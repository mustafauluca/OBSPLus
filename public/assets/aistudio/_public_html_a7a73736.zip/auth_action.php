<?php
/**
 * E-LEARN: Öğrenci Giriş ve Kayıt İşlem Uç Noktası (auth_action.php)
 */

require_once __DIR__ . '/config/settings.php';
require_once __DIR__ . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /');
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!validateCsrfToken($token)) {
    die("Güvenlik ihlali: CSRF doğrulama hatası.");
}

$action = $_POST['action'] ?? '';

if ($action === 'student_login') {
    $studentNo = trim($_POST['student_no'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = !empty($_POST['remember_me']);

    $result = loginStudent($studentNo, $password, $remember);

    if ($result['success']) {
        header('Location: /elearn/profile.php');
        exit;
    } else {
        $_SESSION['flash_error'] = $result['message'];
        header('Location: /?login_error=1');
        exit;
    }
}

if ($action === 'student_register') {
    $result = registerStudent($_POST);

    if ($result['success']) {
        $_SESSION['flash_success'] = $result['message'];
        header('Location: /?registered=1');
        exit;
    } else {
        $_SESSION['flash_error'] = $result['message'];
        header('Location: /?register_error=1');
        exit;
    }
}

header('Location: /');
exit;
