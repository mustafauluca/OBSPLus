/**
 * E-LEARN Başlangıç Verileri (install.sql ile birebir uyumlu)
 */

export interface Course {
  id: number;
  title: string;
  slug: string;
  category: string;
  description: string;
  imageUrl: string;
  sortOrder: number;
  isActive: boolean;
}

export interface Topic {
  id: number;
  courseId: number;
  title: string;
  slug: string;
  shortSummary: string;
  contentHtml: string;
  videoUrl?: string;
  pdfFileUrl?: string;
  sortOrder: number;
  isActive: boolean;
}

export interface QuestionOption {
  id: number;
  questionId: number;
  optionKey: string;
  optionText: string;
  isCorrect: boolean;
}

export interface Question {
  id: number;
  courseId: number;
  topicId?: number;
  questionText: string;
  points: number;
  explanation: string;
  options: QuestionOption[];
}

export interface Exam {
  id: number;
  courseId: number;
  title: string;
  description: string;
  durationMinutes: number;
  passingGrade: number;
  questionCount: number;
  maxAttempts: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

export interface Student {
  id: number;
  studentNo: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  totalScore: number;
  allowScoreboard: boolean;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface ExamAttempt {
  id: number;
  studentId: number;
  studentNo: string;
  studentName: string;
  examType: 'quiz' | 'exam';
  targetId: number;
  targetTitle: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  emptyCount: number;
  passed: boolean;
  completedAt: string;
  answers: {
    questionId: number;
    questionText: string;
    chosenKey?: string;
    chosenText?: string;
    correctKey: string;
    correctText: string;
    isCorrect: boolean;
    explanation?: string;
  }[];
}

export interface VisitorLog {
  id: number;
  ipAddress: string;
  pageTitle: string;
  pageUrl: string;
  referrer: string;
  browser: string;
  os: string;
  deviceType: 'desktop' | 'mobile' | 'tablet';
  studentId?: number;
  visitDate: string;
  visitTime: string;
}

export interface LoginLog {
  id: number;
  studentNo: string;
  fullNameEntered: string;
  ipAddress: string;
  browser: string;
  deviceType: string;
  status: 'success' | 'failed';
  failureReason?: string;
  createdAt: string;
}

export interface RegisterLog {
  id: number;
  studentNo: string;
  fullName: string;
  email: string;
  ipAddress: string;
  status: 'success' | 'failed';
  verificationStatus: string;
  failureReason?: string;
  createdAt: string;
}

export interface TeamMember {
  id: number;
  fullName: string;
  roleTitle: string;
  photoUrl: string;
  biography: string;
  education: string;
  specialties: string;
  sortOrder: number;
  isActive: boolean;
  isDemo: boolean;
}

export interface SiteSettings {
  siteName: string;
  siteTitle: string;
  siteDescription: string;
  footerText: string;
  kvkkText: string;
  aboutSummary: string;
  dataRetentionDays: number;
  rateLimitMaxAttempts: number;
  rateLimitBlockMinutes: number;
}

export interface ContactSettings {
  phone: string;
  email: string;
  address: string;
  whatsapp: string;
  instagram: string;
  facebook: string;
  youtube: string;
  workingHours: string;
}

export const INITIAL_COURSES: Course[] = [
  {
    id: 1,
    title: 'Bilgisayar Teknolojileri ve Programlama',
    slug: 'bilgisayar-teknolojileri',
    category: 'Bilişim & Yazılım',
    description: 'Algoritmalar, modern yazılım prensipleri, MySQLi veritabanı mimarisi ve web güvenliği.',
    imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&auto=format&fit=crop&q=80',
    sortOrder: 1,
    isActive: true,
  },
  {
    id: 2,
    title: 'İşletme Yönetimi ve Finansal Analiz',
    slug: 'isletme-yonetimi',
    category: 'İktisadi Bilimler',
    description: 'Modern yönetim stratejileri, organizasyonel liderlik, bilanço okuma ve kurumsal finans yönetimi.',
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80',
    sortOrder: 2,
    isActive: true,
  },
  {
    id: 3,
    title: 'Web Geliştirme ve Siber Güvenlik',
    slug: 'web-gelistirme',
    category: 'Bilişim & Yazılım',
    description: 'CSRF, XSS ve SQL Injection korumalı oturum mimarisi, güvenli API tasarımı ve şifreleme.',
    imageUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=80',
    sortOrder: 3,
    isActive: true,
  },
  {
    id: 4,
    title: 'Grafik Tasarım ve Kullanıcı Arayüzü',
    slug: 'grafik-tasarim',
    category: 'Tasarım & Sanat',
    description: 'Renk teorisi, tipografi hiyerarşisi, responsive layout dizaynı ve kullanıcı deneyimi ilkeleri.',
    imageUrl: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=600&auto=format&fit=crop&q=80',
    sortOrder: 4,
    isActive: true,
  },
];

export const INITIAL_TOPICS: Topic[] = [
  {
    id: 1,
    courseId: 1,
    title: 'Algoritmalar ve Akış Şemaları',
    slug: 'algoritmalar-ve-akis-semalari',
    shortSummary: 'Problem çözme adımları ve karmaşıklık analizi temelleri.',
    contentHtml: `
      <h3>Algoritma ve Mantıksal Tasarım</h3>
      <p>Algoritma, belirli bir problemi çözmek veya belirli bir amaca ulaşmak için tasarlanan mantıksal adımlar bütünüdür. Her algoritma sonlu sayıda adımdan oluşmalı, kesin ve net olmalıdır.</p>
      <h4>Temel Özellikler:</h4>
      <ul>
        <li><strong>Girdi ve Çıktı:</strong> Sıfır veya daha fazla girdi alır, en az bir çıktı üretir.</li>
        <li><strong>Kesinlik:</strong> Her adım net ve yoruma kapalıdır.</li>
        <li><strong>Sonluluk:</strong> Sonsuz döngüye girmeden durmalıdır.</li>
      </ul>
      <h4>Zaman Karmaşıklığı:</h4>
      <p>Büyük O (Big-O) gösterimi, bir algoritmanın girdi boyutu büyüdükçe işlem süresinin nasıl değiştiğini matematiksel olarak tanımlar. O(1) sabit zamanı, O(n) lineer zamanı ifade eder.</p>
    `,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    pdfFileUrl: '/uploads/materials/algoritmalar_giris.pdf',
    sortOrder: 1,
    isActive: true,
  },
  {
    id: 2,
    courseId: 1,
    title: 'İlişkisel Veritabanları ve MySQLi',
    slug: 'iliskisel-veritabanlari-mysqli',
    shortSummary: 'SQL sorguları, prepared statements ve ACID kuralları.',
    contentHtml: `
      <h3>MySQLi ve Prepared Statements Mimarisi</h3>
      <p>Veritabanı güvenliğinde SQL Injection açıklarına karşı en etkili yöntem MySQLi prepared statement mekanizmasıdır. Parametreler SQL komutundan ayrı olarak derlenir ve veritabanı motoru tarafından doğrudan çalıştırılabilir kod olarak değil salt veri olarak algılanır.</p>
      <h4>Prepared Statement Aşamaları:</h4>
      <ol>
        <li><strong>Hazırlama (Prepare):</strong> Şablon SQL sunucuya gönderilir (örn: <code>SELECT * FROM users WHERE email = ?</code>).</li>
        <li><strong>Bağlama (Bind Param):</strong> Parametreler ve veri tipleri (<code>s, i, d, b</code>) eşleştirilir.</li>
        <li><strong>Çalıştırma (Execute):</strong> Sorgu derlenmiş şablon üzerinden güvenle yürütülür.</li>
      </ol>
    `,
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    pdfFileUrl: '/uploads/materials/mysqli_guvenlik.pdf',
    sortOrder: 2,
    isActive: true,
  },
  {
    id: 3,
    courseId: 2,
    title: 'Yönetim Fonksiyonları ve Liderlik',
    slug: 'yonetim-fonksiyonlari-ve-liderlik',
    shortSummary: 'Planlama, örgütleme, yöneltme ve denetim süreçleri.',
    contentHtml: `
      <h3>Modern Yönetim Fonksiyonları</h3>
      <p>Klasik yönetim kuramından günümüze yönetim süreci 4 temel fonksiyon üzerinde şekillenir: Planlama, Örgütleme, Yöneltme ve Denetim.</p>
      <p>Başarılı bir yönetici hedefleri belirlerken SMART (Spesifik, Ölçülebilir, Ulaşılabilir, İlgili, Zamanlı) kriterlerine bağlı kalır.</p>
    `,
    sortOrder: 1,
    isActive: true,
  },
  {
    id: 4,
    courseId: 3,
    title: 'OWASP İlkeleri ve Web Güvenliği',
    slug: 'owasp-ilkeleri-ve-web-guvenligi',
    shortSummary: 'En yaygın web açıkları ve savunma mekanizmaları.',
    contentHtml: `
      <h3>OWASP Top 10 ve Savunma Prensipleri</h3>
      <p>Web uygulamalarında güvenlik zafiyetlerinin başında Enjeksiyon (SQLi), Kırık Kimlik Doğrulama ve Siteler Arası İstek Sahteciliği (CSRF) gelir.</p>
      <p>CSRF koruması için her HTTP POST formuna tahmin edilemez, oturuma özel kriptografik token yerleştirilmelidir.</p>
    `,
    sortOrder: 1,
    isActive: true,
  },
];

export const INITIAL_QUESTIONS: Question[] = [
  {
    id: 1,
    courseId: 1,
    topicId: 1,
    questionText: 'Aşağıdakilerden hangisi bir algoritmanın temel özelliklerinden biri DEĞİLDİR?',
    points: 10,
    explanation: 'Algoritmalar kesin, sonlu ve etkin olmalıdır; sonsuz döngüye girmemelidir.',
    options: [
      { id: 101, questionId: 1, optionKey: 'A', optionText: 'Sonluluk (Adımların bir sonu olmalıdır)', isCorrect: false },
      { id: 102, questionId: 1, optionKey: 'B', optionText: 'Kesinlik (Her adım açık ve net olmalıdır)', isCorrect: false },
      { id: 103, questionId: 1, optionKey: 'C', optionText: 'Sonsuzluk (İşlem durmaksızın sürmelidir)', isCorrect: true },
      { id: 104, questionId: 1, optionKey: 'D', optionText: 'Etkinlik (Uygulanabilir adımlar olmalıdır)', isCorrect: false },
    ],
  },
  {
    id: 2,
    courseId: 1,
    topicId: 1,
    questionText: 'Zaman karmaşıklığı O(1) olan bir işlem aşağıdakilerden hangisini ifade eder?',
    points: 10,
    explanation: 'Girdi boyutundan bağımsız olarak sabit sürede çalışan işlemleri belirtir.',
    options: [
      { id: 201, questionId: 2, optionKey: 'A', optionText: 'Sabit Zaman (Constant Time)', isCorrect: true },
      { id: 202, questionId: 2, optionKey: 'B', optionText: 'Lineer Zaman (Linear Time)', isCorrect: false },
      { id: 203, questionId: 2, optionKey: 'C', optionText: 'Karesel Zaman (Quadratic Time)', isCorrect: false },
      { id: 204, questionId: 2, optionKey: 'D', optionText: 'Logaritmik Zaman (Logarithmic Time)', isCorrect: false },
    ],
  },
  {
    id: 3,
    courseId: 1,
    topicId: 2,
    questionText: 'SQL Injection saldırılarına karşı en etkili ve endüstri standardı savunma yöntemi hangisidir?',
    points: 10,
    explanation: 'Prepared Statement kullanımı parametreleri SQL komutundan izole eder.',
    options: [
      { id: 301, questionId: 3, optionKey: 'A', optionText: 'Girdileri yalnızca base64 ile kodlamak', isCorrect: false },
      { id: 302, questionId: 3, optionKey: 'B', optionText: 'Prepared Statement (Parametreli Sorgular) kullanmak', isCorrect: true },
      { id: 303, questionId: 3, optionKey: 'C', optionText: 'Veritabanı şifresini kısa tutmak', isCorrect: false },
      { id: 304, questionId: 3, optionKey: 'D', optionText: 'Kullanıcı girdisini tırnakla birleştirmek', isCorrect: false },
    ],
  },
  {
    id: 4,
    courseId: 3,
    topicId: 4,
    questionText: 'CSRF (Cross-Site Request Forgery) saldırılarını engellemek için hangi yöntem kullanılır?',
    points: 10,
    explanation: 'Benzersiz, tahmin edilemez ve oturuma bağlı CSRF token doğrulaması yapılır.',
    options: [
      { id: 401, questionId: 4, optionKey: 'A', optionText: 'Oturum süresini 1 yıla uzatmak', isCorrect: false },
      { id: 402, questionId: 4, optionKey: 'B', optionText: 'Her istekte rastgele üretilen CSRF Token doğrulamak', isCorrect: true },
      { id: 403, questionId: 4, optionKey: 'C', optionText: 'Sadece GET metodunu zorunlu kılmak', isCorrect: false },
      { id: 404, questionId: 4, optionKey: 'D', optionText: 'Tarayıcı önbelleğini devre dışı bırakmak', isCorrect: false },
    ],
  },
  {
    id: 5,
    courseId: 2,
    topicId: 3,
    questionText: 'Yönetim sürecinde SMART hedefler kavramındaki "M" harfi neyi ifade eder?',
    points: 10,
    explanation: 'SMART: Specific, Measurable (Ölçülebilir), Achievable, Relevant, Time-bound.',
    options: [
      { id: 501, questionId: 5, optionKey: 'A', optionText: 'Meaningful (Anlamlı)', isCorrect: false },
      { id: 502, questionId: 5, optionKey: 'B', optionText: 'Measurable (Ölçülebilir)', isCorrect: true },
      { id: 503, questionId: 5, optionKey: 'C', optionText: 'Motivational (Motive edici)', isCorrect: false },
      { id: 504, questionId: 5, optionKey: 'D', optionText: 'Modern (Çağdaş)', isCorrect: false },
    ],
  },
];

export const INITIAL_EXAMS: Exam[] = [
  {
    id: 1,
    courseId: 1,
    title: 'Bilgisayar Teknolojileri Dönem Sonu Vize Sınavı',
    description: 'Algoritmalar, akış şemaları ve temel veritabanı kavramlarını içeren online değerlendirme sınavı.',
    durationMinutes: 30,
    passingGrade: 50,
    questionCount: 3,
    maxAttempts: 2,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isActive: true,
  },
  {
    id: 2,
    courseId: 2,
    title: 'İşletme Yönetimi Vize Değerlendirmesi',
    description: 'Yönetim fonksiyonları, liderlik modelleri ve kurumsal organizasyon ilkeleri sınavı.',
    durationMinutes: 30,
    passingGrade: 50,
    questionCount: 2,
    maxAttempts: 2,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isActive: true,
  },
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 1,
    studentNo: '202610101',
    firstName: 'Ahmet',
    lastName: 'Yılmaz',
    email: 'ahmet.yilmaz@ogrenci.edu.tr',
    phone: '05419141201',
    totalScore: 985,
    allowScoreboard: true,
    status: 'active',
    createdAt: '2026-02-10 10:00:00',
  },
  {
    id: 2,
    studentNo: '202610102',
    firstName: 'Mehmet',
    lastName: 'Kaya',
    email: 'mehmet.kaya@ogrenci.edu.tr',
    phone: '05419141202',
    totalScore: 940,
    allowScoreboard: true,
    status: 'active',
    createdAt: '2026-02-12 11:30:00',
  },
  {
    id: 3,
    studentNo: '202610103',
    firstName: 'Ayşe',
    lastName: 'Demir',
    email: 'ayse.demir@ogrenci.edu.tr',
    phone: '05419141203',
    totalScore: 920,
    allowScoreboard: true,
    status: 'active',
    createdAt: '2026-02-15 09:15:00',
  },
  {
    id: 4,
    studentNo: '202610104',
    firstName: 'Zeynep',
    lastName: 'Çelik',
    email: 'zeynep.celik@ogrenci.edu.tr',
    phone: '05419141204',
    totalScore: 895,
    allowScoreboard: true,
    status: 'active',
    createdAt: '2026-02-18 14:20:00',
  },
];

export const INITIAL_TEAM_MEMBERS: TeamMember[] = [
  {
    id: 1,
    fullName: 'Prof. Dr. Murat DOĞAN',
    roleTitle: 'Eğitim Koordinatörü',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    biography: 'Yükseköğretim müfredat geliştirme ve dijital ölçme-değerlendirme alanlarında 22 yıllık akademik tecrübe.',
    education: 'ODTÜ - Eğitim Bilimleri Doktora',
    specialties: 'Öğretim Tasarımı, Müfredat Geliştirme, Akademik Liderlik',
    sortOrder: 1,
    isActive: true,
    isDemo: true,
  },
  {
    id: 2,
    fullName: 'Doç. Dr. Ceyda SÖZER',
    roleTitle: 'Akademik Danışman',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    biography: 'Öğrenme analitiği, uzaktan eğitim sistemleri ve öğrenci motivasyonu üzerine uluslararası çalışmalar yürütmektedir.',
    education: 'Boğaziçi Üniversitesi - Eğitim Teknolojileri',
    specialties: 'Öğrenme Analitiği, Bilişsel Psikoloji, İntibak Planlama',
    sortOrder: 2,
    isActive: true,
    isDemo: true,
  },
  {
    id: 3,
    fullName: 'Serkan DUMAN',
    roleTitle: 'Bilgisayar Teknolojileri Uzmanı',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    biography: 'Yüksek performanslı sınav motorları, veritabanı optimizasyonu ve güvenli web mimarileri uzmanı.',
    education: 'İTÜ - Bilgisayar Mühendisliği Lisans & Y.Lisans',
    specialties: 'Full Stack Mimari, MySQL İleri Düzey, Sistem Güvenliği',
    sortOrder: 3,
    isActive: true,
    isDemo: true,
  },
  {
    id: 4,
    fullName: 'Dr. Ahmet KOÇYILMAZ',
    roleTitle: 'Ölçme ve Değerlendirme Uzmanı',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    biography: 'Çoktan seçmeli test geçerliliği, soru ayırt edicilik indeksleri ve sınav standardizasyonu lideri.',
    education: 'Hacettepe Üniversitesi - Ölçme ve Değerlendirme',
    specialties: 'Soru Havuzu Analitiği, Madde Güçlüğü, İstatistiksel Testler',
    sortOrder: 4,
    isActive: true,
    isDemo: true,
  },
  {
    id: 5,
    fullName: 'Büşra DEMİR',
    roleTitle: 'Öğrenci İşleri Sorumlusu',
    photoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
    biography: 'Öğrenci kayıt süreçleri, intibak dosya yönetimi ve 7/24 akademik destek operasyon koordinatörü.',
    education: 'Ankara Üniversitesi - İletişim Fakültesi',
    specialties: 'Öğrenci Rehberliği, KVKK Süreçleri, Dosya Takibi',
    sortOrder: 5,
    isActive: true,
    isDemo: true,
  },
  {
    id: 6,
    fullName: 'Numan YILDIRIM',
    roleTitle: 'Eğitim İçerik Editörü',
    photoUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&auto=format&fit=crop&q=80',
    biography: 'Dijital eğitim materyalleri, interaktif soru hazırlama ve video ders anlatımları içerik mimarı.',
    education: 'Gazi Üniversitesi - Türkçe Eğitimi & İletişim',
    specialties: 'Pedagojik İçerik Tasarımı, Zengin Metin, Multimedya',
    sortOrder: 6,
    isActive: true,
    isDemo: true,
  },
];

export const INITIAL_VISITOR_LOGS: VisitorLog[] = [
  {
    id: 1,
    ipAddress: '176.234.88.14',
    pageTitle: 'E-LEARN Ana Sayfa',
    pageUrl: '/',
    referrer: 'Direct',
    browser: 'Chrome 122',
    os: 'Windows 11',
    deviceType: 'desktop',
    visitDate: '2026-11-08',
    visitTime: '10:15:22',
  },
  {
    id: 2,
    ipAddress: '88.241.12.90',
    pageTitle: 'Bilgisayar Teknolojileri ve Programlama',
    pageUrl: '/elearn/course?id=1',
    referrer: 'https://google.com',
    browser: 'Safari Mobile',
    os: 'iOS 17',
    deviceType: 'mobile',
    visitDate: '2026-11-08',
    visitTime: '11:40:05',
  },
  {
    id: 3,
    ipAddress: '212.156.40.18',
    pageTitle: 'Liderler Tablosu Skorboard',
    pageUrl: '/#skorboard',
    referrer: 'Direct',
    browser: 'Firefox 124',
    os: 'macOS Sonoma',
    deviceType: 'desktop',
    visitDate: '2026-11-08',
    visitTime: '12:05:18',
  },
  {
    id: 4,
    ipAddress: '194.27.18.5',
    pageTitle: 'Algoritmalar ve Akış Şemaları Testi',
    pageUrl: '/elearn/test?topic_id=1',
    referrer: 'https://bing.com',
    browser: 'Chrome Mobile',
    os: 'Android 14',
    deviceType: 'mobile',
    visitDate: '2026-11-08',
    visitTime: '12:22:45',
  },
  {
    id: 5,
    ipAddress: '176.234.88.14',
    pageTitle: 'Öğrenci Giriş Paneli',
    pageUrl: '/login',
    referrer: '/',
    browser: 'Chrome 122',
    os: 'Windows 11',
    deviceType: 'desktop',
    visitDate: '2026-11-08',
    visitTime: '12:35:10',
  },
];

export const INITIAL_LOGIN_LOGS: LoginLog[] = [
  {
    id: 1,
    studentNo: '202610101',
    fullNameEntered: 'Ahmet Yılmaz',
    ipAddress: '176.234.88.14',
    browser: 'Chrome 122',
    deviceType: 'desktop',
    status: 'success',
    failureReason: 'Başarılı Oturum',
    createdAt: '2026-11-08 10:18:00',
  },
  {
    id: 2,
    studentNo: '202610999',
    fullNameEntered: '',
    ipAddress: '88.241.12.90',
    browser: 'Safari',
    deviceType: 'mobile',
    status: 'failed',
    failureReason: 'Öğrenci numarası bulunamadı',
    createdAt: '2026-11-08 11:42:15',
  },
  {
    id: 3,
    studentNo: '202610102',
    fullNameEntered: 'Mehmet Kaya',
    ipAddress: '212.156.40.18',
    browser: 'Firefox',
    deviceType: 'desktop',
    status: 'success',
    failureReason: 'Başarılı Oturum',
    createdAt: '2026-11-08 12:10:00',
  },
];

export const INITIAL_REGISTER_LOGS: RegisterLog[] = [
  {
    id: 1,
    studentNo: '202610101',
    fullName: 'Ahmet Yılmaz',
    email: 'ahmet.yilmaz@ogrenci.edu.tr',
    ipAddress: '176.234.88.14',
    status: 'success',
    verificationStatus: 'verified',
    createdAt: '2026-02-10 10:00:00',
  },
  {
    id: 2,
    studentNo: '202610102',
    fullName: 'Mehmet Kaya',
    email: 'mehmet.kaya@ogrenci.edu.tr',
    ipAddress: '212.156.40.18',
    status: 'success',
    verificationStatus: 'verified',
    createdAt: '2026-02-12 11:30:00',
  },
];

export const INITIAL_SITE_SETTINGS: SiteSettings = {
  siteName: 'E-LEARN Eğitim Platformu',
  siteTitle: 'E-LEARN – Öğrenci Eğitim, Sınav ve İstatistik Platformu',
  siteDescription: 'Kapsamlı dersler, konu anlatımları, interaktif testler, vize sınavları ve akademik analiz platformu.',
  footerText: '© 2026 E-LEARN. Tüm Hakları Saklıdır. Güvenli Öğrenci Bilgi ve Sınav Portali.',
  kvkkText: '6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) uyarınca kişisel verileriniz veri sorumlusu sıfatıyla E-LEARN platformu tarafından eğitim ve ölçme-değerlendirme faaliyetleri amacıyla işlenmektedir. Verileriniz şifrelenmiş altyapıda güvenle korunmakta ve üçüncü kişilerle paylaşılmamaktadır.',
  aboutSummary: 'E-LEARN, öğrencilerin teorik ve pratik bilgi düzeylerini ölçen, konu testleri ve vize sınavlarıyla akademik başarılarını destekleyen yeni nesil dijital öğrenme ortamıdır.',
  dataRetentionDays: 365,
  rateLimitMaxAttempts: 5,
  rateLimitBlockMinutes: 15,
};

export const INITIAL_CONTACT_SETTINGS: ContactSettings = {
  phone: '0 541 914 12 48',
  email: 'bilgi@elearn.edu.tr',
  address: 'Üniversiteler Mah. Dumlupınar Bulv. No:1, Çankaya / Ankara',
  whatsapp: '05419141248',
  instagram: 'elearn_resmi',
  facebook: 'elearnturkiye',
  youtube: 'elearnakademi',
  workingHours: 'Pazartesi - Cuma: 08:30 - 18:00',
};
