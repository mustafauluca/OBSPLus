import React, { useEffect, useState } from 'react';
import { useElearn } from '../context/ElearnContext';
import {
  GraduationCap,
  BookOpen,
  Trophy,
  Users,
  Award,
  Sparkles,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Send,
  ArrowRight,
  ShieldAlert,
  FileQuestion,
  Star
} from 'lucide-react';

interface HomeViewProps {
  setCurrentView: (view: string, params?: Record<string, any>) => void;
  onOpenRegister: () => void;
  onOpenLogin: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  setCurrentView,
  onOpenRegister,
  onOpenLogin,
}) => {
  const { courses, getTopScoreboard, teamMembers, students, examAttempts, contactSettings, trackPageVisit, currentStudent } = useElearn();

  useEffect(() => {
    trackPageVisit('E-LEARN Ana Sayfa', '/');
  }, []);

  const scoreboard = getTopScoreboard();
  const [contactSuccess, setContactSuccess] = useState(false);
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setContactName('');
    setContactEmail('');
    setContactMessage('');
    setTimeout(() => setContactSuccess(false), 5000);
  };

  return (
    <div className="space-y-16">
      {/* 1. HERO ALANI */}
      <section className="bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white py-16 sm:py-20 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              Akademik Ölçme ve Değerlendirme Standardı
            </div>

            <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              Geleceğini Şekillendirecek <span className="text-teal-400">Eğitim ve Sınav</span> Portali
            </h1>

            <p className="text-slate-300 text-base sm:text-lg max-w-2xl leading-relaxed">
              Zenginleştirilmiş konu anlatımları, interaktif modül testleri ve online vize sınavları ile akademik başarını en üst seviyeye taşı. Detaylı analizler ve başarı sıralamasıyla gelişimini anlık izle.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => setCurrentView('elearn_catalog')}
                className="px-6 py-3.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm shadow-lg flex items-center gap-2 transition-all cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                Eğitime Başla & Dersler
              </button>

              {!currentStudent ? (
                <button
                  onClick={onOpenRegister}
                  className="px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-sm font-semibold transition-all cursor-pointer"
                >
                  Öğrenci Kaydı Yap
                </button>
              ) : (
                <button
                  onClick={() => setCurrentView('student_profile')}
                  className="px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 text-sm font-semibold flex items-center gap-2"
                >
                  <Award className="w-4 h-4" />
                  Öğrenci Profilim
                </button>
              )}
            </div>
          </div>

          {/* Hero Sağ Vitrin: Öne Çıkan Başarılar */}
          <div className="lg:col-span-5">
            <div className="p-6 rounded-3xl bg-slate-800/60 border border-slate-700/80 shadow-2xl backdrop-blur-md space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>Ders Birincileri Skorboardı</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-[10px] font-bold border border-teal-500/30">
                  Canlı Liderler
                </span>
              </div>

              <div className="space-y-2.5">
                {scoreboard.slice(0, 3).map((sb) => (
                  <div
                    key={sb.courseId}
                    className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700/60 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="text-[10px] text-slate-400">{sb.courseTitle}</div>
                      <div className="font-bold text-teal-300 mt-0.5 text-sm">{sb.maskedName}</div>
                    </div>
                    <div className="text-right">
                      <span className="px-2 py-0.5 rounded bg-amber-400/20 text-amber-300 font-mono font-bold text-xs border border-amber-400/30">
                        {sb.totalPoints} Puan
                      </span>
                      <div className="text-[10px] text-slate-400 mt-0.5 font-medium">%{sb.successRate} Başarı</div>
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-[11px] text-slate-400 text-center italic">
                * KVKK gereğince öğrenci soyadları maskelenerek gösterilmektedir.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. İSTATİSTİKLER SAYACI */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono text-slate-900">
              {students.length}+
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kayıtlı Öğrenci</div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono text-teal-600">
              {courses.length}
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Aktif Eğitim Programı</div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono text-indigo-600">
              {Math.max(120, examAttempts.length + 85)}+
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tamamlanan Sınav</div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-1">
            <div className="text-3xl sm:text-4xl font-black font-mono text-emerald-600">
              %98.4
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Öğrenci Memnuniyeti</div>
          </div>
        </div>
      </section>

      {/* 3. AKTİF DERSLER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-bold uppercase tracking-wider border border-teal-200">
            Müfredat ve Dersler
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">Öğrenci Eğitim Modülleri</h2>
          <p className="text-sm text-slate-600">
            Akademisyenlerimiz tarafından hazırlanan zengin içerikli konu anlatımları ve interaktif çoktan seçmeli testler.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col hover:shadow-md transition-shadow group"
            >
              <div className="h-44 overflow-hidden relative">
                <img
                  src={course.imageUrl}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-bold">
                  {course.category}
                </span>
              </div>

              <div className="p-5 flex flex-col flex-grow space-y-3">
                <h4 className="font-bold text-slate-900 text-sm leading-snug">{course.title}</h4>
                <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed flex-grow">
                  {course.description}
                </p>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentView('course_detail', { id: course.id })}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    Dersi İncele & Test Çöz <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. SKORBOARD (HER DERSİN EN BAŞARILI ÖĞRENCİSİ) */}
      <section id="skorboard" className="bg-slate-100 py-16 px-4">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold uppercase tracking-wider border border-amber-200 inline-flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5" /> Başarı Sıralaması
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Ders Bazlı Skorboard (Liderler Tablosu)
            </h2>
            <p className="text-sm text-slate-600">
              Her dersin en başarılı öğrencisi. Kişisel veriler KVKK ilkeleri uyarınca soyad ilk harf olarak maskelenerek yayınlanır.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {scoreboard.map((sb) => (
              <div
                key={sb.courseId}
                className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs relative flex flex-col justify-between space-y-4 hover:border-amber-400 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{sb.category}</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px]">
                    #1 Lider
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{sb.courseTitle}</h4>
                  <div className="flex items-center gap-3 mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                    <div className="w-10 h-10 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-sm font-mono shrink-0">
                      {sb.maskedName.charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 text-sm">{sb.maskedName}</div>
                      <div className="text-[11px] text-slate-500 font-medium">{sb.examCount} Sınav Tamamlandı</div>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold uppercase">Toplam Puan</span>
                    <div className="text-lg font-black font-mono text-teal-600">{sb.totalPoints}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 font-semibold uppercase">Başarı Oranı</span>
                    <div className="text-lg font-black font-mono text-emerald-600">%{sb.successRate}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. AKADEMİK EKİP */}
      <section id="ekip" className="max-w-7xl mx-auto px-4 sm:px-6 space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold uppercase tracking-wider border border-indigo-200">
            Akademik Kadro
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">Eğitim ve Ölçme Heyetimiz</h2>
          <p className="text-sm text-slate-600">
            Müfredat geliştirme, sınav soru havuzu ve akademik danışmanlık heyeti temsilcilerimiz (Temsili / Demo Kadro).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-4">
                <img
                  src={member.photoUrl}
                  alt={member.fullName}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-teal-500 shadow-xs"
                />
                <div>
                  <h4 className="font-bold text-slate-900 text-base">{member.fullName}</h4>
                  <div className="text-xs text-teal-600 font-semibold mt-0.5">{member.roleTitle}</div>
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                {member.biography}
              </p>

              <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
                <div><strong className="text-slate-700">Mezuniyet:</strong> {member.education}</div>
                <div><strong className="text-slate-700">Uzmanlık:</strong> {member.specialties}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. İLETİŞİM ALANI */}
      <section id="iletisim" className="bg-slate-900 text-white py-16 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <span className="px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold border border-teal-500/30">
              İletişim & Danışma
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Öğrenci Destek ve Akademik Koordinasyon
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              Dersler, vize sınavları, puan denkleştirmeleri veya teknik sorularınız için akademik danışman heyetimizle iletişime geçebilirsiniz.
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <Phone className="w-4 h-4 text-teal-400" />
                <div>
                  <div className="text-slate-400">Danışma & Bilgi Hattı</div>
                  <div className="font-bold text-white text-sm">{contactSettings.phone}</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <Mail className="w-4 h-4 text-teal-400" />
                <div>
                  <div className="text-slate-400">Resmi E-Posta</div>
                  <div className="font-bold text-white text-sm">{contactSettings.email}</div>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/80 border border-slate-700">
                <MapPin className="w-4 h-4 text-teal-400" />
                <div>
                  <div className="text-slate-400">Kampüs Adresi</div>
                  <div className="font-bold text-white">{contactSettings.address}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Mesaj Formu */}
          <div className="lg:col-span-6 bg-white text-slate-900 p-8 rounded-3xl shadow-xl space-y-4">
            <h4 className="font-bold text-slate-900 text-lg">Hızlı Danışma Mesajı Gönder</h4>
            <p className="text-xs text-slate-500">Formu doldurarak eğitim danışmanlarımıza anlık iletebilirsiniz.</p>

            {contactSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Mesajınız başarıyla iletildi. En kısa sürede geri dönüş yapılacaktır.</span>
              </div>
            )}

            <form onSubmit={handleContactSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Adınız Soyadınız</label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="Adınız Soyadınız"
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">E-Posta Adresiniz</label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder="ad@ornek.com"
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Mesajınız</label>
                <textarea
                  rows={4}
                  required
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  placeholder="Ders veya sınav hakkındaki sorunuz..."
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:outline-none"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" /> Mesajı Gönder
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};
