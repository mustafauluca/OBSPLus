import React, { useState } from 'react';
import { useElearn } from '../../context/ElearnContext';
import { Save, ShieldAlert, CheckCircle, Database, Lock, Clock } from 'lucide-react';

export const AdminSettingsTab: React.FC = () => {
  const { siteSettings, updateSiteSettings } = useElearn();
  const [formData, setFormData] = useState({
    siteName: siteSettings.siteName || 'E-LEARN Platform',
    siteTitle: siteSettings.siteTitle || 'E-LEARN – Öğrenci Eğitim Platformu',
    siteDescription: siteSettings.siteDescription || 'Online eğitim, test ve vize sınavı yönetim sistemi',
    aboutSummary: siteSettings.aboutSummary || 'Öğrenciler için geliştirilmiş modern eğitim platformu',
    footerText: siteSettings.footerText || '© 2026 E-LEARN Öğrenci Eğitim Platformu. Tüm hakları saklıdır.',
    kvkkText: siteSettings.kvkkText || '6698 sayılı Kişisel Verilerin Korunması Kanunu uyarınca...',
    rateLimitMaxAttempts: siteSettings.rateLimitMaxAttempts || 5,
    rateLimitBlockMinutes: siteSettings.rateLimitBlockMinutes || 15,
    dataRetentionDays: siteSettings.dataRetentionDays || 90,
  });

  const [saved, setSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSiteSettings(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Sistem ve Güvenlik Ayarları</h2>
          <p className="text-sm text-slate-500">
            KVKK aydınlatma metni, rate limit (brute force koruması) ve log saklama parametreleri
          </p>
        </div>
        {saved && (
          <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
            <CheckCircle className="w-4 h-4" /> Ayarlar Kaydedildi!
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
            <Database className="w-4 h-4 text-teal-600" /> Genel Platform Tanımları
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">Site Başlığı</label>
            <input
              type="text"
              value={formData.siteTitle}
              onChange={(e) => setFormData({ ...formData, siteTitle: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">Site Açıklaması (Meta Description)</label>
            <textarea
              rows={2}
              value={formData.siteDescription}
              onChange={(e) => setFormData({ ...formData, siteDescription: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-500" /> Güvenlik, Rate Limit & KVKK Saklama Politikası
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                Maksimum Hatalı Giriş Sayısı (Rate Limit)
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="number"
                  min="3"
                  max="20"
                  value={formData.rateLimitMaxAttempts}
                  onChange={(e) => setFormData({ ...formData, rateLimitMaxAttempts: Number(e.target.value) })}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Bu sayı aşıldığında IP geçici olarak engellenir.</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                IP Engelleme Süresi (Dakika)
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="number"
                  min="5"
                  max="1440"
                  value={formData.rateLimitBlockMinutes}
                  onChange={(e) => setFormData({ ...formData, rateLimitBlockMinutes: Number(e.target.value) })}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Engellenen IP'nin bekleme süresi.</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                Log Saklama Süresi (Gün - KVKK Politikası)
              </label>
              <div className="relative">
                <Database className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="number"
                  min="30"
                  max="365"
                  value={formData.dataRetentionDays}
                  onChange={(e) => setFormData({ ...formData, dataRetentionDays: Number(e.target.value) })}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Bu süreden eski loglar otomatik temizlenir.</p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1">
              KVKK Aydınlatma Metni (Öğrenci Kayıt Formunda Gösterilir)
            </label>
            <textarea
              rows={6}
              value={formData.kvkkText}
              onChange={(e) => setFormData({ ...formData, kvkkText: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 font-sans"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-md cursor-pointer"
          >
            <Save className="w-4 h-4" /> Değişiklikleri Kaydet
          </button>
        </div>
      </form>
    </div>
  );
};
