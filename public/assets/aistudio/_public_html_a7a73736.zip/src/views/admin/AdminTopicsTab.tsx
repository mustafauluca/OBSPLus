import React, { useState } from 'react';
import { useElearn } from '../../context/ElearnContext';
import { Plus, Edit2, Trash2, Video, FileText } from 'lucide-react';
import { Topic } from '../../data/initialData';

export const AdminTopicsTab: React.FC = () => {
  const { courses, topics, saveTopic, deleteTopic } = useElearn();
  const [selectedCourseId, setSelectedCourseId] = useState<number>(courses[0]?.id || 1);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  const [form, setForm] = useState({
    courseId: selectedCourseId,
    title: '',
    shortSummary: '',
    contentHtml: '',
    videoUrl: '',
    pdfFileUrl: '',
    sortOrder: 1,
    isActive: true,
  });

  const filteredTopics = topics.filter((t) => t.courseId === selectedCourseId);

  const handleOpenAdd = () => {
    setEditingId(null);
    setForm({
      courseId: selectedCourseId,
      title: '',
      shortSummary: '',
      contentHtml: '<p>Konu içeriğini buraya giriniz.</p>',
      videoUrl: '',
      pdfFileUrl: '',
      sortOrder: filteredTopics.length + 1,
      isActive: true,
    });
    setShowModal(true);
  };

  const handleOpenEdit = (topic: Topic) => {
    setEditingId(topic.id);
    setForm({
      courseId: topic.courseId,
      title: topic.title,
      shortSummary: topic.shortSummary,
      contentHtml: topic.contentHtml,
      videoUrl: topic.videoUrl || '',
      pdfFileUrl: topic.pdfFileUrl || '',
      sortOrder: topic.sortOrder,
      isActive: topic.isActive,
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title) return;

    saveTopic({
      ...(editingId ? { id: editingId } : {}),
      courseId: form.courseId,
      title: form.title,
      shortSummary: form.shortSummary,
      contentHtml: form.contentHtml,
      videoUrl: form.videoUrl || undefined,
      pdfFileUrl: form.pdfFileUrl || undefined,
      sortOrder: form.sortOrder,
      isActive: form.isActive,
      slug: form.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    });

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Konu ve Müfredat Yönetimi</h2>
          <p className="text-sm text-slate-500">
            Derslere ait alt konuları, video bağlantılarını, PDF materyallerini ve sıralamayı düzenleyin
          </p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Yeni Konu Ekle
        </button>
      </div>

      {/* Course Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {courses.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCourseId(c.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCourseId === c.id
                ? 'bg-teal-600 text-white shadow-md shadow-teal-100'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {c.title}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-xs uppercase font-bold text-slate-500 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 w-16">Sıra</th>
                <th className="px-6 py-4">Konu Başlığı</th>
                <th className="px-6 py-4">Kısa Açıklama</th>
                <th className="px-6 py-4">Materyaller</th>
                <th className="px-6 py-4 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTopics.map((topic) => (
                <tr key={topic.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-400 font-mono">
                    #{topic.sortOrder}
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-800">
                    {topic.title}
                  </td>
                  <td className="px-6 py-4 text-slate-500 max-w-xs truncate">
                    {topic.shortSummary}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3 text-xs">
                      {topic.videoUrl ? (
                        <span className="flex items-center gap-1 text-emerald-600 font-medium">
                          <Video className="w-3.5 h-3.5" /> Video Var
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                      {topic.pdfFileUrl ? (
                        <span className="flex items-center gap-1 text-teal-600 font-medium">
                          <FileText className="w-3.5 h-3.5" /> PDF Var
                        </span>
                      ) : null}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleOpenEdit(topic)}
                        className="p-2 text-teal-600 hover:bg-teal-50 rounded-lg transition-colors cursor-pointer"
                        title="Düzenle"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`"${topic.title}" konusunu silmek istediğinize emin misiniz?`)) {
                            deleteTopic(topic.id);
                          }
                        }}
                        className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="Sil"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredTopics.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400 text-sm">
                    Bu derse ait henüz bir konu bulunmuyor.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-100 my-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4">
              {editingId ? 'Konuyu Düzenle' : 'Yeni Konu Ekle'}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">Bağlı Olduğu Ders</label>
                  <select
                    value={form.courseId}
                    onChange={(e) => setForm({ ...form, courseId: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                  >
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">Sıra Numarası</label>
                  <input
                    type="number"
                    min="1"
                    value={form.sortOrder}
                    onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Konu Başlığı</label>
                <input
                  type="text"
                  required
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Kısa Açıklama</label>
                <input
                  type="text"
                  required
                  value={form.shortSummary}
                  onChange={(e) => setForm({ ...form, shortSummary: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  İçerik (HTML veya Zengin Metin)
                </label>
                <textarea
                  rows={6}
                  required
                  value={form.contentHtml}
                  onChange={(e) => setForm({ ...form, contentHtml: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm font-mono text-xs focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">Video Embed URL (YouTube vb.)</label>
                  <input
                    type="text"
                    value={form.videoUrl}
                    onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
                    placeholder="https://www.youtube.com/embed/..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">PDF Materyal URL</label>
                  <input
                    type="text"
                    value={form.pdfFileUrl}
                    onChange={(e) => setForm({ ...form, pdfFileUrl: e.target.value })}
                    placeholder="https://.../notlar.pdf"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-sm cursor-pointer"
                >
                  {editingId ? 'Güncelle' : 'Kaydet'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
