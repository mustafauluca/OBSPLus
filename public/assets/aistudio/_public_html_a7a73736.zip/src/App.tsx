import React, { useState } from 'react';
import { ElearnProvider, useElearn } from './context/ElearnContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthModals } from './components/AuthModals';
import { VisitorIpModal } from './components/VisitorIpModal';
import { AdminLayout } from './components/AdminLayout';

import { HomeView } from './views/HomeView';
import { ElearnCatalogView } from './views/ElearnCatalogView';
import { CourseDetailView } from './views/CourseDetailView';
import { TopicView } from './views/TopicView';
import { QuizView } from './views/QuizView';
import { ExamView } from './views/ExamView';
import { ResultView } from './views/ResultView';
import { StudentProfileView } from './views/StudentProfileView';
import { AdminLoginView } from './views/AdminLoginView';
import { PhpDistributionView } from './views/PhpDistributionView';

import { AdminDashboardTab } from './views/admin/AdminDashboardTab';
import { AdminVisitorsTab } from './views/admin/AdminVisitorsTab';
import { AdminLoginLogsTab } from './views/admin/AdminLoginLogsTab';
import { AdminRegisterLogsTab } from './views/admin/AdminRegisterLogsTab';
import { AdminStudentsTab } from './views/admin/AdminStudentsTab';
import { AdminCoursesTab } from './views/admin/AdminCoursesTab';
import { AdminTopicsTab } from './views/admin/AdminTopicsTab';
import { AdminQuestionsTab } from './views/admin/AdminQuestionsTab';
import { AdminExamsTab } from './views/admin/AdminExamsTab';
import { AdminResultsTab } from './views/admin/AdminResultsTab';
import { AdminScoreboardTab } from './views/admin/AdminScoreboardTab';
import { AdminTeamTab } from './views/admin/AdminTeamTab';
import { AdminSettingsTab } from './views/admin/AdminSettingsTab';
import { AdminContactTab } from './views/admin/AdminContactTab';

const AppContent: React.FC = () => {
  const { currentStudent } = useElearn();

  // Navigation states
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParams, setViewParams] = useState<Record<string, any>>({});
  const [adminTab, setAdminTab] = useState<string>('dashboard');

  // Modal states
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [kvkkOpen, setKvkkOpen] = useState(false);
  const [selectedIp, setSelectedIp] = useState<string | null>(null);

  const handleNavigate = (view: string, params?: Record<string, any>) => {
    setCurrentView(view);
    if (params) setViewParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderAdminTab = () => {
    switch (adminTab) {
      case 'dashboard':
        return <AdminDashboardTab />;
      case 'visitors':
        return <AdminVisitorsTab onSelectIp={(ip) => setSelectedIp(ip)} />;
      case 'login_logs':
        return <AdminLoginLogsTab onSelectIp={(ip) => setSelectedIp(ip)} />;
      case 'register_logs':
        return <AdminRegisterLogsTab />;
      case 'students':
        return <AdminStudentsTab />;
      case 'courses':
        return <AdminCoursesTab />;
      case 'topics':
        return <AdminTopicsTab />;
      case 'questions':
        return <AdminQuestionsTab />;
      case 'exams':
        return <AdminExamsTab />;
      case 'results':
        return <AdminResultsTab />;
      case 'scoreboard':
        return <AdminScoreboardTab />;
      case 'team':
        return <AdminTeamTab />;
      case 'settings':
        return <AdminSettingsTab />;
      case 'contact':
        return <AdminContactTab />;
      default:
        return <AdminDashboardTab />;
    }
  };

  const renderMainView = () => {
    switch (currentView) {
      case 'home':
        return (
          <HomeView
            setCurrentView={handleNavigate}
            onOpenRegister={() => setRegisterOpen(true)}
            onOpenLogin={() => setLoginOpen(true)}
          />
        );
      case 'elearn_catalog':
        return <ElearnCatalogView setCurrentView={handleNavigate} />;
      case 'course_detail':
        return (
          <CourseDetailView
            courseId={viewParams.id || 1}
            setCurrentView={handleNavigate}
          />
        );
      case 'topic':
        return (
          <TopicView
            topicId={viewParams.id || 1}
            setCurrentView={handleNavigate}
          />
        );
      case 'quiz':
        return (
          <QuizView
            topicId={viewParams.id || 1}
            setCurrentView={handleNavigate}
          />
        );
      case 'exam':
        return (
          <ExamView
            examId={viewParams.id || 1}
            setCurrentView={handleNavigate}
          />
        );
      case 'result':
        return (
          <ResultView
            attemptId={viewParams.attemptId || 1}
            setCurrentView={handleNavigate}
          />
        );
      case 'student_profile':
        return (
          <StudentProfileView
            setCurrentView={handleNavigate}
            onOpenLogin={() => setLoginOpen(true)}
          />
        );
      case 'admin_login':
        return <AdminLoginView setCurrentView={handleNavigate} />;
      case 'admin_dashboard':
        return (
          <AdminLayout
            currentTab={adminTab}
            setCurrentTab={setAdminTab}
            setCurrentView={handleNavigate}
          >
            {renderAdminTab()}
          </AdminLayout>
        );
      case 'php_distribution':
        return <PhpDistributionView />;
      default:
        return (
          <HomeView
            setCurrentView={handleNavigate}
            onOpenRegister={() => setRegisterOpen(true)}
            onOpenLogin={() => setLoginOpen(true)}
          />
        );
    }
  };

  const isAdminView = currentView === 'admin_dashboard';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans antialiased">
      {!isAdminView && (
        <Navbar
          currentView={currentView}
          setCurrentView={handleNavigate}
          onOpenLogin={() => setLoginOpen(true)}
          onOpenRegister={() => setRegisterOpen(true)}
        />
      )}
      <main className="flex-1">{renderMainView()}</main>
      {!isAdminView && (
        <Footer
          onOpenKvkk={() => setKvkkOpen(true)}
          setCurrentView={handleNavigate}
        />
      )}

      {/* Global Modals */}
      <AuthModals
        loginOpen={loginOpen}
        registerOpen={registerOpen}
        kvkkOpen={kvkkOpen}
        onCloseLogin={() => setLoginOpen(false)}
        onCloseRegister={() => setRegisterOpen(false)}
        onCloseKvkk={() => setKvkkOpen(false)}
        onSwitchToRegister={() => {
          setLoginOpen(false);
          setRegisterOpen(true);
        }}
        onSwitchToLogin={() => {
          setRegisterOpen(false);
          setLoginOpen(true);
        }}
        onOpenKvkkFromRegister={() => setKvkkOpen(true)}
      />

      <VisitorIpModal
        ipAddress={selectedIp}
        onClose={() => setSelectedIp(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ElearnProvider>
      <AppContent />
    </ElearnProvider>
  );
}
