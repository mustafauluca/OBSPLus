import React from 'react';
import { useElearn } from '../context/ElearnContext';
import { BookOpen, MapPin, Phone, Mail, Clock, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onOpenKvkk: () => void;
  setCurrentView: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenKvkk, setCurrentView }) => {
  const { contactSettings, siteSettings } = useElearn();

  return (
    <footer className="bg-slate-950 text-white mt-auto pt-14 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 mb-12">
          {/* Logo & Hakkımızda */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-lg">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-xl font-black tracking-tight text-white">
                E-LEARN<span className="text-teal-400">.edu</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              {siteSettings.aboutSummary}
            </p>
            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-semibold border border-teal-500/20">
                <ShieldCheck className="w-3.5 h-3.5" /> 6698 Sayılı KVKK Uyumlu Altyapı
              </span>
            </div>
          </div>

          {/* Hızlı Menü */}
          <div className="lg:col-span-2 space-y-3">
            <h6 className="text-xs uppercase font-extrabold text-teal-400 tracking-wider">Hızlı Erişim</h6>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => setCurrentView('home')} className="hover:text-white transition-colors">
                  Ana Sayfa
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('elearn_catalog')} className="hover:text-white transition-colors">
                  Dersler & Konular
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('php_distribution')} className="hover:text-amber-400 transition-colors text-amber-300">
                  PHP Dağıtım Paketi
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('admin_login')} className="hover:text-white transition-colors">
                  Yönetici Girişi
                </button>
              </li>
            </ul>
          </div>

          {/* İletişim Bilgileri */}
          <div className="lg:col-span-3 space-y-3">
            <h6 className="text-xs uppercase font-extrabold text-teal-400 tracking-wider">İletişim & Kampüs</h6>
            <div className="space-y-2 text-xs text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>{contactSettings.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-teal-400 shrink-0" />
                <span className="font-semibold text-slate-200">{contactSettings.phone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                <span>{contactSettings.email}</span>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-400 shrink-0" />
                <span>{contactSettings.workingHours}</span>
              </p>
            </div>
          </div>

          {/* KVKK & Yasal */}
          <div className="lg:col-span-3 space-y-3">
            <h6 className="text-xs uppercase font-extrabold text-teal-400 tracking-wider">KVKK & Güvenlik Politikası</h6>
            <p className="text-slate-400 text-xs leading-relaxed">
              Öğrenci verileri ve sınav sonuçları yüksek güvenlikli şifrelenmiş sunucularda barındırılır. Parolalar asla açık metin tutulmaz ve loglanmaz.
            </p>
            <button
              onClick={onOpenKvkk}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
              KVKK Aydınlatma Metnini İncele
            </button>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>{siteSettings.footerText}</div>
          <div className="flex items-center gap-4 text-slate-500">
            <span>Türkiye Saati: {new Date().toLocaleDateString('tr-TR')} (Europe/Istanbul)</span>
            <span>•</span>
            <span>PHP 8.2 & MySQLi</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
