import React, { useState } from 'react';
import { useElearn } from '../context/ElearnContext';
import { X, LogIn, UserPlus, ShieldCheck, Lock, IdCard, Mail, Phone, CheckCircle, AlertTriangle } from 'lucide-react';

interface AuthModalsProps {
  loginOpen: boolean;
  registerOpen: boolean;
  kvkkOpen: boolean;
  onCloseLogin: () => void;
  onCloseRegister: () => void;
  onCloseKvkk: () => void;
  onSwitchToRegister: () => void;
  onSwitchToLogin: () => void;
  onOpenKvkkFromRegister: () => void;
}

export const AuthModals: React.FC<AuthModalsProps> = ({
  loginOpen,
  registerOpen,
  kvkkOpen,
  onCloseLogin,
  onCloseRegister,
  onCloseKvkk,
  onSwitchToRegister,
  onSwitchToLogin,
  onOpenKvkkFromRegister,
}) => {
  const { loginStudent, registerStudent, siteSettings } = useElearn();

  // Login form state
  const [loginStudentNo, setLoginStudentNo] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Register form state
  const [regStudentNo, setRegStudentNo] = useState('');
  const [regFirstName, setRegFirstName] = useState('');
  const [regLastName, setRegLastName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPasswordConfirm, setRegPasswordConfirm] = useState('');
  const [regKvkk, setRegKvkk] = useState(true);
  const [regScoreboard, setRegScoreboard] = useState(true);
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccess, setRegSuccess] = useState<string | null>(null);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    const res = loginStudent(loginStudentNo, loginPassword);
    if (res.success) {
      onCloseLogin();
      setLoginStudentNo('');
      setLoginPassword('');
    } else {
      setLoginError(res.message);
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccess(null);

    const res = registerStudent({
      studentNo: regStudentNo,
      firstName: regFirstName,
      lastName: regLastName,
      email: regEmail,
      phone: regPhone,
      password: regPassword,
      passwordConfirm: regPasswordConfirm,
      kvkkAccepted: regKvkk,
      allowScoreboard: regScoreboard,
    });

    if (res.success) {
      setRegSuccess('Kaydınız başarıyla tamamlandı! Giriş yapabilirsiniz.');
      setTimeout(() => {
        onCloseRegister();
      }, 1200);
    } else {
      setRegError(res.message);
    }
  };

  return (
    <>
      {/* 1. ÖĞRENCİ GİRİŞ MODALİ */}
      {loginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <LogIn className="w-5 h-5 text-teal-400" />
                <h3 className="font-bold text-base text-white">Öğrenci Giriş Portali</h3>
              </div>
              <button onClick={onCloseLogin} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
              {loginError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Öğrenci Numarası
                </label>
                <div className="relative">
                  <IdCard className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={loginStudentNo}
                    onChange={(e) => setLoginStudentNo(e.target.value)}
                    placeholder="Örn: 202610101"
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Örnek öğrenci: <code>202610101</code></p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Şifre
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Örnek şifre: <code>123456</code> veya min 6 karakter</p>
              </div>

              <div className="flex items-center justify-between text-xs">
                <label className="flex items-center gap-1.5 text-slate-600 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-slate-300 text-teal-600 focus:ring-teal-500" />
                  <span>Beni Hatırla</span>
                </label>
                <button
                  type="button"
                  onClick={() => alert('Şifre sıfırlama için lütfen Öğrenci İşleri ile iletişime geçiniz: 0 541 914 12 48')}
                  className="text-teal-600 hover:text-teal-700 font-semibold"
                >
                  Şifremi Unuttum
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                Giriş Yap
              </button>

              <div className="text-center pt-2 border-t border-slate-100 text-xs text-slate-600">
                Hesabınız yok mu?{' '}
                <button
                  type="button"
                  onClick={onSwitchToRegister}
                  className="text-teal-600 font-bold hover:underline"
                >
                  Şimdi Kayıt Olun
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. ÖĞRENCİ KAYIT MODALİ */}
      {registerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-teal-400" />
                <h3 className="font-bold text-base text-white">Yeni Öğrenci Kayıt Formu</h3>
              </div>
              <button onClick={onCloseRegister} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="p-6 space-y-4">
              {regError && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}
              {regSuccess && (
                <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>{regSuccess}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Öğrenci Numarası <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regStudentNo}
                    onChange={(e) => setRegStudentNo(e.target.value)}
                    placeholder="Örn: 202610109"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    E-Posta Adresi <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="ad@ogrenci.edu.tr"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Adınız <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regFirstName}
                    onChange={(e) => setRegFirstName(e.target.value)}
                    placeholder="Adınız"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Soyadınız <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regLastName}
                    onChange={(e) => setRegLastName(e.target.value)}
                    placeholder="Soyadınız"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Telefon Numarası (İsteğe Bağlı)
                </label>
                <input
                  type="tel"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="05XXXXXXXXX"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Şifre <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="En az 6 karakter"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Şifre Tekrarı <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={regPasswordConfirm}
                    onChange={(e) => setRegPasswordConfirm(e.target.value)}
                    placeholder="Şifreyi tekrar edin"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={regKvkk}
                    onChange={(e) => setRegKvkk(e.target.checked)}
                    required
                    className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>
                    6698 Sayılı{' '}
                    <button
                      type="button"
                      onClick={onOpenKvkkFromRegister}
                      className="text-teal-600 underline font-semibold"
                    >
                      KVKK Aydınlatma Metnini
                    </button>{' '}
                    okudum, kişisel verilerimin işlenmesini onaylıyorum.
                  </span>
                </label>

                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={regScoreboard}
                    onChange={(e) => setRegScoreboard(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>
                    Sınav başarı sıralamasında (Skorboard) maskelenmiş adımın gösterilmesine izin veriyorum (Örn: Ahmet Y.).
                  </span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                Kaydı Tamamla & Giriş Yap
              </button>

              <div className="text-center pt-2 text-xs text-slate-600">
                Zaten hesabınız var mı?{' '}
                <button
                  type="button"
                  onClick={onSwitchToLogin}
                  className="text-teal-600 font-bold hover:underline"
                >
                  Giriş Yapın
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. KVKK AYDINLATMA METNİ MODALİ */}
      {kvkkOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-teal-400" />
                <h3 className="font-bold text-base text-white">KVKK Aydınlatma Metni</h3>
              </div>
              <button onClick={onCloseKvkk} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-3 text-xs text-slate-600 leading-relaxed max-h-[70vh] overflow-y-auto">
              <h5 className="font-bold text-slate-900 text-sm">1. Veri Sorumlusu ve Kapsam</h5>
              <p>{siteSettings.kvkkText}</p>

              <h5 className="font-bold text-slate-900 text-sm">2. Veri Saklama ve İmha Politikası</h5>
              <p>
                Platformumuzda tutulan IP adresleri, sayfa ziyaretleri, giriş logları ve sınav girişimleri azami{' '}
                <strong>{siteSettings.dataRetentionDays} gün</strong> süreyle saklanır. Süre bitiminde kayıtlar otomatik olarak anonimleştirilir veya güvenli yöntemlerle imha edilir.
              </p>

              <h5 className="font-bold text-slate-900 text-sm">3. Parola ve Kimlik Güvenliği</h5>
              <p>
                Kullanıcı şifreleri veritabanında hiçbir koşulda açık metin olarak tutulmaz; endüstri standardı olan tek yönlü <code>password_hash()</code> (bcrypt) algoritması ile korunur. Giriş denemelerinde girilen parolalar asla log dosyalarına yazılmaz.
              </p>

              <h5 className="font-bold text-slate-900 text-sm">4. Başarı Sıralaması (Skorboard) Gizliliği</h5>
              <p>
                Kamuya açık ana sayfadaki ders sıralamasında soyadlar sadece ilk harf olarak maskelenir (Örn: <code>Ahmet Y. – 985 Puan</code>). Öğrencinin açık rızası olmadan hiçbir sıralama listesinde adı yayınlanmaz.
              </p>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={onCloseKvkk}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg"
              >
                Okudum, Anladım
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
