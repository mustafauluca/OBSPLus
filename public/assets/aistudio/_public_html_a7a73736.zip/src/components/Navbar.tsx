import React, { useState } from 'react';
import { useElearn } from '../context/ElearnContext';
import {
  GraduationCap,
  BookOpen,
  Trophy,
  Users,
  Phone,
  Lock,
  User,
  LogOut,
  FolderCode,
  Menu,
  X,
  FileText
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string, params?: Record<string, any>) => void;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  onOpenLogin,
  onOpenRegister,
}) => {
  const { currentStudent, logoutStudent, isAdminLoggedIn, contactSettings } = useElearn();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      {/* Üst Bilgi Şeridi */}
      <div className="bg-slate-950 text-slate-300 text-xs py-1.5 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-teal-400 font-semibold">
              <GraduationCap className="w-3.5 h-3.5" /> E-LEARN Öğrenci Eğitim & Sınav Platformu
            </span>
            <span className="text-slate-600 hidden sm:inline">|</span>
            <span className="text-slate-400 hidden sm:inline flex items-center gap-1">
              <Phone className="w-3 h-3 text-teal-400" /> {contactSettings.phone}
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <button
              onClick={() => setCurrentView('php_distribution')}
              className={`flex items-center gap-1 font-semibold transition-colors ${
                currentView === 'php_distribution' ? 'text-amber-400' : 'text-slate-300 hover:text-amber-300'
              }`}
            >
              <FolderCode className="w-3.5 h-3.5 text-amber-400" /> PHP Sunucu Dağıtım Paketi
            </button>
            <span className="text-slate-700">|</span>
            {isAdminLoggedIn ? (
              <button
                onClick={() => setCurrentView('admin_dashboard')}
                className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
              >
                <Lock className="w-3 h-3" /> Yönetim Paneli Açık
              </button>
            ) : (
              <button
                onClick={() => setCurrentView('admin_login')}
                className="text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
              >
                <Lock className="w-3 h-3" /> Yönetici Girişi
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Ana Gezinme Çubuğu */}
      <nav className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-2.5 text-left focus:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight text-white">
                E-LEARN<span className="text-teal-400">.edu</span>
              </span>
              <span className="block text-[10px] text-slate-400 -mt-1 font-medium">Akademik Ölçme Portali</span>
            </div>
          </button>

          {/* Masaüstü Linkler */}
          <div className="hidden md:flex items-center gap-6 text-sm font-semibold">
            <button
              onClick={() => setCurrentView('home')}
              className={`transition-colors ${currentView === 'home' ? 'text-teal-400 font-bold' : 'text-slate-300 hover:text-white'}`}
            >
              Ana Sayfa
            </button>
            <button
              onClick={() => setCurrentView('elearn_catalog')}
              className={`transition-colors ${currentView === 'elearn_catalog' ? 'text-teal-400 font-bold' : 'text-slate-300 hover:text-white'}`}
            >
              Dersler & Konular
            </button>
            <button
              onClick={() => {
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('skorboard')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Skorboard
            </button>
            <button
              onClick={() => {
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('ekip')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-slate-300 hover:text-white transition-colors"
            >
              Akademik Ekip
            </button>
            <button
              onClick={() => {
                setCurrentView('home');
                setTimeout(() => {
                  document.getElementById('iletisim')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="text-slate-300 hover:text-white transition-colors"
            >
              İletişim
            </button>
          </div>

          {/* Sağ Butonlar */}
          <div className="hidden md:flex items-center gap-3">
            {currentStudent ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentView('student_profile')}
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 font-semibold text-xs border border-slate-700 flex items-center gap-1.5"
                >
                  <User className="w-3.5 h-3.5 text-teal-400" />
                  {currentStudent.firstName} (Puan: {currentStudent.totalScore})
                </button>
                <button
                  onClick={logoutStudent}
                  className="px-2.5 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-300 text-xs font-semibold border border-red-800/50"
                  title="Oturumu Kapat"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenLogin}
                  className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs border border-slate-700 transition-colors"
                >
                  Öğrenci Girişi
                </button>
                <button
                  onClick={onOpenRegister}
                  className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-sm transition-colors"
                >
                  Kayıt Ol
                </button>
              </div>
            )}
          </div>

          {/* Mobil Menü Butonu */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-400 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobil Menü Açılır Panel */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 py-4 space-y-3">
            <button
              onClick={() => { setCurrentView('home'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-1 text-slate-300 hover:text-teal-400 font-semibold"
            >
              Ana Sayfa
            </button>
            <button
              onClick={() => { setCurrentView('elearn_catalog'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-1 text-slate-300 hover:text-teal-400 font-semibold"
            >
              Dersler & Konular
            </button>
            <button
              onClick={() => { setCurrentView('php_distribution'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-1 text-amber-400 font-semibold"
            >
              PHP Sunucu Dağıtım Paketi
            </button>

            <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
              {currentStudent ? (
                <>
                  <button
                    onClick={() => { setCurrentView('student_profile'); setMobileMenuOpen(false); }}
                    className="w-full py-2 bg-slate-800 rounded-lg text-teal-300 text-xs font-bold text-center"
                  >
                    Profilim ({currentStudent.firstName})
                  </button>
                  <button
                    onClick={() => { logoutStudent(); setMobileMenuOpen(false); }}
                    className="w-full py-2 bg-red-950 text-red-300 rounded-lg text-xs font-bold text-center"
                  >
                    Çıkış Yap
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => { onOpenLogin(); setMobileMenuOpen(false); }}
                    className="w-full py-2 bg-slate-800 rounded-lg text-white text-xs font-semibold"
                  >
                    Öğrenci Girişi
                  </button>
                  <button
                    onClick={() => { onOpenRegister(); setMobileMenuOpen(false); }}
                    className="w-full py-2 bg-teal-600 rounded-lg text-white text-xs font-bold"
                  >
                    Kayıt Ol
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </nav>
    </>
  );
};
