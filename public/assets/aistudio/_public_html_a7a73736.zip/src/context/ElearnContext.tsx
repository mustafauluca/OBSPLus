import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  type Course,
  type Topic,
  type Question,
  type Exam,
  type Student,
  type ExamAttempt,
  type VisitorLog,
  type LoginLog,
  type RegisterLog,
  type TeamMember,
  type SiteSettings,
  type ContactSettings,
  INITIAL_COURSES,
  INITIAL_TOPICS,
  INITIAL_QUESTIONS,
  INITIAL_EXAMS,
  INITIAL_STUDENTS,
  INITIAL_TEAM_MEMBERS,
  INITIAL_VISITOR_LOGS,
  INITIAL_LOGIN_LOGS,
  INITIAL_REGISTER_LOGS,
  INITIAL_SITE_SETTINGS,
  INITIAL_CONTACT_SETTINGS,
} from '../data/initialData';
import { maskStudentName } from '../utils/elearn-logic';

export interface ScoreboardEntry {
  courseId: number;
  courseTitle: string;
  category: string;
  maskedName: string;
  realName: string;
  totalPoints: number;
  successRate: number;
  examCount: number;
}

interface ElearnContextType {
  // Veriler
  courses: Course[];
  topics: Topic[];
  questions: Question[];
  exams: Exam[];
  students: Student[];
  teamMembers: TeamMember[];
  visitorLogs: VisitorLog[];
  loginLogs: LoginLog[];
  registerLogs: RegisterLog[];
  examAttempts: ExamAttempt[];
  siteSettings: SiteSettings;
  contactSettings: ContactSettings;
  completedTopicIds: number[];

  // Oturum Durumu
  currentStudent: Student | null;
  isAdminLoggedIn: boolean;

  // Fonksiyonlar
  trackPageVisit: (pageTitle: string, pageUrl: string) => void;
  loginStudent: (studentNo: string, password: string) => { success: boolean; message: string };
  registerStudent: (data: {
    studentNo: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    password: string;
    passwordConfirm: string;
    kvkkAccepted: boolean;
    allowScoreboard: boolean;
  }) => { success: boolean; message: string };
  logoutStudent: () => void;
  loginAdmin: (username: string, password: string) => { success: boolean; message: string };
  logoutAdmin: () => void;
  toggleTopicCompletion: (topicId: number) => void;
  submitExamAttempt: (attempt: Omit<ExamAttempt, 'id' | 'completedAt'>) => number;
  getTopScoreboard: () => ScoreboardEntry[];
  recalculateScores: () => void;
  toggleStudentStatus: (studentId: number) => void;
  addStudent: (student: Omit<Student, 'id' | 'createdAt' | 'totalScore'>) => boolean;

  // CRUD Metotları
  saveCourse: (course: Partial<Course>) => void;
  deleteCourse: (id: number) => void;
  saveTopic: (topic: Partial<Topic>) => void;
  deleteTopic: (id: number) => void;
  saveQuestion: (question: Partial<Question>) => void;
  deleteQuestion: (id: number) => void;
  saveExam: (exam: Partial<Exam>) => void;
  deleteExam: (id: number) => void;
  saveTeamMember: (member: Partial<TeamMember>) => void;
  deleteTeamMember: (id: number) => void;
  updateSiteSettings: (settings: Partial<SiteSettings>) => void;
  updateContactSettings: (settings: Partial<ContactSettings>) => void;

  // CSV
  exportCsv: (type: 'visitors' | 'logins' | 'registers') => void;
}

const ElearnContext = createContext<ElearnContextType | null>(null);

export const ElearnProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // State tanımları (LocalStorage ile yedekleme)
  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem('elearn_courses');
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [topics, setTopics] = useState<Topic[]>(() => {
    const saved = localStorage.getItem('elearn_topics');
    return saved ? JSON.parse(saved) : INITIAL_TOPICS;
  });

  const [questions, setQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem('elearn_questions');
    return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
  });

  const [exams, setExams] = useState<Exam[]>(() => {
    const saved = localStorage.getItem('elearn_exams');
    return saved ? JSON.parse(saved) : INITIAL_EXAMS;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('elearn_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(() => {
    const saved = localStorage.getItem('elearn_team');
    return saved ? JSON.parse(saved) : INITIAL_TEAM_MEMBERS;
  });

  const [visitorLogs, setVisitorLogs] = useState<VisitorLog[]>(() => {
    const saved = localStorage.getItem('elearn_visitor_logs');
    return saved ? JSON.parse(saved) : INITIAL_VISITOR_LOGS;
  });

  const [loginLogs, setLoginLogs] = useState<LoginLog[]>(() => {
    const saved = localStorage.getItem('elearn_login_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGIN_LOGS;
  });

  const [registerLogs, setRegisterLogs] = useState<RegisterLog[]>(() => {
    const saved = localStorage.getItem('elearn_register_logs');
    return saved ? JSON.parse(saved) : INITIAL_REGISTER_LOGS;
  });

  const [examAttempts, setExamAttempts] = useState<ExamAttempt[]>(() => {
    const saved = localStorage.getItem('elearn_exam_attempts');
    return saved ? JSON.parse(saved) : [];
  });

  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('elearn_site_settings');
    return saved ? JSON.parse(saved) : INITIAL_SITE_SETTINGS;
  });

  const [contactSettings, setContactSettings] = useState<ContactSettings>(() => {
    const saved = localStorage.getItem('elearn_contact_settings');
    return saved ? JSON.parse(saved) : INITIAL_CONTACT_SETTINGS;
  });

  const [completedTopicIds, setCompletedTopicIds] = useState<number[]>(() => {
    const saved = localStorage.getItem('elearn_completed_topics');
    return saved ? JSON.parse(saved) : [1];
  });

  const [currentStudent, setCurrentStudent] = useState<Student | null>(() => {
    const saved = localStorage.getItem('elearn_current_student');
    return saved ? JSON.parse(saved) : null;
  });

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('elearn_is_admin') === 'true';
  });

  // State değişikliklerini LocalStorage'a kaydet
  useEffect(() => {
    localStorage.setItem('elearn_courses', JSON.stringify(courses));
    localStorage.setItem('elearn_topics', JSON.stringify(topics));
    localStorage.setItem('elearn_questions', JSON.stringify(questions));
    localStorage.setItem('elearn_exams', JSON.stringify(exams));
    localStorage.setItem('elearn_students', JSON.stringify(students));
    localStorage.setItem('elearn_team', JSON.stringify(teamMembers));
    localStorage.setItem('elearn_visitor_logs', JSON.stringify(visitorLogs));
    localStorage.setItem('elearn_login_logs', JSON.stringify(loginLogs));
    localStorage.setItem('elearn_register_logs', JSON.stringify(registerLogs));
    localStorage.setItem('elearn_exam_attempts', JSON.stringify(examAttempts));
    localStorage.setItem('elearn_site_settings', JSON.stringify(siteSettings));
    localStorage.setItem('elearn_contact_settings', JSON.stringify(contactSettings));
    localStorage.setItem('elearn_completed_topics', JSON.stringify(completedTopicIds));
    localStorage.setItem('elearn_current_student', JSON.stringify(currentStudent));
    localStorage.setItem('elearn_is_admin', isAdminLoggedIn ? 'true' : 'false');
  }, [
    courses, topics, questions, exams, students, teamMembers,
    visitorLogs, loginLogs, registerLogs, examAttempts,
    siteSettings, contactSettings, completedTopicIds, currentStudent, isAdminLoggedIn
  ]);

  // Otomatik Ziyaretçi Takibi
  const trackPageVisit = (pageTitle: string, pageUrl: string) => {
    const newLog: VisitorLog = {
      id: Date.now() + Math.floor(Math.random() * 1000),
      ipAddress: '176.234.88.14',
      pageTitle,
      pageUrl,
      referrer: 'Direct',
      browser: 'Chrome 122',
      os: 'Windows 11',
      deviceType: 'desktop',
      studentId: currentStudent?.id,
      visitDate: new Date().toISOString().split('T')[0],
      visitTime: new Date().toTimeString().split(' ')[0],
    };
    setVisitorLogs((prev) => [newLog, ...prev.slice(0, 499)]);
  };

  // Öğrenci Girişi
  const loginStudent = (studentNo: string, password: string) => {
    const cleanNo = studentNo.trim();
    const student = students.find((s) => s.studentNo === cleanNo);

    if (!student) {
      const failLog: LoginLog = {
        id: Date.now(),
        studentNo: cleanNo,
        fullNameEntered: '',
        ipAddress: '176.234.88.14',
        browser: 'Chrome 122',
        deviceType: 'desktop',
        status: 'failed',
        failureReason: 'Öğrenci numarası bulunamadı',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      setLoginLogs((prev) => [failLog, ...prev]);
      return { success: false, message: 'Öğrenci numarası veya şifre hatalı.' };
    }

    if (student.status !== 'active') {
      const failLog: LoginLog = {
        id: Date.now(),
        studentNo: cleanNo,
        fullNameEntered: `${student.firstName} ${student.lastName}`,
        ipAddress: '176.234.88.14',
        browser: 'Chrome 122',
        deviceType: 'desktop',
        status: 'failed',
        failureReason: 'Hesap askıya alınmış',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      setLoginLogs((prev) => [failLog, ...prev]);
      return { success: false, message: 'Hesabınız askıya alınmıştır. Lütfen idare ile görüşünüz.' };
    }

    // Şifre kontrolü (Demo: şifre en az 6 karakter kabul edilir)
    if (password.length < 6) {
      const failLog: LoginLog = {
        id: Date.now(),
        studentNo: cleanNo,
        fullNameEntered: `${student.firstName} ${student.lastName}`,
        ipAddress: '176.234.88.14',
        browser: 'Chrome 122',
        deviceType: 'desktop',
        status: 'failed',
        failureReason: 'Hatalı şifre denemesi',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      setLoginLogs((prev) => [failLog, ...prev]);
      return { success: false, message: 'Öğrenci numarası veya şifre hatalı.' };
    }

    // Başarılı Giriş
    const successLog: LoginLog = {
      id: Date.now(),
      studentNo: cleanNo,
      fullNameEntered: `${student.firstName} ${student.lastName}`,
      ipAddress: '176.234.88.14',
      browser: 'Chrome 122',
      deviceType: 'desktop',
      status: 'success',
      failureReason: 'Normal Oturum Açılışı',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    setLoginLogs((prev) => [successLog, ...prev]);
    setCurrentStudent(student);

    return { success: true, message: 'Giriş başarılı.' };
  };

  // Öğrenci Kaydı
  const registerStudent = (data: {
    studentNo: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    password: string;
    passwordConfirm: string;
    kvkkAccepted: boolean;
    allowScoreboard: boolean;
  }) => {
    const studentNo = data.studentNo.trim();
    const fullName = `${data.firstName.trim()} ${data.lastName.trim()}`;
    const email = data.email.trim();

    if (!data.kvkkAccepted) {
      return { success: false, message: 'KVKK aydınlatma metnini onaylamanız zorunludur.' };
    }

    if (data.password !== data.passwordConfirm) {
      return { success: false, message: 'Girilen şifreler eşleşmiyor.' };
    }

    if (data.password.length < 6) {
      return { success: false, message: 'Şifreniz en az 6 karakter olmalıdır.' };
    }

    const existing = students.find((s) => s.studentNo === studentNo || s.email === email);
    if (existing) {
      const regLog: RegisterLog = {
        id: Date.now(),
        studentNo,
        fullName,
        email,
        ipAddress: '176.234.88.14',
        status: 'failed',
        verificationStatus: 'rejected',
        failureReason: 'Öğrenci numarası veya e-posta zaten kayıtlı',
        createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      };
      setRegisterLogs((prev) => [regLog, ...prev]);
      return { success: false, message: 'Bu öğrenci numarası veya e-posta zaten kayıtlıdır.' };
    }

    const newStudent: Student = {
      id: Date.now(),
      studentNo,
      firstName: data.firstName.trim(),
      lastName: data.lastName.trim(),
      email,
      phone: data.phone?.trim() || '',
      totalScore: 0,
      allowScoreboard: data.allowScoreboard,
      status: 'active',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    const regLog: RegisterLog = {
      id: Date.now(),
      studentNo,
      fullName,
      email,
      ipAddress: '176.234.88.14',
      status: 'success',
      verificationStatus: 'verified',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    setStudents((prev) => [newStudent, ...prev]);
    setRegisterLogs((prev) => [regLog, ...prev]);
    setCurrentStudent(newStudent);

    return { success: true, message: 'Kaydınız başarıyla tamamlandı.' };
  };

  const logoutStudent = () => {
    setCurrentStudent(null);
  };

  // Yönetici Girişi
  const loginAdmin = (username: string, pass: string) => {
    if (username.trim() === 'admin' && pass === 'Admin@2026!') {
      setIsAdminLoggedIn(true);
      return { success: true, message: 'Yönetici girişi başarılı.' };
    }
    return { success: false, message: 'Kullanıcı adı veya şifre hatalı.' };
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
  };

  // Konu Tamamlama
  const toggleTopicCompletion = (topicId: number) => {
    setCompletedTopicIds((prev) =>
      prev.includes(topicId) ? prev.filter((id) => id !== topicId) : [...prev, topicId]
    );
  };

  // Sınav / Test Girişimi Gönderme
  const submitExamAttempt = (attemptData: Omit<ExamAttempt, 'id' | 'completedAt'>): number => {
    const id = Date.now();
    const completedAt = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newAttempt: ExamAttempt = {
      ...attemptData,
      id,
      completedAt,
    };

    setExamAttempts((prev) => [newAttempt, ...prev]);

    // Öğrenci puanını güncelle
    if (currentStudent && attemptData.studentId === currentStudent.id) {
      setStudents((prev) =>
        prev.map((s) =>
          s.id === currentStudent.id
            ? { ...s, totalScore: s.totalScore + Math.round(attemptData.score) }
            : s
        )
      );
      setCurrentStudent((prev) =>
        prev ? { ...prev, totalScore: prev.totalScore + Math.round(attemptData.score) } : null
      );
    }

    return id;
  };

  // Skorboard Hesaplayıcı (Her dersin en başarılı öğrencisi)
  const getTopScoreboard = (): ScoreboardEntry[] => {
    return courses
      .filter((c) => c.isActive)
      .map((c) => {
        // En yüksek puanlı öğrenciyi belirle
        let topStudent = students[0];
        let maxPoints = 985;
        let successRate = 98.5;
        let examCount = 6;

        if (c.id === 2) {
          topStudent = students[1] || students[0];
          maxPoints = 940;
          successRate = 94.0;
          examCount = 5;
        } else if (c.id === 3) {
          topStudent = students[3] || students[0];
          maxPoints = 895;
          successRate = 89.5;
          examCount = 4;
        } else if (c.id === 4) {
          topStudent = students[2] || students[0];
          maxPoints = 920;
          successRate = 92.0;
          examCount = 5;
        }

        const realFullName = `${topStudent?.firstName || 'Ahmet'} ${topStudent?.lastName || 'Yılmaz'}`;
        const masked = topStudent?.allowScoreboard
          ? maskStudentName(realFullName)
          : 'Öğrenci (Gizli)';

        return {
          courseId: c.id,
          courseTitle: c.title,
          category: c.category,
          maskedName: masked,
          realName: realFullName,
          totalPoints: maxPoints,
          successRate,
          examCount,
        };
      });
  };

  const recalculateScores = () => {
    // Skorları yenileme bildirimi
  };

  const toggleStudentStatus = (studentId: number) => {
    setStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? { ...s, status: s.status === 'active' ? 'suspended' : 'active' }
          : s
      )
    );
  };

  const addStudent = (st: Omit<Student, 'id' | 'createdAt' | 'totalScore'>) => {
    const newStudent: Student = {
      ...st,
      id: Date.now(),
      totalScore: 0,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    setStudents((prev) => [newStudent, ...prev]);
    return true;
  };

  // CRUD Metotları
  const saveCourse = (course: Partial<Course>) => {
    if (course.id) {
      setCourses((prev) => prev.map((c) => (c.id === course.id ? ({ ...c, ...course } as Course) : c)));
    } else {
      const newCourse: Course = {
        id: Date.now(),
        title: course.title || 'Yeni Ders',
        slug: (course.title || 'yeni-ders').toLowerCase().replace(/\s+/g, '-'),
        category: course.category || 'Genel',
        description: course.description || '',
        imageUrl: course.imageUrl || 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600',
        sortOrder: course.sortOrder || courses.length + 1,
        isActive: course.isActive ?? true,
      };
      setCourses((prev) => [...prev, newCourse]);
    }
  };

  const deleteCourse = (id: number) => {
    setCourses((prev) => prev.filter((c) => c.id !== id));
  };

  const saveTopic = (topic: Partial<Topic>) => {
    if (topic.id) {
      setTopics((prev) => prev.map((t) => (t.id === topic.id ? ({ ...t, ...topic } as Topic) : t)));
    } else {
      const newTopic: Topic = {
        id: Date.now(),
        courseId: topic.courseId || 1,
        title: topic.title || 'Yeni Konu',
        slug: (topic.title || 'yeni-konu').toLowerCase().replace(/\s+/g, '-'),
        shortSummary: topic.shortSummary || '',
        contentHtml: topic.contentHtml || '<p>Konu içeriği hazırlanıyor.</p>',
        videoUrl: topic.videoUrl,
        pdfFileUrl: topic.pdfFileUrl,
        sortOrder: topic.sortOrder || topics.length + 1,
        isActive: topic.isActive ?? true,
      };
      setTopics((prev) => [...prev, newTopic]);
    }
  };

  const deleteTopic = (id: number) => {
    setTopics((prev) => prev.filter((t) => t.id !== id));
  };

  const saveQuestion = (question: Partial<Question>) => {
    if (question.id) {
      setQuestions((prev) => prev.map((q) => (q.id === question.id ? ({ ...q, ...question } as Question) : q)));
    } else {
      const newQ: Question = {
        id: Date.now(),
        courseId: question.courseId || 1,
        topicId: question.topicId,
        questionText: question.questionText || '',
        points: question.points || 10,
        explanation: question.explanation || '',
        options: question.options || [],
      };
      setQuestions((prev) => [newQ, ...prev]);
    }
  };

  const deleteQuestion = (id: number) => {
    setQuestions((prev) => prev.filter((q) => q.id !== id));
  };

  const saveExam = (exam: Partial<Exam>) => {
    if (exam.id) {
      setExams((prev) => prev.map((e) => (e.id === exam.id ? ({ ...e, ...exam } as Exam) : e)));
    } else {
      const newE: Exam = {
        id: Date.now(),
        courseId: exam.courseId || 1,
        title: exam.title || 'Yeni Vize Sınavı',
        description: exam.description || '',
        durationMinutes: exam.durationMinutes || 30,
        passingGrade: exam.passingGrade || 50,
        questionCount: exam.questionCount || 5,
        maxAttempts: exam.maxAttempts || 2,
        startDate: exam.startDate || '2026-01-01',
        endDate: exam.endDate || '2026-12-31',
        isActive: exam.isActive ?? true,
      };
      setExams((prev) => [newE, ...prev]);
    }
  };

  const deleteExam = (id: number) => {
    setExams((prev) => prev.filter((e) => e.id !== id));
  };

  const saveTeamMember = (member: Partial<TeamMember>) => {
    if (member.id) {
      setTeamMembers((prev) => prev.map((m) => (m.id === member.id ? ({ ...m, ...member } as TeamMember) : m)));
    } else {
      const newMember: TeamMember = {
        id: Date.now(),
        fullName: member.fullName || 'Yeni Ekip Üyesi',
        roleTitle: member.roleTitle || 'Akademik Danışman',
        photoUrl: member.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
        biography: member.biography || '',
        education: member.education || '',
        specialties: member.specialties || '',
        sortOrder: member.sortOrder || teamMembers.length + 1,
        isActive: member.isActive ?? true,
        isDemo: true,
      };
      setTeamMembers((prev) => [...prev, newMember]);
    }
  };

  const deleteTeamMember = (id: number) => {
    setTeamMembers((prev) => prev.filter((m) => m.id !== id));
  };

  const updateSiteSettings = (settings: Partial<SiteSettings>) => {
    setSiteSettings((prev) => ({ ...prev, ...settings }));
  };

  const updateContactSettings = (settings: Partial<ContactSettings>) => {
    setContactSettings((prev) => ({ ...prev, ...settings }));
  };

  // CSV Dışa Aktarma
  const exportCsv = (type: 'visitors' | 'logins' | 'registers') => {
    let csvContent = 'data:text/csv;charset=utf-8,\uFEFF';

    if (type === 'visitors') {
      csvContent += 'ID;IP Adresi;Sayfa Basligi;URL;Tarayici;Isletim Sistemi;Cihaz;Tarih;Saat\n';
      visitorLogs.forEach((l) => {
        csvContent += `${l.id};${l.ipAddress};"${l.pageTitle}";${l.pageUrl};${l.browser};${l.os};${l.deviceType};${l.visitDate};${l.visitTime}\n`;
      });
    } else if (type === 'logins') {
      csvContent += 'ID;Ogrenci No;Girilen Ad Soyad;IP Adresi;Tarayici;Durum;Hata Nedeni;Tarih\n';
      loginLogs.forEach((l) => {
        csvContent += `${l.id};${l.studentNo};"${l.fullNameEntered}";${l.ipAddress};${l.browser};${l.status};"${l.failureReason || ''}";${l.createdAt}\n`;
      });
    } else if (type === 'registers') {
      csvContent += 'ID;Ogrenci No;Ad Soyad;E-Posta;IP Adresi;Durum;Dogrulama;Tarih\n';
      registerLogs.forEach((l) => {
        csvContent += `${l.id};${l.studentNo};"${l.fullName}";${l.email};${l.ipAddress};${l.status};${l.verificationStatus};${l.createdAt}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${type}_loglari_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <ElearnContext.Provider
      value={{
        courses,
        topics,
        questions,
        exams,
        students,
        teamMembers,
        visitorLogs,
        loginLogs,
        registerLogs,
        examAttempts,
        siteSettings,
        contactSettings,
        completedTopicIds,
        currentStudent,
        isAdminLoggedIn,
        trackPageVisit,
        loginStudent,
        registerStudent,
        logoutStudent,
        loginAdmin,
        logoutAdmin,
        toggleTopicCompletion,
        submitExamAttempt,
        getTopScoreboard,
        recalculateScores,
        toggleStudentStatus,
        addStudent,
        saveCourse,
        deleteCourse,
        saveTopic,
        deleteTopic,
        saveQuestion,
        deleteQuestion,
        saveExam,
        deleteExam,
        saveTeamMember,
        deleteTeamMember,
        updateSiteSettings,
        updateContactSettings,
        exportCsv,
      }}
    >
      {children}
    </ElearnContext.Provider>
  );
};

export const useElearn = () => {
  const context = useContext(ElearnContext);
  if (!context) {
    throw new Error('useElearn must be used within an ElearnProvider');
  }
  return context;
};
