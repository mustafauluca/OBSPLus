<?php
/**
 * E-LEARN: Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Ana Sayfa (index.php)
 */

$pageTitle = 'E-LEARN – Yeni Nesil Öğrenci Eğitim ve Sınav Portali';
require_once __DIR__ . '/includes/header.php';

// Flash Mesajları
$flashSuccess = $_SESSION['flash_success'] ?? null;
$flashError = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// Aktif Dersler
$courses = dbSelect("SELECT * FROM courses WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 6");

// Skorboard Verisi
$scoreboard = getTopScoreboard();

// Ekip Üyeleri
$teamMembers = dbSelect("SELECT * FROM team_members WHERE is_active = 1 ORDER BY sort_order ASC");

// İstatistik Sayaçları
$studentCount = dbSelectOne("SELECT COUNT(*) as c FROM students WHERE status = 'active'")['c'] ?? 1420;
$examCount = dbSelectOne("SELECT COUNT(*) as c FROM exam_attempts WHERE status = 'completed'")['c'] ?? 3840;
$courseCount = count($courses);
?>

<main>
  <!-- Bildirim Mesajları -->
  <?php if ($flashSuccess): ?>
    <div class="alert alert-success alert-dismissible fade show m-0 rounded-0 text-center fw-semibold" role="alert">
      <i class="fa-solid fa-circle-check me-2"></i><?php echo e($flashSuccess); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>
  <?php if ($flashError): ?>
    <div class="alert alert-danger alert-dismissible fade show m-0 rounded-0 text-center fw-semibold" role="alert">
      <i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo e($flashError); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <!-- 1. Karşılama Alanı (Hero) -->
  <section class="bg-navy text-white py-5 position-relative overflow-hidden">
    <div class="container py-lg-4">
      <div class="row align-items-center g-5">
        <div class="col-lg-7">
          <div class="d-inline-flex align-items-center gap-2 px-3 py-1 rounded-pill bg-white bg-opacity-10 text-teal small fw-bold mb-3">
            <i class="fa-solid fa-award"></i> Akademik Ölçme ve Değerlendirme Standardı
          </div>
          <h1 class="display-4 fw-black tracking-tight mb-3">
            Geleceğini Şekillendirecek <span class="text-teal">Eğitim ve Sınav</span> Portali
          </h1>
          <p class="lead text-white-50 mb-4">
            Zenginleştirilmiş konu anlatımları, interaktif modül testleri ve online vize sınavları ile akademik başarını en üst seviyeye taşı. Detaylı analizler ve başarı sıralamasıyla gelişimini anlık izle.
          </p>
          <div class="d-flex flex-wrap gap-3">
            <a href="/elearn/" class="btn btn-teal btn-lg px-4 shadow">
              <i class="fa-solid fa-book-open-reader me-2"></i>Eğitime Başla
            </a>
            <?php if (!$isStudent): ?>
              <button class="btn btn-outline-light btn-lg px-4" data-bs-toggle="modal" data-bs-target="#registerModal">
                <i class="fa-solid fa-user-plus me-2"></i>Öğrenci Kaydı
              </button>
            <?php else: ?>
              <a href="/elearn/profile.php" class="btn btn-outline-light btn-lg px-4">
                <i class="fa-solid fa-chart-line me-2"></i>Öğrenci Panelim
              </a>
            <?php endif; ?>
          </div>
        </div>
      
<div class="col-lg-5">
    <div class="p-4 rounded-4 bg-white border shadow-lg text-dark">

        <h5 class="fw-bold mb-4 d-flex align-items-center justify-content-between">
            <span>
                <i class="fa-solid fa-trophy text-warning me-2"></i>
                Öne Çıkan Başarılar
            </span>
            <span class="badge bg-primary small">Canlı Sıralama</span>
        </h5>

        <div class="space-y-3">

            <?php foreach (array_slice($scoreboard, 0, 3) as $sb): ?>

                <div class="d-flex align-items-center justify-content-between p-3 rounded-3 bg-light border mb-2">

                    <div>
                        <div class="small text-secondary mb-1">
                            <?php echo e($sb['course_title']); ?>
                        </div>

                        <div class="fw-bold text-dark">
                            <i class="fa-solid fa-user-graduate text-primary me-1"></i>
                            <?php echo e($sb['masked_name']); ?>
                        </div>
                    </div>

                    <div class="text-end">
                        <span class="badge bg-warning text-dark fw-bold px-3 py-2">
                            <?php echo $sb['total_points']; ?> Puan
                        </span>

                        <div class="small text-success fw-semibold mt-2">
                            %<?php echo number_format($sb['success_rate'], 0); ?> Başarı
                        </div>
                    </div>

                </div>

            <?php endforeach; ?>

            <?php if (empty($scoreboard)): ?>
                <div class="text-center text-secondary py-4">
                    <i class="fa-solid fa-chart-line fa-2x mb-2"></i>
                    <div>Henüz başarı sıralaması bulunmuyor.</div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

      </div>
    </div>
  </section>

  <!-- 2. İstatistikler Bandı -->
  <section class="py-4 bg-white border-bottom shadow-sm">
    <div class="container">
      <div class="row text-center g-4">
        <div class="col-6 col-md-3">
          <div class="fs-2 fw-black text-navy"><?php echo number_format($studentCount); ?>+</div>
          <div class="text-muted small fw-semibold">Kayıtlı Öğrenci</div>
        </div>
        <div class="col-6 col-md-3">
          <div class="fs-2 fw-black text-teal"><?php echo $courseCount; ?></div>
          <div class="text-muted small fw-semibold">Aktif Eğitim Programı</div>
        </div>
        <div class="col-6 col-md-3">
          <div class="fs-2 fw-black text-primary"><?php echo number_format($examCount); ?>+</div>
          <div class="text-muted small fw-semibold">Tamamlanan Sınav</div>
        </div>
        <div class="col-6 col-md-3">
          <div class="fs-2 fw-black text-success">%94.2</div>
          <div class="text-muted small fw-semibold">Öğrenci Memnuniyeti</div>
        </div>
      </div>
    </div>
  </section>

  <!-- 3. Aktif Dersler ve Eğitim Modülleri -->
  <section class="py-5" id="dersler">
    <div class="container">
      <div class="text-center max-w-xl mx-auto mb-5">
        <span class="badge bg-primary-subtle text-primary fw-bold text-uppercase px-3 py-1 rounded-pill">Müfredat</span>
        <h2 class="fw-bold text-navy mt-2">Aktif Eğitim Dersleri</h2>
        <p class="text-muted">Alanında uzman akademisyenler tarafından hazırlanan güncel ders modülleri ve interaktif testler.</p>
      </div>

      <div class="row g-4">
        <?php foreach ($courses as $c): ?>
          <div class="col-lg-3 col-md-6">
            <div class="card h-100 border-0 shadow-sm scoreboard-card overflow-hidden">
              <img src="<?php echo e($c['image_url'] ?: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600'); ?>" class="card-img-top" style="height: 180px; object-fit: cover;" alt="<?php echo e($c['title']); ?>">
              <div class="card-body d-flex flex-column">
                <div class="badge bg-secondary-subtle text-secondary small align-self-start mb-2"><?php echo e($c['category']); ?></div>
                <h5 class="card-title fw-bold text-navy fs-6"><?php echo e($c['title']); ?></h5>
                <p class="card-text text-muted small flex-grow-1"><?php echo e(mb_strimwidth($c['description'] ?? '', 0, 90, '...')); ?></p>
                <div class="d-flex align-items-center justify-content-between pt-3 border-top mt-2">
                  <a href="/elearn/course.php?id=<?php echo $c['id']; ?>" class="btn btn-outline-primary btn-sm fw-bold w-100">
                    Dersi İncele & Test Çöz →
                  </a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- 4. Skorboard (Her Dersin En Başarılı Öğrencisi) -->
  <section class="py-5 bg-white border-top border-bottom" id="skorboard">
    <div class="container">
      <div class="text-center max-w-xl mx-auto mb-5">
        <span class="badge bg-warning-subtle text-warning-emphasis fw-bold text-uppercase px-3 py-1 rounded-pill">
          <i class="fa-solid fa-medal me-1"></i> Akademik Başarı
        </span>
        <h2 class="fw-bold text-navy mt-2">Ders Bazlı Skorboard (Liderler Tablosu)</h2>
        <p class="text-muted">Her dersin en başarılı öğrencisi. Kişisel veriler KVKK ilkeleri uyarınca maskelenmiştir.</p>
      </div>

      <div class="row g-4 justify-content-center">
        <?php if (empty($scoreboard)): ?>
          <div class="col-12 text-center text-muted py-4">Henüz yayınlanmış bir sınav derecesi bulunmamaktadır.</div>
        <?php else: ?>
          <?php foreach ($scoreboard as $index => $sb): ?>
            <div class="col-lg-3 col-md-6">
              <div class="card h-100 scoreboard-card border-0 shadow-sm p-3 bg-light position-relative">
                <div class="position-absolute top-0 end-0 p-3">
                  <span class="badge rounded-pill bg-warning text-dark fw-bold">#1 Lider</span>
                </div>
                <div class="text-muted small text-uppercase fw-bold"><?php echo e($sb['category']); ?></div>
                <h5 class="fw-bold text-navy mt-1"><?php echo e($sb['course_title']); ?></h5>
                
                <div class="d-flex align-items-center gap-3 my-3 p-3 bg-white rounded-3 shadow-xs border">
                  <div class="avatar-circle bg-navy text-white rounded-circle d-flex align-items-center justify-content-center fw-bold fs-5" style="width: 48px; height: 48px;">
                    <?php echo mb_substr($sb['masked_name'], 0, 1); ?>
                  </div>
                  <div>
                    <div class="fw-bold text-navy fs-6"><?php echo e($sb['masked_name']); ?></div>
                    <div class="small text-muted"><?php echo $sb['exam_count']; ?> Sınav Tamamlandı</div>
                  </div>
                </div>

                <div class="d-flex justify-content-between text-center pt-2 border-top">
                  <div>
                    <div class="small text-muted">Toplam Puan</div>
                    <div class="fw-black text-primary fs-5"><?php echo $sb['total_points']; ?></div>
                  </div>
                  <div>
                    <div class="small text-muted">Başarı Oranı</div>
                    <div class="fw-black text-success fs-5">%<?php echo number_format($sb['success_rate'], 1); ?></div>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- 5. Akademik Ekip -->
  <section class="py-5" id="ekip">
    <div class="container">
      <div class="text-center max-w-xl mx-auto mb-5">
        <span class="badge bg-info-subtle text-info-emphasis fw-bold text-uppercase px-3 py-1 rounded-pill">Kadro</span>
        <h2 class="fw-bold text-navy mt-2">Eğitim ve Ölçme Heyetimiz</h2>
        <p class="text-muted small">Temsili / demo kadro profilleri. Müfredat ve sınav sistemini yöneten uzman heyet.</p>
      </div>

      <div class="row g-4">
        <?php foreach ($teamMembers as $m): ?>
          <div class="col-lg-4 col-md-6">
            <div class="card h-100 border-0 shadow-sm scoreboard-card p-3">
              <div class="d-flex align-items-center gap-3 mb-3">
                <img src="<?php echo e($m['photo_url'] ?: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400'); ?>" class="rounded-circle object-fit-cover border border-2 border-primary" style="width: 70px; height: 70px;" alt="<?php echo e($m['full_name']); ?>">
                <div>
                  <h5 class="fw-bold text-navy mb-0 fs-6"><?php echo e($m['full_name']); ?></h5>
                  <div class="badge bg-primary-subtle text-primary small mt-1"><?php echo e($m['role_title']); ?></div>
                </div>
              </div>
              <p class="small text-muted flex-grow-1"><?php echo e($m['biography']); ?></p>
              <div class="small border-top pt-2 mt-2">
                <span class="text-muted fw-bold">Eğitim:</span> <span class="text-secondary"><?php echo e($m['education']); ?></span>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- 6. İletişim Bölümü -->
  <section class="py-5 bg-white border-top" id="iletisim">
    <div class="container">
      <div class="row g-5 align-items-center">
        <div class="col-lg-6">
          <span class="badge bg-teal-subtle text-teal fw-bold text-uppercase px-3 py-1 rounded-pill">Bize Ulaşın</span>
          <h2 class="fw-bold text-navy mt-2">Öğrenci Destek & Akademik Danışma</h2>
          <p class="text-muted">Kayıt, intibak, ders seçimleri veya sınav sistemi ile ilgili her türlü sorunuzda danışman heyetimiz yanınızda.</p>
          
          <div class="space-y-3 mt-4">
            <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-2">
              <div class="fs-4 text-teal"><i class="fa-solid fa-phone"></i></div>
              <div>
                <div class="small text-muted fw-semibold">Telefon Hattı</div>
                <div class="fw-bold text-navy"><?php echo e($contact['phone']); ?></div>
              </div>
            </div>
            <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-2">
              <div class="fs-4 text-teal"><i class="fa-solid fa-envelope"></i></div>
              <div>
                <div class="small text-muted fw-semibold">E-Posta</div>
                <div class="fw-bold text-navy"><?php echo e($contact['email']); ?></div>
              </div>
            </div>
            <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-3 mb-2">
              <div class="fs-4 text-teal"><i class="fa-solid fa-location-dot"></i></div>
              <div>
                <div class="small text-muted fw-semibold">Kampüs & Ofis</div>
                <div class="fw-bold text-navy"><?php echo e($contact['address']); ?></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="card border-0 shadow-lg p-4 rounded-4">
            <h4 class="fw-bold text-navy mb-3">Hızlı Mesaj Gönder</h4>
            <form onsubmit="alert('Mesajınız başarıyla iletildi. En kısa sürede geri dönüş yapılacaktır.'); this.reset(); return false;">
              <div class="mb-3">
                <label class="form-label small fw-semibold">Adınız Soyadınız</label>
                <input type="text" class="form-control" required placeholder="Adınız Soyadınız">
              </div>
              <div class="mb-3">
                <label class="form-label small fw-semibold">E-Posta Adresiniz</label>
                <input type="email" class="form-control" required placeholder="ad@ornek.com">
              </div>
              <div class="mb-3">
                <label class="form-label small fw-semibold">Mesajınız</label>
                <textarea class="form-control" rows="4" required placeholder="Sorunuz veya talebiniz..."></textarea>
              </div>
              <button type="submit" class="btn btn-teal w-100 fw-bold py-2.5">
                <i class="fa-solid fa-paper-plane me-2"></i>Mesajı Gönder
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
