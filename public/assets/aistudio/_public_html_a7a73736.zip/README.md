# E-LEARN: Öğrenci Eğitim, Sınav ve İstatistik Platformu

Bu proje; modüler PHP 8.2+, MySQLi mimarisi, Bootstrap 5 ve Chart.js ile geliştirilmiş kurumsal düzeyde bir eğitim, sınav ve analitik platformudur.

---

## 1. TEKNİK GEREKSİNİMLER

- **PHP Sürümü**: PHP 8.2 veya üzeri
- **Veritabanı**: MySQL 8.0+ / MariaDB 10.5+ (InnoDB motoru zorunludur)
- **Veritabanı Sürücüsü**: `mysqli` (PDO kullanılmamıştır)
- **Gerekli PHP Eklentileri**:
  - `php-mysqli` (Veritabanı iletişimi için)
  - `php-mbstring` (Türkçe karakter ve UTF-8 işlemleri için)
  - `php-fileinfo` (Güvenli dosya MIME türü doğrulaması için)
  - `php-curl` (İsteğe bağlı harici servisler için)
  - `php-json` (JSON veri alışverişi için)
- **Saat Dilimi**: Europe/Istanbul (Türkiye Standart Saati)
- **Karakter Seti**: `utf8mb4` / `utf8mb4_unicode_ci`

---

## 2. VERİTABANI VE KURULUM ADIMLARI

1. **Veritabanı Oluşturma**:
   - cPanel / Plesk veya phpMyAdmin üzerinden yeni bir veritabanı oluşturun:
     - Veritabanı Adı: `u988165477_eventpi`
     - Kullanıcı Adı: `u988165477_eventpi`
     - Karakter Seti: `utf8mb4_unicode_ci`
2. **SQL Şemasını Yükleme**:
   - `/install/install.sql` dosyasını phpMyAdmin veya MySQL komut satırı ile içe aktarın (Import):
     ```bash
     mysql -u u988165477_eventpi -p u988165477_eventpi < install/install.sql
     ```
3. **Bağlantı Bilgilerini Düzenleme**:
   - `/config/database.php` dosyasını açarak güncel şifrenizi girin veya ortam değişkeni olarak tanımlayın:
     ```php
     define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
     define('DB_NAME', getenv('DB_NAME') ?: 'u988165477_eventpi');
     define('DB_USER', getenv('DB_USER') ?: 'u988165477_eventpi');
     define('DB_PASS', getenv('DB_PASS') ?: 'GUNCEL_SIFRENIZ');
     ```

---

## 3. İLK GİRİŞ VE YÖNETİCİ HESABI

Sistem kurulumunda varsayılan süper yönetici hesabı oluşturulmuştur:

- **Yönetici Giriş Adresi**: `https://alanadiniz.com/admin/login.php`
- **Kullanıcı Adı**: `admin`
- **Şifre**: `Admin@2026!`
- **Şifreleme**: `password_hash()` (bcrypt 10-cost)

*Not: Kurulum tamamlandıktan sonra `/admin/settings.php` veya veritabanı üzerinden yönetici şifrenizi değiştirmeniz önerilir.*

---

## 4. DİZİN YAPISI

```
/
├── config/
│   ├── database.php        # MySQLi bağlantı ve prepared statement yardımcıları
│   └── settings.php        # Dinamik ayarlar ve oturum başlatma
├── includes/
│   ├── auth.php            # Öğrenci & admin kimlik doğrulama, KVKK loglama
│   ├── functions.php       # Skorboard, tarih, CSV ve yardımcı fonksiyonlar
│   ├── security.php        # CSRF, XSS koruması, IP filtreleme ve rate limit
│   ├── visitor_tracker.php # Ziyaretçi ve bot takip motoru
│   ├── header.php          # Genel site başlığı ve Bootstrap menü
│   └── footer.php          # Genel site alt bilgisi ve modal pencereleri
├── admin/
│   ├── includes/           # Admin panel ortak başlık ve alt bilgileri
│   ├── dashboard.php       # Chart.js analitikleri ve genel özet
│   ├── visitors.php        # IP bazlı ziyaret logları & IP detay denetimi
│   ├── login_logs.php      # Öğrenci giriş denemeleri (KVKK uyumlu)
│   ├── register_logs.php   # Öğrenci kayıt denemeleri
│   ├── students.php        # Öğrenci hesap ve puan yönetimi
│   ├── courses.php         # Ders ekleme, düzenleme ve silme
│   ├── topics.php          # Konu, video ve PDF materyal yönetimi
│   ├── questions.php       # Soru havuzu ve şık yönetimi
│   ├── exams.php           # Vize sınavları (süre, soru sayısı, tarihler)
│   ├── results.php         # Öğrenci sınav sonuçları ve başarı raporları
│   ├── scoreboard.php      # Skorboard denetimi ve puan yeniden hesaplama
│   ├── team.php            # Akademik heyet ve danışman profilleri
│   ├── contact.php         # İletişim bilgileri ve sosyal medya
│   ├── settings.php        # KVKK veri saklama ve rate limit ayarları
│   ├── login.php           # Yönetici güvenli giriş ekranı
│   └── logout.php          # Yönetici oturum kapatma
├── elearn/
│   ├── index.php           # Eğitim merkezi ve ders kataloğu
│   ├── course.php          # Ders izlencesi ve konu listesi
│   ├── topic.php           # Konu anlatımı ve tamamlama
│   ├── test.php            # Süreli interaktif konu testi
│   ├── exam.php            # Çift gönderim korumalı vize sınavı
│   ├── result.php          # Soru analizli karne ve değerlendirme raporu
│   ├── profile.php         # Öğrenci profili, sınav geçmişi ve sertifika
│   └── logout.php          # Öğrenci oturum kapatma
├── install/
│   └── install.sql         # 24 tabloluk eksiksiz veritabanı şeması ve tohum verileri
├── uploads/                # Ders, ekip ve materyal yükleme dizinleri
├── index.php               # Ana karşılama, vitrin ve skorboard sayfası
├── auth_action.php         # Öğrenci giriş ve kayıt POST işleyicisi
└── .htaccess               # Dizin gizleme ve güvenlik kuralları
```

---

## 5. TEST SENARYOLARI

1. **Ziyaretçi Takip Testi**:
   - Sitede herhangi bir sayfayı açın.
   - `/admin/visitors.php` sayfasına girin. IP adresiniz, cihazınız ve ziyaret edilen sayfanın listelendiğini doğrulayın.
   - IP adresine tıklayarak açılan detay panelinde bu IP'den gelen tüm geçmiş ziyaret ve giriş hareketlerini inceleyin.
2. **Öğrenci Kayıt ve Giriş Testi**:
   - Ana sayfadaki "Kayıt Ol" butonuna tıklayın. KVKK onay kutusunu işaretleyerek yeni bir öğrenci kaydı oluşturun.
   - `/admin/register_logs.php` sayfasından kayıt denemesinin loglandığını doğrulayın.
   - Oluşturulan hesapla "Öğrenci Girişi" yapın. Parolanın açık metin kaydedilmediğini teyit edin.
3. **E-LEARN Konu Tamamlama ve Test Çözme**:
   - `/elearn/` adresine gidip bir ders seçin.
   - Konu anlatımını okuyup "Konuyu Tamamlandı Olarak İşaretle" butonuna basın. İlerlemenin kaydedildiğini görün.
   - "Konu Testini Çöz" butonuna basarak 15 dakikalık süreli testi başlatın, soruları cevaplayıp sonucu karnede inceleyin.
4. **Vize Sınavı Testi**:
   - Ders detayındaki "Resmi Vize Sınavı"na katılın.
   - Süre sayacının çalıştığını, sayfa yenilense bile kalan sürenin ve sınav haklarının korunduğunu test edin.
5. **Skorboard ve KVKK Maskeleme**:
   - Test veya vize tamamlandıktan sonra ana sayfadaki `#skorboard` alanına bakın.
   - Öğrencinin soyadının yalnızca ilk harfinin yayınlandığını (örn. "Ahmet Y. – 985 Puan") ve öğrenci izin vermediğinde listelenmediğini teyit edin.

---

## 6. KURULUM SONRASI GÜVENLİK KONTROL LİSTESİ

- [x] `install/install.sql` dosyası üretim sunucusuna yüklendikten sonra silinmeli veya `.htaccess` ile dış erişime kapalı tutulmalıdır.
- [x] Varsayılan yönetici şifresi (`Admin@2026!`) derhal güncellenmelidir.
- [x] SSL/TLS (HTTPS) sertifikası aktif edilmelidir.
- [x] `config/database.php` dosyası için dosya izinleri `640` veya `600` olarak sınırlandırılmalıdır.
- [x] `uploads/` dizininde PHP scriptlerinin çalıştırılması engellenmelidir.
