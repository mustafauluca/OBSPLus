<?php
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['admin_universities'])) {
    $_SESSION['admin_universities'] = [
        ['code' => 'AÜ', 'name' => 'Anadolu Üniversitesi', 'city' => 'Eskişehir', 'rector' => 'Prof. Dr. Fuat ERDAL', 'dean' => 'Prof. Dr. İbrahim KAYA'],
        ['code' => 'EAÜ', 'name' => 'Erzurum Atatürk Üniversitesi', 'city' => 'Erzurum', 'rector' => 'Prof. Dr. Ömer ÇOMAKLI', 'dean' => 'Prof. Dr. Kenan SÖNMEZ'],
        ['code' => 'İÜ', 'name' => 'İstanbul Üniversitesi', 'city' => 'İstanbul', 'rector' => 'Prof. Dr. Osman Bülent ZÜLFİKAR', 'dean' => 'Prof. Dr. Nilgün SARP'],
        ['code' => 'MEÜ', 'name' => 'Marmara Üniversitesi', 'city' => 'İstanbul', 'rector' => 'Prof. Dr. Mustafa KURT', 'dean' => 'Prof. Dr. Ercan GEGEZ'],
        ['code' => 'DEÜ', 'name' => 'Dokuz Eylül Üniversitesi', 'city' => 'İzmir', 'rector' => 'Prof. Dr. Nükhet HOTAR', 'dean' => 'Prof. Dr. Pınar GÜNER'],
    ];
}

// Handle Add University
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_uni') {
    $newCode = strtoupper(trim($_POST['code']));
    $newName = trim($_POST['name']);
    $newCity = trim($_POST['city']);
    $newRector = trim($_POST['rector']);
    $newDean = trim($_POST['dean']);

    if (!empty($newCode) && !empty($newName)) {
        $_SESSION['admin_universities'][] = [
            'code' => $newCode,
            'name' => $newName,
            'city' => $newCity ?: 'Türkiye',
            'rector' => $newRector ?: 'Prof. Dr. Murat DOĞAN',
            'dean' => $newDean ?: 'Prof. Dr. Ceyda SÖZER'
        ];
        logAuditAction('university_add', 'admin_1', 'Yönetici', 'admin', "Yeni üniversite eklendi: $newCode - $newName");
    }
}

// Handle Delete University
if (isset($_GET['delete_code'])) {
    $delCode = $_GET['delete_code'];
    $_SESSION['admin_universities'] = array_filter($_SESSION['admin_universities'], function($u) use ($delCode) {
        return $u['code'] !== $delCode;
    });
    logAuditAction('university_delete', 'admin_1', 'Yönetici', 'admin', "Üniversite silindi: $delCode");
    header("Location: admin.php");
    exit;
}

$universities = $_SESSION['admin_universities'];
$auditLogs = $_SESSION['audit_logs'] ?? [];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>diplomatr.com Yönetim Paneli</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 p-6 text-slate-900 font-sans">
  <div class="max-w-6xl mx-auto space-y-6">
    <div class="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between shadow-xs">
      <div>
        <h1 class="text-base font-bold">diplomatr.com Yönetim Paneli</h1>
        <p class="text-xs text-slate-500">Üniversiteler, İntibak ve Güvenlik Denetim Portali</p>
      </div>
      <a href="index.php" class="text-xs font-semibold text-slate-600 hover:text-slate-900">← Ana Sayfa</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <!-- Add Uni Form -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 space-y-4 shadow-xs">
        <h3 class="text-sm font-bold">Yeni Üniversite Tanımla</h3>
        <form method="POST" class="space-y-3 text-xs">
          <input type="hidden" name="action" value="add_uni">
          <div>
            <label class="block font-semibold mb-1">Monogram Başharfleri (Örn: BEÜ)</label>
            <input type="text" name="code" required class="w-full px-3 py-2 border rounded-lg uppercase font-bold">
          </div>
          <div>
            <label class="block font-semibold mb-1">Üniversite Adı</label>
            <input type="text" name="name" required class="w-full px-3 py-2 border rounded-lg">
          </div>
          <div class="grid grid-cols-3 gap-2">
            <div>
              <label class="block font-semibold mb-1">Şehir</label>
              <input type="text" name="city" value="Ankara" class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div>
              <label class="block font-semibold mb-1">Rektör</label>
              <input type="text" name="rector" value="Prof. Dr. Murat DOĞAN" class="w-full px-3 py-2 border rounded-lg">
            </div>
            <div>
              <label class="block font-semibold mb-1">Dekan</label>
              <input type="text" name="dean" value="Prof. Dr. Ceyda SÖZER" class="w-full px-3 py-2 border rounded-lg">
            </div>
          </div>
          <button type="submit" class="w-full py-2.5 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800">
            Üniversiteyi Kaydet
          </button>
        </form>
      </div>

      <!-- Universities List -->
      <div class="bg-white p-6 rounded-2xl border border-slate-200 space-y-3 shadow-xs">
        <h3 class="text-sm font-bold">Mevcut Üniversiteler (<?php echo count($universities); ?>)</h3>
        <div class="space-y-2 max-h-72 overflow-y-auto pr-1">
          <?php foreach ($universities as $u): ?>
            <div class="p-3 bg-slate-50 border rounded-xl flex items-center justify-between text-xs">
              <div class="flex items-center gap-2.5">
                <span class="w-9 h-9 rounded-lg bg-amber-500 text-slate-950 font-bold flex items-center justify-center font-mono">
                  <?php echo $u['code']; ?>
                </span>
                <div>
                  <div class="font-bold text-slate-900"><?php echo htmlspecialchars($u['name']); ?></div>
                  <div class="text-[10px] text-slate-500"><?php echo $u['city']; ?> • Rektör: <?php echo $u['rector']; ?></div>
                </div>
              </div>
              <a href="admin.php?delete_code=<?php echo $u['code']; ?>" class="text-red-500 hover:text-red-700 font-bold text-xs" onclick="return confirm('Silmek istiyor musunuz?');">Sil</a>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Audit Logs Section -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
      <h3 class="text-sm font-bold">İşlem ve Güvenlik Denetim Logları (Audit Trail)</h3>
      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs border border-slate-200 rounded-lg">
          <thead class="bg-slate-50 text-slate-600 font-bold">
            <tr>
              <th class="p-2.5">Zaman</th>
              <th class="p-2.5">Kullanıcı</th>
              <th class="p-2.5">Rol</th>
              <th class="p-2.5">İşlem</th>
              <th class="p-2.5">İstemci IP</th>
              <th class="p-2.5">Açıklama</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-100">
            <?php if (empty($auditLogs)): ?>
              <tr>
                <td colspan="6" class="p-4 text-center text-slate-400">Henüz kayıtlı bir işlem logu bulunmuyor.</td>
              </tr>
            <?php else: ?>
              <?php foreach ($auditLogs as $log): ?>
                <tr>
                  <td class="p-2.5 font-mono text-slate-500"><?php echo $log['timestamp']; ?></td>
                  <td class="p-2.5 font-bold text-slate-900"><?php echo htmlspecialchars($log['user_name']); ?></td>
                  <td class="p-2.5 font-mono uppercase text-[10px]"><?php echo $log['user_role']; ?></td>
                  <td class="p-2.5 font-mono font-bold"><?php echo $log['action']; ?></td>
                  <td class="p-2.5 font-mono text-amber-700"><?php echo $log['ip_address']; ?></td>
                  <td class="p-2.5 text-slate-600"><?php echo htmlspecialchars($log['details']); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
