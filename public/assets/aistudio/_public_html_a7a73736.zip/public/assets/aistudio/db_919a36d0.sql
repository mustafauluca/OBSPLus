-- diplomatr.com MySQL Veritabanı Tablo Şeması ve Başlangıç Verileri
-- phpMyAdmin üzerinden 'İçe Aktar' (Import) yaparak doğrudan yükleyebilirsiniz.

CREATE DATABASE IF NOT EXISTS `diplomatr_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `diplomatr_db`;

-- 1. Kullanıcı Hesapları Tablosu (Öğrenci, Danışman, Admin)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(150) UNIQUE NOT NULL,
  `tc_no` VARCHAR(11) UNIQUE NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` ENUM('student', 'advisor', 'admin') DEFAULT 'student',
  `password_hash` VARCHAR(255) NOT NULL,
  `register_ip` VARCHAR(45) NOT NULL,
  `last_login_ip` VARCHAR(45) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Güvenlik ve İşlem Denetim Logları Tablosu (Audit Trail)
CREATE TABLE IF NOT EXISTS `user_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `user_id` VARCHAR(50) NOT NULL,
  `user_name` VARCHAR(100) NOT NULL,
  `user_role` ENUM('student', 'advisor', 'admin', 'system') NOT NULL,
  `action` VARCHAR(50) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `details` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Üniversiteler Tablosu
CREATE TABLE IF NOT EXISTS `universities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `city` VARCHAR(50) DEFAULT 'Türkiye',
  `rector_name` VARCHAR(100) NOT NULL,
  `dean_name` VARCHAR(100) NOT NULL,
  `seal_color` VARCHAR(20) DEFAULT '#855827',
  `established_year` INT DEFAULT 1980,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `universities` (`code`, `name`, `city`, `rector_name`, `dean_name`, `seal_color`, `established_year`) VALUES
('AÜ', 'Anadolu Üniversitesi', 'Eskişehir', 'Prof. Dr. Fuat ERDAL', 'Prof. Dr. İbrahim KAYA', '#1e3a8a', 1958),
('EAÜ', 'Erzurum Atatürk Üniversitesi', 'Erzurum', 'Prof. Dr. Ömer ÇOMAKLI', 'Prof. Dr. Kenan SÖNMEZ', '#991b1b', 1957),
('İÜ', 'İstanbul Üniversitesi', 'İstanbul', 'Prof. Dr. Osman Bülent ZÜLFİKAR', 'Prof. Dr. Nilgün SARP', '#065f46', 1453),
('MEÜ', 'Marmara Üniversitesi', 'İstanbul', 'Prof. Dr. Mustafa KURT', 'Prof. Dr. Ercan GEGEZ', '#3730a3', 1883),
('DEÜ', 'Dokuz Eylül Üniversitesi', 'İzmir', 'Prof. Dr. Nükhet HOTAR', 'Prof. Dr. Pınar GÜNER', '#0e7490', 1982);

-- 4. Bölümler Tablosu
CREATE TABLE IF NOT EXISTS `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `slug` VARCHAR(80) UNIQUE NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `type` ENUM('2 Yıllık (Ön Lisans)', '4 Yıllık (Lisans)') NOT NULL,
  `faculty` VARCHAR(150) NOT NULL,
  `total_semesters` INT NOT NULL,
  `total_akts` INT NOT NULL,
  `term_fee` DECIMAL(10,2) NOT NULL,
  `per_credit_fee` DECIMAL(10,2) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `departments` (`slug`, `name`, `type`, `faculty`, `total_semesters`, `total_akts`, `term_fee`, `per_credit_fee`) VALUES
('tibbi-dokumantasyon', 'Tıbbi Dokümantasyon ve Sekreterlik', '2 Yıllık (Ön Lisans)', 'Sağlık Hizmetleri Meslek Yüksekokulu', 4, 120, 1950.00, 260.00),
('adalet', 'Adalet', '2 Yıllık (Ön Lisans)', 'Adalet Meslek Yüksekokulu', 4, 120, 1900.00, 250.00),
('buro-yonetimi', 'Büro Yönetimi ve Yönetici Asistanlığı', '2 Yıllık (Ön Lisans)', 'Meslek Yüksekokulu', 4, 120, 1850.00, 240.00),
('bilgisayar-programciligi', 'Bilgisayar Programcılığı', '2 Yıllık (Ön Lisans)', 'Teknik Bilimler Meslek Yüksekokulu', 4, 120, 2100.00, 280.00),
('ascilik', 'Aşçılık', '2 Yıllık (Ön Lisans)', 'Turizm ve Otelcilik Meslek Yüksekokulu', 4, 120, 2000.00, 250.00),
('web-tasarimi', 'Web Tasarımı ve Kodlama', '2 Yıllık (Ön Lisans)', 'Açıköğretim / Meslek Yüksekokulu', 4, 120, 2050.00, 270.00),
('yonetim-bilisim-sistemleri', 'Yönetim Bilişim Sistemleri', '4 Yıllık (Lisans)', 'İktisadi ve İdari Bilimler Fakültesi', 8, 240, 2450.00, 310.00),
('cocuk-gelisimi', 'Çocuk Gelişimi', '4 Yıllık (Lisans)', 'Sağlık Bilimleri Fakültesi', 8, 240, 2350.00, 290.00),
('sosyal-hizmet', 'Sosyal Hizmet / Sosyal Hizmetler', '4 Yıllık (Lisans)', 'İktisadi, İdari ve Sosyal Bilimler Fakültesi', 8, 240, 2300.00, 285.00),
('isletme', 'İşletme', '4 Yıllık (Lisans)', 'İktisadi ve İdari Bilimler Fakültesi', 8, 240, 2400.00, 300.00),
('insan-kaynaklari', 'İnsan Kaynakları Yönetimi', '4 Yıllık (Lisans)', 'İşletme Fakültesi / İİBF', 8, 240, 2350.00, 295.00),
('kamu-yonetimi', 'Kamu Yönetimi', '4 Yıllık (Lisans)', 'İktisadi ve İdari Bilimler Fakültesi', 8, 240, 2300.00, 290.00),
('havacilik-yonetimi', 'Havacılık Yönetimi', '4 Yıllık (Lisans)', 'Havacılık ve Uzay Bilimleri Fakültesi', 8, 240, 2600.00, 320.00),
('iktisat', 'İktisat', '4 Yıllık (Lisans)', 'İktisadi ve İdari Bilimler Fakültesi', 8, 240, 2350.00, 295.00);

-- 5. Öğrenci Profilleri Tablosu (OBS)
CREATE TABLE IF NOT EXISTS `students` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `age` INT NOT NULL,
  `tc_no` VARCHAR(11) NOT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `student_number` VARCHAR(20) UNIQUE NOT NULL,
  `university_id` INT NOT NULL,
  `department_slug` VARCHAR(80) NOT NULL,
  `status` ENUM('active', 'passive', 'dismissed_amnesty') NOT NULL,
  `current_class` VARCHAR(50) NOT NULL,
  `delayed_years` INT DEFAULT 0,
  `register_ip` VARCHAR(45) NOT NULL,
  `gpa` DECIMAL(3,2) DEFAULT 0.00,
  `tuition_debt` DECIMAL(10,2) DEFAULT 0.00,
  `courses_fee` DECIMAL(10,2) DEFAULT 0.00,
  `scholarship_debt` DECIMAL(10,2) DEFAULT 10000.00,
  `total_payable` DECIMAL(10,2) DEFAULT 0.00,
  `thesis_topic` TEXT,
  `advisor_name` VARCHAR(100),
  `has_committed` TINYINT(1) DEFAULT 0,
  `is_graduated` TINYINT(1) DEFAULT 0,
  `graduation_date` VARCHAR(50) DEFAULT NULL,
  `diploma_number` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`university_id`) REFERENCES `universities`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Transkript İnceleme Talepleri Tablosu
CREATE TABLE IF NOT EXISTS `transcript_submissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `student_name` VARCHAR(100) NOT NULL,
  `department_name` VARCHAR(150) NOT NULL,
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `student_note` TEXT NOT NULL,
  `status` ENUM('pending', 'reviewed', 'approved') DEFAULT 'pending',
  `advisor_feedback` TEXT DEFAULT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Bitirme ve Muafiyet Sınav Girişimleri Tablosu
CREATE TABLE IF NOT EXISTS `exam_attempts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `exam_id` VARCHAR(100) NOT NULL,
  `exam_title` VARCHAR(200) NOT NULL,
  `score` INT NOT NULL,
  `passed` TINYINT(1) NOT NULL,
  `attempt_date` VARCHAR(50) NOT NULL,
  `certificate_number` VARCHAR(100) DEFAULT NULL,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
