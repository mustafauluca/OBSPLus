<?php
require_once __DIR__ . '/config.php';

$student = $_SESSION['obs_student'] ?? [
    'full_name' => 'Ahmet Yılmaz',
    'student_number' => '2022104082',
    'tc_no' => '28491028472',
    'university_code' => 'AÜ',
    'department_name' => 'Bilgisayar Programcılığı',
];

logAuditAction('id_card_view', 'std_' . $student['student_number'], $student['full_name'], 'student', "Öğrenci kimlik kartı açıldı ({$student['university_code']})");
$avatarUrl = 'https://ui-avatars.com/api/?name=' . urlencode($student['full_name']) . '&background=0f172a&color=f8fafc&size=256&bold=true';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Öğrenci Kimliği - <?php echo htmlspecialchars($student['full_name']); ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @media print {
      .no-print { display: none !important; }
      body { background: white !important; padding: 0 !important; }
    }
  </style>
</head>
<body class="bg-slate-200 p-4 sm:p-8 flex flex-col items-center justify-center min-h-screen font-sans">

  <div class="no-print max-w-md w-full mb-4 flex items-center justify-between bg-slate-900 text-white p-3.5 rounded-xl shadow-md">
    <div class="text-xs font-bold">Öğrenci Kimlik Kartı (sablon_kimlik.html)</div>
    <div class="flex items-center gap-2">
      <button onclick="window.print()" class="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg">
        Yazdır / PDF
      </button>
      <a href="obs.php" class="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs rounded-lg hover:text-white">
        OBS'ye Dön
      </a>
    </div>
  </div>

  <!-- ISO CR-80 PVC Card -->
  <div class="w-full max-w-[420px] aspect-[1.586] rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white p-5 shadow-2xl border border-slate-700 flex flex-col justify-between relative overflow-hidden">
    <div class="flex items-center justify-between pb-3 border-b border-slate-700">
      <div class="flex items-center gap-2.5">
        <div class="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 font-black text-lg flex items-center justify-center font-serif">
          <?php echo $student['university_code']; ?>
        </div>
        <div>
          <div class="text-xs font-bold uppercase tracking-wide text-white"><?php echo $student['university_code']; ?> ÜNİVERSİTESİ</div>
          <div class="text-[9px] text-amber-400 font-semibold tracking-wider uppercase">Öğrenci Bilgi Sistemi Kimliği</div>
        </div>
      </div>
      <div class="w-8 h-6 rounded bg-amber-400/80 border border-amber-300"></div>
    </div>

    <div class="grid grid-cols-12 gap-3 items-center my-auto py-1">
      <div class="col-span-4 flex flex-col items-center">
        <img src="<?php echo $avatarUrl; ?>" alt="Foto" class="w-20 h-24 rounded-xl object-cover border-2 border-amber-400 bg-slate-800 shadow-md">
      </div>
      <div class="col-span-8 space-y-1 text-slate-200">
        <div>
          <div class="text-[8px] uppercase tracking-wider text-slate-400">Adı Soyadı</div>
          <div class="text-xs font-bold text-white"><?php echo htmlspecialchars($student['full_name']); ?></div>
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <div class="text-[8px] uppercase tracking-wider text-slate-400">Öğrenci No</div>
            <div class="text-xs font-mono font-bold text-amber-300"><?php echo $student['student_number']; ?></div>
          </div>
          <div>
            <div class="text-[8px] uppercase tracking-wider text-slate-400">T.C. No</div>
            <div class="text-xs font-mono text-slate-300"><?php echo $student['tc_no']; ?></div>
          </div>
        </div>
        <div>
          <div class="text-[8px] uppercase tracking-wider text-slate-400">Bölüm</div>
          <div class="text-[11px] font-semibold text-slate-100 truncate"><?php echo htmlspecialchars($student['department_name']); ?></div>
        </div>
      </div>
    </div>

    <div class="pt-2 border-t border-slate-700 flex items-center justify-between text-[8px] text-slate-400 font-mono">
      <span>*<?php echo $student['student_number']; ?>*</span>
      <span>YÖK-OBS E-Doğrulanabilir</span>
    </div>
  </div>

</body>
</html>
