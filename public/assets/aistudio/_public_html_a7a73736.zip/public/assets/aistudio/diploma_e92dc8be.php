<?php
require_once __DIR__ . '/config.php';

$student = $_SESSION['obs_student'] ?? [
    'full_name' => 'Ahmet Yılmaz',
    'student_number' => '2022104082',
    'tc_no' => '28491028472',
    'university_code' => 'AÜ',
    'department_name' => 'Bilgisayar Programcılığı',
    'gpa' => 2.45
];

logAuditAction('diploma_view', 'std_' . $student['student_number'], $student['full_name'], 'student', "Diploma görüntülendi ({$student['university_code']})");
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Resmi Diploma - <?php echo htmlspecialchars($student['full_name']); ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @media print {
      .no-print { display: none !important; }
      body { background: white !important; padding: 0 !important; }
      #diploma-box { box-shadow: none !important; border-width: 8px !important; }
    }
  </style>
</head>
<body class="bg-stone-200 p-4 sm:p-8 flex flex-col items-center justify-center min-h-screen font-serif">

  <div class="no-print max-w-4xl w-full mb-4 flex items-center justify-between bg-slate-900 text-white p-4 rounded-xl shadow-md font-sans">
    <div class="text-xs font-bold">Resmi Üniversite Diploması (sablon_diploma.html)</div>
    <div class="flex items-center gap-2">
      <button onclick="window.print()" class="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg">
        Yazdır / PDF Olarak Kaydet
      </button>
      <a href="obs.php" class="px-3 py-2 bg-slate-800 text-slate-300 text-xs rounded-lg hover:text-white">
        OBS'ye Dön
      </a>
    </div>
  </div>

  <div id="diploma-box" class="w-full max-w-4xl aspect-[1.414] bg-[#fdfbf7] text-slate-900 p-10 sm:p-14 border-[12px] border-double border-[#855827]/70 shadow-2xl flex flex-col justify-between relative">
    <div class="text-center space-y-1">
      <div class="inline-block w-14 h-14 rounded-full border-2 border-[#855827] bg-[#fbf7ee] text-[#855827] font-black text-2xl leading-[50px] mb-2">
        <?php echo $student['university_code']; ?>
      </div>
      <div class="text-xs uppercase tracking-[0.3em] text-[#855827] font-semibold">TÜRKİYE CUMHURİYETİ</div>
      <h1 class="text-2xl sm:text-3xl font-bold uppercase tracking-wide"><?php echo $student['university_code']; ?> ÜNİVERSİTESİ</h1>
      <div class="text-xs italic text-slate-600">Öğrenci İşleri Daire Başkanlığı</div>
    </div>

    <div class="text-center my-4">
      <div class="inline-block py-1 px-8 border-y-2 border-[#855827]/50 text-base font-bold tracking-[0.25em] text-[#855827] uppercase">
        LİSANS DİPLOMASI
      </div>
    </div>

    <div class="text-center space-y-3 px-6">
      <div class="text-xs italic text-slate-600">Üniversitemiz yetkili kurulları kararıyla gerekli tüm akademik yükümlülükleri tamamlayan</div>
      <div class="text-3xl font-bold text-slate-900 underline decoration-[#855827]/40 underline-offset-8">
        <?php echo mb_strtoupper($student['full_name'], 'UTF-8'); ?>
      </div>
      <div class="text-sm text-slate-800 max-w-xl mx-auto leading-relaxed">
        Üniversitemiz <span class="font-bold"><?php echo htmlspecialchars($student['department_name']); ?></span> programından başarıyla mezun olmuş ve kendisine yasaların tanıdığı tüm hak ve yetkiler tevcih edilmiştir.
      </div>
    </div>

    <div class="flex items-center justify-between text-xs text-slate-700 py-2 border-t border-b border-[#855827]/20 font-sans">
      <div>T.C. Kimlik: <strong><?php echo $student['tc_no']; ?></strong></div>
      <div>Öğrenci No: <strong><?php echo $student['student_number']; ?></strong></div>
      <div>GNO: <strong><?php echo number_format($student['gpa'], 2); ?> / 4.00</strong></div>
      <div>Mezuniyet: <strong>08 KASIM 2026</strong></div>
    </div>

    <div class="grid grid-cols-2 pt-6 items-end font-sans">
      <div class="text-center">
        <div class="italic font-serif text-sm font-bold text-slate-800 mb-1">Ceyda Sözer</div>
        <div class="border-t border-slate-400 w-36 mx-auto pt-1 text-xs font-bold">Prof. Dr. Ceyda SÖZER</div>
        <div class="text-[10px] text-slate-500">Fakülte Dekanı</div>
      </div>
      <div class="text-center">
        <div class="italic font-serif text-sm font-bold text-slate-800 mb-1">Murat Doğan</div>
        <div class="border-t border-slate-400 w-36 mx-auto pt-1 text-xs font-bold">Prof. Dr. Murat DOĞAN</div>
        <div class="text-[10px] text-slate-500">Üniversite Rektörü</div>
      </div>
    </div>
  </div>

</body>
</html>
