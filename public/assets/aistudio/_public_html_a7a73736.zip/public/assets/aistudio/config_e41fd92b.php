<?php
/**
 * diplomatr.com - PHP & MySQL Veritabanı Yapılandırma Dosyası
 * FTP ile sunucuya attıktan sonra cPanel / Plesk MySQL bilgilerinizi buraya girin.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'u988165477_eventpi');
define('DB_USER', 'u988165477_eventpi');
define('DB_PASS', 'even+Pi.2026'); 
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME', 'diplomatr.com');
define('CONTACT_PHONE', '0 541 914 12 48');
define('CONTACT_EMAIL', 'bilgi@diplomatr.com');
define('DEFAULT_SCHOLARSHIP_DEBT', 10000.00); // 10.000,00 TL Öğrenim Bursu Geri Ödemesi

function getDbConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Veritabanı henüz bağlanmadıysa oturum (session) tabanlı yerel depolama kullanır
            return null;
        }
    }
    return $pdo;
}

function getClientIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '176.234.88.14';
    }
}

function logAuditAction($action, $userId, $userName, $userRole, $details) {
    $pdo = getDbConnection();
    $ip = getClientIp();
    if ($pdo) {
        try {
            $stmt = $pdo->prepare("INSERT INTO user_logs (user_id, user_name, user_role, action, ip_address, details) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$userId, $userName, $userRole, $action, $ip, $details]);
        } catch (Exception $e) {}
    } else {
        if (!isset($_SESSION['audit_logs'])) $_SESSION['audit_logs'] = [];
        array_unshift($_SESSION['audit_logs'], [
            'id' => 'log_' . time() . '_' . rand(100, 999),
            'timestamp' => date('Y-m-d H:i:s'),
            'user_id' => $userId,
            'user_name' => $userName,
            'user_role' => $userRole,
            'action' => $action,
            'ip_address' => $ip,
            'details' => $details
        ]);
    }
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
