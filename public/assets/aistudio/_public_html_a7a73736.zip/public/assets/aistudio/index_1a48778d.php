<?php
require_once __DIR__ . '/config.php';

$pdo = getDbConnection();

// Initial departments
$departments = [
    ['name' => 'Tıbbi Dokümantasyon ve Sekreterlik', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 1950],
    ['name' => 'Adalet', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 1900],
    ['name' => 'Büro Yönetimi ve Yönetici Asistanlığı', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 1850],
    ['name' => 'Bilgisayar Programcılığı', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 2100],
    ['name' => 'Aşçılık', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 2000],
    ['name' => 'Web Tasarımı ve Kodlama', 'type' => '2 Yıllık (Ön Lisans)', 'semesters' => 4, 'fee' => 2050],
    ['name' => 'Yönetim Bilişim Sistemleri', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2450],
    ['name' => 'Çocuk Gelişimi', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2350],
    ['name' => 'Sosyal Hizmet / Sosyal Hizmetler', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2300],
    ['name' => 'İşletme', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2400],
    ['name' => 'İnsan Kaynakları Yönetimi', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2350],
    ['name' => 'Kamu Yönetimi', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2300],
    ['name' => 'Havacılık Yönetimi', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2600],
    ['name' => 'İktisat', 'type' => '4 Yıllık (Lisans)', 'semesters' => 8, 'fee' => 2350],
];

// Universities
$universities = [
    ['code' => 'AÜ', 'name' => 'Anadolu Üniversitesi', 'city' => 'Eskişehir', 'rector' => 'Prof. Dr. Fuat ERDAL', 'dean' => 'Prof. Dr. İbrahim KAYA'],
    ['code' => 'EAÜ', 'name' => 'Erzurum Atatürk Üniversitesi', 'city' => 'Erzurum', 'rector' => 'Prof. Dr. Ömer ÇOMAKLI', 'dean' => 'Prof. Dr. Kenan SÖNMEZ'],
    ['code' => 'İÜ', 'name' => 'İstanbul Üniversitesi', 'city' => 'İstanbul', 'rector' => 'Prof. Dr. Osman Bülent ZÜLFİKAR', 'dean' => 'Prof. Dr. Nilgün SARP'],
    ['code' => 'MEÜ', 'name' => 'Marmara Üniversitesi', 'city' => 'İstanbul', 'rector' => 'Prof. Dr. Mustafa KURT', 'dean' => 'Prof. Dr. Ercan GEGEZ'],
    ['code' => 'DEÜ', 'name' => 'Dokuz Eylül Üniversitesi', 'city' => 'İzmir', 'rector' => 'Prof. Dr. Nükhet HOTAR', 'dean' => 'Prof. Dr. Pınar GÜNER'],
];

if (!isset($_SESSION['admin_universities'])) {
    $_SESSION['admin_universities'] = $universities;
} else {
    $universities = $_SESSION['admin_universities'];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DiplomaTR - Erken Mezuniyet & OBS Eğitim Koçluğu</title>
  <meta name="description" content="diplomatr.com: Eğitim koçlarımız ve danışmanlarımız ile eksik dersleri tamamlayıp erken mezun olun.">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 text-slate-900 font-sans antialiased">

  <!-- Top Announcement Bar -->
  <div class="bg-slate-900 text-slate-200 text-xs py-2 px-4 border-b border-slate-800">
    <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
      <div class="flex items-center gap-2">
        <span class="text-amber-400 font-bold">YÖK Mevzuatı Uyumlu:</span>
        <span>Öğrenci affı, pasif kayıt yenileme ve erken mezuniyet danışmanlığı</span>
      </div>
      <div class="flex items-center gap-4 text-xs font-semibold">
        <a href="tel:05419141248" class="text-emerald-400 hover:text-emerald-300">İletişim: <?php echo CONTACT_PHONE; ?></a>
        <span class="text-slate-600">|</span>
        <span class="text-slate-400">Prof. Dr. Murat DOĞAN & Heyeti</span>
      </div>
    </div>
  </div>

  <!-- Main Header -->
  <header class="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-xl shadow-xs">
          D
        </div>
        <div>
          <a href="index.php" class="text-xl font-bold tracking-tight text-slate-900">
            diplomatr<span class="text-amber-600">.com</span>
          </a>
          <div class="text-[10px] text-slate-500 font-medium">ÖBS & Erken Mezuniyet Danışmanlığı</div>
        </div>
      </div>

      <nav class="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
        <a href="#hero" class="hover:text-slate-900">Ana Sayfa</a>
        <a href="#koclar" class="hover:text-slate-900">Eğitim Koçlarımız</a>
        <a href="#bolumler" class="hover:text-slate-900">Bölümler (14 Program)</a>
        <a href="#basvuru" class="text-amber-700 hover:text-amber-800">Mezuniyet & İntibak Planı</a>
      </nav>

      <div class="flex items-center gap-2.5">
        <a href="admin.php" class="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-200">
          Akademisyen Girişi
        </a>
        <a href="obs.php" class="px-3.5 py-2 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
          Öğrenci Girişi
        </a>
        <a href="#basvuru" class="px-4 py-2 text-xs font-extrabold text-white bg-amber-600 hover:bg-amber-500 rounded-lg shadow-xs uppercase tracking-wider">
          BAŞVUR
        </a>
      </div>
    </div>
  </header>

  <!-- Hero Section -->
  <section id="hero" class="bg-gradient-to-b from-slate-900 to-slate-950 text-white py-16 px-4">
    <div class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
      <div class="lg:col-span-7 space-y-6">
        <div class="inline-block px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
          YÖK Uyumlu Mezuniyet & İntibak Planlaması
        </div>
        <h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
          Eğitim Koçlarımız ve Danışmanlarımız ile <span class="text-amber-400">Erken Mezun Olup Diplomanı</span> Gecikmeden Sene Uzatmadan Alabilirsin
        </h1>
        <p class="text-slate-300 text-base max-w-2xl leading-relaxed">
          Kaldığın eksik dersleri tespit ediyor, kaydın silinmişse güncel aftan yararlandırıyor, pasifsen kayıt yeniliyoruz. Geçmiş yıl harç borçları, kredi bedelleri ve 10.000 TL burs yapılandırması ile kişiye özel müfredat hazırlıyoruz.
        </p>
        <div class="flex flex-wrap items-center gap-4 pt-2">
          <a href="#basvuru" class="px-6 py-3.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-sm hover:bg-amber-300 shadow-lg">
            Hemen Başvuru Yap
          </a>
          <a href="tel:05419141248" class="px-5 py-3.5 rounded-xl bg-slate-800 text-slate-200 border border-slate-700 text-sm font-semibold hover:text-white">
            İletişim: <?php echo CONTACT_PHONE; ?>
          </a>
        </div>
      </div>
      <div id="basvuru" class="lg:col-span-5 bg-slate-800/60 p-6 rounded-2xl border border-slate-700 space-y-4">
        <h3 class="text-lg font-bold text-white">Öğrenci Kayıt & İntibak Başvuru Paneli</h3>
        <p class="text-xs text-slate-300">Öğrenci profilinize özel transkript, eksik ders tamamlama ve harç dökümü oluşturun.</p>
        <form action="obs.php" method="POST" class="space-y-3 text-xs">
          <div>
            <label class="block font-semibold text-slate-300 mb-1">Adınız Soyadınız</label>
            <input type="text" name="full_name" required placeholder="Ad Soyad" class="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white">
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div>
              <label class="block font-semibold text-slate-300 mb-1">Yaş</label>
              <input type="number" name="age" required value="24" class="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white">
            </div>
            <div>
              <label class="block font-semibold text-slate-300 mb-1">Kaç Yıl Geriden?</label>
              <select name="delayed_years" class="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white">
                <option value="0">0 (Normal Süre)</option>
                <option value="1">1 Yıl Geriden</option>
                <option value="2" selected>2 Yıl Geriden</option>
                <option value="3">3 Yıl Geriden</option>
                <option value="4">4 Yıl Geriden</option>
              </select>
            </div>
          </div>
          <div>
            <label class="block font-semibold text-slate-300 mb-1">Üniversite</label>
            <select name="university_code" class="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white font-bold">
              <?php foreach ($universities as $u): ?>
                <option value="<?php echo $u['code']; ?>"><?php echo $u['code']; ?> - <?php echo $u['name']; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block font-semibold text-slate-300 mb-1">Bölüm Seçimi</label>
            <select name="department_name" class="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white">
              <?php foreach ($departments as $d): ?>
                <option value="<?php echo htmlspecialchars($d['name']); ?>"><?php echo $d['type']; ?>: <?php echo $d['name']; ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="w-full py-3 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider hover:bg-amber-300 transition-colors cursor-pointer">
            Başvuruyu Tamamla & OBS'ye Git →
          </button>
        </form>
      </div>
    </div>
  </section>

  <!-- Team Section -->
  <section id="koclar" class="py-16 px-4 max-w-7xl mx-auto space-y-10">
    <div class="text-center max-w-2xl mx-auto space-y-2">
      <span class="text-xs font-bold uppercase tracking-widest text-amber-600">Akademik Danışmanlık ve Koçluk Heyeti</span>
      <h2 class="text-3xl font-extrabold text-slate-900">Eğitim Psikolojisi ve Alan Uzmanlarımız</h2>
      <p class="text-sm text-slate-600">Öğrenci profiline göre eksik ders tespiti, intibak ve mezuniyet koçluğu yürüten yetkili kadromuz.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Eğitim Psikolojisi Uzmanı & Başdanışman</div>
        <h3 class="text-lg font-bold text-slate-900">Prof. Dr. Murat DOĞAN</h3>
        <p class="text-xs text-slate-600 leading-relaxed">Öğrenci motivasyonu, sınav kaygısı giderme ve hızlandırılmış mezuniyet stratejileri danışmanı.</p>
      </div>

      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Akademisyen & Müfredat Uzmanı</div>
        <h3 class="text-lg font-bold text-slate-900">Ceyda SÖZER</h3>
        <p class="text-xs text-slate-600 leading-relaxed">Ön lisans ve lisans ders intibakı, AKTS kredi denkleştirme ve transkript eksik konu planlama lideri.</p>
      </div>

      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Akademisyen & Sınav Stratejisti</div>
        <h3 class="text-lg font-bold text-slate-900">Serkan DUMAN</h3>
        <p class="text-xs text-slate-600 leading-relaxed">Vize, final ve bütünleme sınavlarında geçme barajı ve konu tamamlama koçu.</p>
      </div>

      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Akademisyen & Hukuk / Af Danışmanı</div>
        <h3 class="text-lg font-bold text-slate-900">Ahmet KOÇYILMAZ</h3>
        <p class="text-xs text-slate-600 leading-relaxed">YÖK öğrenci affı kanunları, kayıt dondurma ve yasal intibak mevzuat danışmanı.</p>
      </div>

      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Genel Sekreter</div>
        <h3 class="text-lg font-bold text-slate-900">Numan YILDIRIM</h3>
        <p class="text-xs text-slate-600 leading-relaxed">Üniversite koordinasyon kurulları, harç ve burs yapılandırma süreç yöneticisi.</p>
      </div>

      <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div class="text-xs font-bold text-amber-600">Yönetici Asistanı</div>
        <h3 class="text-lg font-bold text-slate-900">Büşra DEMİR</h3>
        <p class="text-xs text-slate-600 leading-relaxed">Öğrenci dosya takibi, randevu planlaması ve 7/24 danışman iletişim destek uzmanı.</p>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-slate-950 text-white py-12 px-4 border-t border-slate-800">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-slate-400">
      <div>
        <div class="text-lg font-bold text-white">diplomatr.com</div>
        <div>Eğitim Koçlarımız ve Danışmanlarımız ile Erken Mezuniyet & OBS Portali</div>
      </div>
      <div>
        Telefon: <strong class="text-white"><?php echo CONTACT_PHONE; ?></strong>
      </div>
      <div>
        © 2026 diplomatr.com — Tüm Hakları Saklıdır.
      </div>
    </div>
  </footer>

</body>
</html>
