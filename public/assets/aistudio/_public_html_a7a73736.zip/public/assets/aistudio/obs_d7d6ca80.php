<?php
require_once __DIR__ . '/config.php';

// Form inputs or session
$fullName = $_POST['full_name'] ?? $_SESSION['obs_student']['full_name'] ?? 'Ahmet Yılmaz';
$age = intval($_POST['age'] ?? $_SESSION['obs_student']['age'] ?? 24);
$delayedYears = intval($_POST['delayed_years'] ?? $_SESSION['obs_student']['delayed_years'] ?? 2);
$uniCode = $_POST['university_code'] ?? $_SESSION['obs_student']['university_code'] ?? 'AÜ';
$deptName = $_POST['department_name'] ?? $_SESSION['obs_student']['department_name'] ?? 'Bilgisayar Programcılığı';

// Generate consistent numbers
$studentNumber = '2022' . (abs(crc32($uniCode)) % 90 + 10) . (abs(crc32($fullName)) % 9000 + 1000);
$tcNo = (abs(crc32($fullName . $age)) % 899999999 + 100000000) . '28';

// Financial calculation: prompt requires unpaid tuition for delayed years + missing courses fee + 10,000 TL scholarship debt
$unpaidSemesters = $delayedYears * 2;
if ($unpaidSemesters === 0) $unpaidSemesters = 2; // minimum renewal
$termFee = 2100;
$totalTuitionDebt = $unpaidSemesters * $termFee;
$missingCoursesFee = 4250;
$scholarshipDebt = DEFAULT_SCHOLARSHIP_DEBT; // 10.000,00 TL
$totalDebt = $totalTuitionDebt + $missingCoursesFee + $scholarshipDebt;

$_SESSION['obs_student'] = [
    'full_name' => $fullName,
    'age' => $age,
    'delayed_years' => $delayedYears,
    'university_code' => $uniCode,
    'department_name' => $deptName,
    'student_number' => $studentNumber,
    'tc_no' => $tcNo,
    'total_debt' => $totalDebt,
    'gpa' => 2.45
];

// Log audit trail
logAuditAction('login', 'std_' . $studentNumber, $fullName, 'student', "OBS girişi yapıldı: $deptName ($uniCode)");

$avatarUrl = 'https://ui-avatars.com/api/?name=' . urlencode($fullName) . '&background=0f172a&color=f8fafc&size=256&bold=true';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Öğrenci Bilgi Sistemi (OBS) - diplomatr.com</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 text-slate-900 font-sans p-4 sm:p-8">
  <div class="max-w-6xl mx-auto space-y-6">

    <!-- Top Bar -->
    <div class="bg-slate-900 rounded-2xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
      <div class="flex items-center gap-4">
        <img src="<?php echo $avatarUrl; ?>" alt="Profil" class="w-16 h-16 rounded-xl border-2 border-amber-400 bg-slate-800">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-xs font-bold border border-amber-500/30">
              No: <?php echo $studentNumber; ?>
            </span>
            <span class="text-xs text-slate-400">Öğrenci Affı İntibak</span>
          </div>
          <h1 class="text-2xl font-bold text-white mt-1"><?php echo htmlspecialchars($fullName); ?></h1>
          <p class="text-xs text-slate-300"><?php echo htmlspecialchars($deptName); ?> • Üniversite: <?php echo $uniCode; ?></p>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-2.5">
        <a href="kimlik.php" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700">
          Öğrenci Kimliği Aç
        </a>
        <a href="diploma.php" class="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold shadow-md">
          Resmi Diplomanı Aç
        </a>
        <a href="index.php" class="px-3.5 py-2.5 rounded-xl bg-slate-800 text-slate-400 text-xs hover:text-white">
          Çıkış Yap
        </a>
      </div>
    </div>

    <!-- 4 Stats Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div class="text-[11px] font-bold text-slate-400 uppercase">Genel Not Ortalaması</div>
        <div class="text-3xl font-black font-mono text-slate-900 mt-1">2.45 <span class="text-xs text-slate-400 font-normal">/ 4.00</span></div>
        <div class="text-xs text-emerald-600 font-semibold mt-1">✓ Başarılı Seviye</div>
      </div>

      <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div class="text-[11px] font-bold text-slate-400 uppercase">Gecikme / İntibak</div>
        <div class="text-3xl font-black font-mono text-slate-900 mt-1"><?php echo $delayedYears; ?> Yıl</div>
        <div class="text-xs text-slate-500 mt-1"><?php echo $unpaidSemesters; ?> Yarıyıl Harç Borcu</div>
      </div>

      <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div class="text-[11px] font-bold text-slate-400 uppercase">Öğrenim Bursu Borcu</div>
        <div class="text-2xl font-black font-mono text-amber-700 mt-1">10.000,00 TL</div>
        <div class="text-xs text-slate-500 mt-1">Sabit Geri Ödeme</div>
      </div>

      <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div class="text-[11px] font-bold text-slate-400 uppercase">Toplam Mali Yükümlülük</div>
        <div class="text-2xl font-black font-mono text-slate-900 mt-1"><?php echo number_format($totalDebt, 2, ',', '.'); ?> TL</div>
        <div class="text-xs text-slate-500 mt-1">Harç + Kredi + Burs</div>
      </div>
    </div>

    <!-- Financial Breakdown Table -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
      <h3 class="text-base font-bold text-slate-900">Mali ve Harç Borç Dökümü</h3>
      <table class="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
        <thead class="bg-slate-50 font-bold text-slate-700">
          <tr>
            <th class="p-3">Borç Kalemi</th>
            <th class="p-3 text-center">Açıklama</th>
            <th class="p-3 text-right">Tutar</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          <tr>
            <td class="p-3 font-semibold">Gecikilen Yıllara Ait Ödenmemiş Öğrenim Harçları</td>
            <td class="p-3 text-center"><?php echo $unpaidSemesters; ?> Dönem x <?php echo number_format($termFee, 2, ',', '.'); ?> TL</td>
            <td class="p-3 text-right font-mono font-bold"><?php echo number_format($totalTuitionDebt, 2, ',', '.'); ?> TL</td>
          </tr>
          <tr>
            <td class="p-3 font-semibold">Eksik Müfredat ve Kredi Tamamlama Bedeli</td>
            <td class="p-3 text-center">İntibak Dersleri</td>
            <td class="p-3 text-right font-mono font-bold"><?php echo number_format($missingCoursesFee, 2, ',', '.'); ?> TL</td>
          </tr>
          <tr>
            <td class="p-3 font-semibold">Tahsis Edilen Öğrenim Bursu Geri Ödemesi</td>
            <td class="p-3 text-center">10.000 TL Burs Sabit Bakiye</td>
            <td class="p-3 text-right font-mono font-bold"><?php echo number_format($scholarshipDebt, 2, ',', '.'); ?> TL</td>
          </tr>
          <tr class="bg-amber-50 font-bold text-amber-950">
            <td class="p-3 font-black">GENEL TOPLAM</td>
            <td class="p-3 text-center">Mezuniyet Taahhüt Tutarı</td>
            <td class="p-3 text-right font-mono font-black text-sm"><?php echo number_format($totalDebt, 2, ',', '.'); ?> TL</td>
          </tr>
        </tbody>
      </table>
    </div>

  </div>
</body>
</html>
