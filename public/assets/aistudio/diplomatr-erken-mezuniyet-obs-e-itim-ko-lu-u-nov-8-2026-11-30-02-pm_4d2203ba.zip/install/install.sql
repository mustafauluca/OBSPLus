-- ==========================================================
-- E-LEARN Öğrenci Eğitim, Sınav ve İstatistik Platformu
-- Eksiksiz MySQL/MariaDB Veritabanı Kurulum Dosyası (InnoDB, utf8mb4)
-- ==========================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+03:00";

-- 1. YÖNETİCİLER (admins)
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` ENUM('superadmin', 'editor', 'moderator') DEFAULT 'superadmin',
  `is_active` TINYINT(1) DEFAULT 1,
  `last_login` DATETIME DEFAULT NULL,
  `last_login_ip` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. ÖĞRENCİLER (students)
CREATE TABLE IF NOT EXISTS `students` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_number` VARCHAR(20) NOT NULL UNIQUE,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `remember_token` VARCHAR(100) DEFAULT NULL,
  `kvkk_accepted` TINYINT(1) DEFAULT 1,
  `show_on_scoreboard` TINYINT(1) DEFAULT 1,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `register_ip` VARCHAR(45) DEFAULT NULL,
  `last_login` DATETIME DEFAULT NULL,
  `last_login_ip` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_student_number` (`student_number`),
  INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ZİYARETÇİ VE TRAFİK LOGLARI (visitor_logs)
CREATE TABLE IF NOT EXISTS `visitor_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `session_id` VARCHAR(100) NOT NULL,
  `visitor_hash` VARCHAR(64) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `student_id` INT DEFAULT NULL,
  `page_title` VARCHAR(150) DEFAULT NULL,
  `page_url` TEXT NOT NULL,
  `referrer` TEXT DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `browser` VARCHAR(50) DEFAULT NULL,
  `os` VARCHAR(50) DEFAULT NULL,
  `device_type` ENUM('mobile', 'tablet', 'desktop', 'bot') DEFAULT 'desktop',
  `visit_source` VARCHAR(50) DEFAULT 'direct',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_ip` (`ip_address`),
  INDEX `idx_visitor_hash` (`visitor_hash`),
  INDEX `idx_student_id` (`student_id`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. ÖĞRENCİ GİRİŞ LOGLARI (student_login_logs)
CREATE TABLE IF NOT EXISTS `student_login_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(45) NOT NULL,
  `student_number` VARCHAR(50) NOT NULL,
  `entered_name` VARCHAR(100) DEFAULT NULL,
  `is_success` TINYINT(1) NOT NULL DEFAULT 0,
  `failure_reason` VARCHAR(255) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `browser` VARCHAR(50) DEFAULT NULL,
  `device_type` VARCHAR(30) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_login_ip` (`ip_address`),
  INDEX `idx_login_number` (`student_number`),
  INDEX `idx_login_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. ÖĞRENCİ KAYIT LOGLARI (student_register_logs)
CREATE TABLE IF NOT EXISTS `student_register_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(45) NOT NULL,
  `student_number` VARCHAR(50) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `is_success` TINYINT(1) NOT NULL DEFAULT 0,
  `verification_status` VARCHAR(50) DEFAULT 'verified',
  `failure_reason` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_reg_ip` (`ip_address`),
  INDEX `idx_reg_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. DERSLER (courses)
CREATE TABLE IF NOT EXISTS `courses` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(160) NOT NULL UNIQUE,
  `description` TEXT DEFAULT NULL,
  `category` VARCHAR(80) DEFAULT 'Genel',
  `image` VARCHAR(255) DEFAULT NULL,
  `sort_order` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_course_slug` (`slug`),
  INDEX `idx_course_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. KONULAR (course_topics)
CREATE TABLE IF NOT EXISTS `course_topics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(160) NOT NULL,
  `short_description` VARCHAR(255) DEFAULT NULL,
  `sort_order` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_topic_course` (`course_id`),
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. KONU ANLATIM İÇERİKLERİ (topic_contents)
CREATE TABLE IF NOT EXISTS `topic_contents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `topic_id` INT NOT NULL,
  `body_html` LONGTEXT NOT NULL,
  `video_url` VARCHAR(255) DEFAULT NULL,
  `summary` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_topic_content` (`topic_id`),
  FOREIGN KEY (`topic_id`) REFERENCES `course_topics`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. DERS VE KONU MATERYALLERİ (course_materials)
CREATE TABLE IF NOT EXISTS `course_materials` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `topic_id` INT DEFAULT NULL,
  `title` VARCHAR(150) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` VARCHAR(20) DEFAULT 'pdf',
  `file_size` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`topic_id`) REFERENCES `course_topics`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. SORU HAVUZU (questions)
CREATE TABLE IF NOT EXISTS `questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `topic_id` INT DEFAULT NULL,
  `question_text` TEXT NOT NULL,
  `explanation` TEXT DEFAULT NULL,
  `points` INT DEFAULT 10,
  `difficulty` ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_q_course` (`course_id`),
  INDEX `idx_q_topic` (`topic_id`),
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`topic_id`) REFERENCES `course_topics`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. SORU SEÇENEKLERİ (question_options)
CREATE TABLE IF NOT EXISTS `question_options` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question_id` INT NOT NULL,
  `option_letter` CHAR(1) NOT NULL,
  `option_text` TEXT NOT NULL,
  `is_correct` TINYINT(1) NOT NULL DEFAULT 0,
  INDEX `idx_opt_question` (`question_id`),
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. TESTLER (tests - Konu Bazlı)
CREATE TABLE IF NOT EXISTS `tests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `topic_id` INT DEFAULT NULL,
  `title` VARCHAR(150) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `duration_minutes` INT DEFAULT 15,
  `pass_score` INT DEFAULT 60,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`topic_id`) REFERENCES `course_topics`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. TEST SORULARI (test_questions)
CREATE TABLE IF NOT EXISTS `test_questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `test_id` INT NOT NULL,
  `question_id` INT NOT NULL,
  `sort_order` INT DEFAULT 0,
  UNIQUE KEY `uniq_test_q` (`test_id`, `question_id`),
  FOREIGN KEY (`test_id`) REFERENCES `tests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. VİZE SINAVLARI (exams - Ders Bazlı)
CREATE TABLE IF NOT EXISTS `exams` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `course_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `duration_minutes` INT DEFAULT 30,
  `question_count` INT DEFAULT 10,
  `pass_score` INT DEFAULT 50,
  `start_date` DATETIME DEFAULT NULL,
  `end_date` DATETIME DEFAULT NULL,
  `max_attempts` INT DEFAULT 2,
  `random_questions` TINYINT(1) DEFAULT 1,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. VİZE SINAV SORULARI (exam_questions)
CREATE TABLE IF NOT EXISTS `exam_questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `exam_id` INT NOT NULL,
  `question_id` INT NOT NULL,
  UNIQUE KEY `uniq_exam_q` (`exam_id`, `question_id`),
  FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. SINAV GİRİŞİMLERİ (exam_attempts)
CREATE TABLE IF NOT EXISTS `exam_attempts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `exam_id` INT DEFAULT NULL,
  `test_id` INT DEFAULT NULL,
  `type` ENUM('exam', 'test') DEFAULT 'exam',
  `start_time` DATETIME NOT NULL,
  `end_time` DATETIME DEFAULT NULL,
  `time_spent_seconds` INT DEFAULT 0,
  `total_questions` INT NOT NULL,
  `correct_count` INT DEFAULT 0,
  `wrong_count` INT DEFAULT 0,
  `empty_count` INT DEFAULT 0,
  `score` DECIMAL(5,2) DEFAULT 0.00,
  `is_passed` TINYINT(1) DEFAULT 0,
  `status` ENUM('in_progress', 'completed', 'timed_out') DEFAULT 'in_progress',
  `attempt_ip` VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_attempt_student` (`student_id`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`exam_id`) REFERENCES `exams`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`test_id`) REFERENCES `tests`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. SINAV CEVAPLARI (exam_answers)
CREATE TABLE IF NOT EXISTS `exam_answers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `attempt_id` INT NOT NULL,
  `question_id` INT NOT NULL,
  `selected_option_id` INT DEFAULT NULL,
  `is_correct` TINYINT(1) DEFAULT 0,
  `points_earned` INT DEFAULT 0,
  FOREIGN KEY (`attempt_id`) REFERENCES `exam_attempts`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. ÖĞRENCİ DERS İLERLEMESİ (student_progress)
CREATE TABLE IF NOT EXISTS `student_progress` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `topic_id` INT NOT NULL,
  `is_completed` TINYINT(1) DEFAULT 1,
  `completed_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_student_topic` (`student_id`, `topic_id`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`topic_id`) REFERENCES `course_topics`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. ÖĞRENCİ PUAN VE SKORLARI (student_scores)
CREATE TABLE IF NOT EXISTS `student_scores` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_id` INT NOT NULL,
  `course_id` INT NOT NULL,
  `total_score` INT DEFAULT 0,
  `exam_count` INT DEFAULT 0,
  `success_rate` DECIMAL(5,2) DEFAULT 0.00,
  `last_activity` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_student_course_score` (`student_id`, `course_id`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`course_id`) REFERENCES `courses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 20. EKİP ÜYELERİ (team_members)
CREATE TABLE IF NOT EXISTS `team_members` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `role_title` VARCHAR(100) NOT NULL,
  `bio` TEXT DEFAULT NULL,
  `degree_info` VARCHAR(150) DEFAULT NULL,
  `specialties` VARCHAR(255) DEFAULT NULL,
  `photo_url` VARCHAR(255) DEFAULT NULL,
  `sort_order` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 21. SİTE AYARLARI (site_settings)
CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key` VARCHAR(60) PRIMARY KEY,
  `setting_value` LONGTEXT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 22. İLETİŞİM AYARLARI (contact_settings)
CREATE TABLE IF NOT EXISTS `contact_settings` (
  `id` INT PRIMARY KEY DEFAULT 1,
  `phone` VARCHAR(30) DEFAULT '0 541 914 12 48',
  `email` VARCHAR(100) DEFAULT 'bilgi@diplomatr.com',
  `address` TEXT DEFAULT 'Kavaklıdere Mah. Atatürk Bulvarı No: 142 Çankaya / Ankara',
  `whatsapp` VARCHAR(30) DEFAULT '905419141248',
  `instagram` VARCHAR(100) DEFAULT 'diplomatr_elearn',
  `facebook` VARCHAR(100) DEFAULT 'diplomatr_edu',
  `youtube` VARCHAR(100) DEFAULT 'diplomatr_akademi',
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 23. ENGELLENEN IP ADRESLERİ (blocked_ips)
CREATE TABLE IF NOT EXISTS `blocked_ips` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(45) NOT NULL UNIQUE,
  `reason` VARCHAR(255) DEFAULT 'Aşırı başarısız giriş denemesi',
  `failed_attempts` INT DEFAULT 5,
  `blocked_until` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 24. YÖNETİCİ VE SİSTEM AUDIT LOGLARI (audit_logs)
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_entity` VARCHAR(50) DEFAULT NULL,
  `target_id` INT DEFAULT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================================
-- BAŞLANGIÇ VERİLERİ (SEED DATA)
-- ==========================================================

-- İlk Admin Kullanıcısı: admin / Admin@123456
INSERT INTO `admins` (`username`, `email`, `password_hash`, `full_name`, `role`)
VALUES ('admin', 'admin@diplomatr.com', '$2y$10$wT0vA6Qd0C4d3Rz4uJ8CWeUaG5FmZ1l7r9Hn4M2vY1Qo2T8Y.y3bK', 'Sistem Yöneticisi', 'superadmin')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Varsayılan Site Ayarları
INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'E-LEARN – Öğrenci Eğitim, Sınav ve İstatistik Platformu'),
('site_description', 'Kişiselleştirilmiş eğitim müfredatları, konu testleri, vize sınavları ve detaylı başarı analitiği.'),
('footer_text', '© 2026 E-LEARN Platformu. Tüm hakları saklıdır. YÖK ve akademik standartlara uygun öğrenme sistemi.'),
('logo_url', '/assets/images/logo.png'),
('kvkk_text', '6698 sayılı Kişisel Verilerin Korunması Kanunu uyarınca, eğitim ve değerlendirme faaliyetlerinizin yürütülmesi amacıyla verileriniz işlenmektedir.'),
('about_content', 'E-LEARN, öğrencilerin eksik kaldıkları akademik konuları hızla tespit eden, özel çalışma planı ve vize hazırlık sınavları sunan yeni nesil dijital öğrenme merkezidir.'),
('max_failed_logins', '5'),
('lockout_minutes', '15'),
('log_retention_days', '180')
ON DUPLICATE KEY UPDATE `setting_key`=`setting_key`;

-- Varsayılan İletişim Bilgileri
INSERT INTO `contact_settings` (`id`, `phone`, `email`, `address`, `whatsapp`, `instagram`, `facebook`, `youtube`)
VALUES (1, '0 541 914 12 48', 'bilgi@diplomatr.com', 'Kavaklıdere Mah. Atatürk Bulvarı No: 142 Çankaya / Ankara', '905419141248', 'diplomatr_elearn', 'diplomatr_edu', 'diplomatr_akademi')
ON DUPLICATE KEY UPDATE `id`=1;

-- Örnek Ekip Üyeleri (Temsili & Yönetilebilir)
INSERT INTO `team_members` (`full_name`, `role_title`, `bio`, `degree_info`, `specialties`, `photo_url`, `sort_order`) VALUES
('Prof. Dr. Murat DOĞAN', 'Eğitim Koordinatörü & Psikoloji Uzmanı', 'Öğrenme psikolojisi ve sınav odaklı çalışma modelleri üzerine 20 yılı aşkın akademik deneyim.', 'Hacettepe Üniversitesi - Eğitim Fakültesi', 'Eğitim Psikolojisi, Sınav Stratejileri', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80', 1),
('Doç. Dr. Ceyda SÖZER', 'Akademik Danışman & Müfredat Uzmanı', 'YÖK intibak ders programları ve AKTS kredilendirme standartları koordinatörü.', 'Anadolu Üniversitesi - İİBF', 'Ders İntibakı, AKTS Planlama', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80', 2),
('Serkan DUMAN', 'Bilgisayar Teknolojileri Uzmanı', 'Web geliştirme, veritabanı mimarisi ve eğitim yazılımları geliştirme uzmanı.', 'ODTÜ - Bilgisayar Mühendisliği', 'Yazılım Mimarisi, SQL, Full Stack', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80', 3),
('Ahmet KOÇYILMAZ', 'Ölçme ve Değerlendirme Uzmanı', 'Soru havuzu geliştirme, test geçerlilik analizleri ve öğrenci performans istatistikleri uzmanı.', 'Gazi Üniversitesi - Eğitim Bilimleri', 'Psikometri, İstatistik, Soru Bankası', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80', 4),
('Numan YILDIRIM', 'Öğrenci İşleri Sorumlusu', 'Öğrenci kayıt süreçleri, intibak dosya denetimi ve mevzuat bilgilendirme koordinatörü.', 'Ankara Üniversitesi - Hukuk', 'Öğrenci Mevzuatı, Af Kanunları', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80', 5),
('Büşra DEMİR', 'Eğitim İçerik Editörü', 'Ders anlatımları, interaktif soru hazırlığı ve dijital materyal tasarım sorumlusu.', 'Ege Üniversitesi - İletişim', 'İçerik Editörlüğü, Pedagoji', 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80', 6);

-- Örnek Dersler
INSERT INTO `courses` (`id`, `title`, `slug`, `description`, `category`, `image`, `sort_order`, `is_active`) VALUES
(1, 'Bilgisayar Teknolojileri ve Programlama', 'bilgisayar-teknolojileri', 'Algoritmalar, veri yapıları, web mimarisi ve veritabanı yönetimi temelleri.', 'Bilişim', 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80', 1, 1),
(2, 'İşletme ve Yönetim Organizasyon', 'isletme-yonetim', 'Modern işletme stratejileri, finansal planlama ve kurumsal organizasyon yapıları.', 'İşletme', 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=600&q=80', 2, 1),
(3, 'Grafik Tasarım ve Görsel İletişim', 'grafik-tasarim', 'Tipografi, renk teorisi, dijital illüstrasyon ve modern UI/UX tasarım temelleri.', 'Tasarım', 'https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&w=600&q=80', 3, 1),
(4, 'Web Geliştirme ve Veritabanı Sistemleri', 'web-gelistirme', 'HTML5, CSS3, JavaScript, PHP 8 ve MySQL ilişkisel veritabanı mimarisi.', 'Yazılım', 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80', 4, 1),
(5, 'Veri Analizi ve İstatistik', 'veri-analizi', 'Tanımlayıcı istatistik, hipotez testleri ve veri görselleştirme yöntemleri.', 'İstatistik', 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80', 5, 1);

-- Örnek Konular
INSERT INTO `course_topics` (`id`, `course_id`, `title`, `slug`, `short_description`, `sort_order`, `is_active`) VALUES
(1, 1, 'Algoritma ve Mantıksal Akış Şemaları', 'algoritma-mantik', 'Temel programlama mantığı, döngüler ve karar yapıları.', 1, 1),
(2, 1, 'İlişkisel Veritabanı ve SQL Temelleri', 'iliskisel-veritabani-sql', 'Tablo tasarımı, normalizasyon ve temel SQL sorguları.', 2, 1),
(3, 1, 'Web Mimarisi ve İstemci-Sunucu İletişimi', 'web-mimarisi-istemci-sunucu', 'HTTP protokolü, REST prensipleri ve API kavramı.', 3, 1),
(4, 2, 'Stratejik Yönetim ve SWOT Analizi', 'stratejik-yonetim-swot', 'İç ve dış çevre analizi, rekabet üstünlüğü modelleri.', 1, 1),
(5, 2, 'Finansal Tablolar ve Bütçe Planlaması', 'finansal-tablolar-butce', 'Bilanço, gelir tablosu analizi ve nakit akışı yönetimi.', 2, 1),
(6, 3, 'Renk Teorisi ve Tipografi Esasları', 'renk-teorisi-tipografi', 'Gözün renk algısı, kontrast kuralları ve font hiyerarşisi.', 1, 1),
(7, 4, 'PHP 8 ile Güvenli Backend Programlama', 'php-8-guvenli-backend', 'Prepared statements, oturum güvenliği ve CSRF önlemleri.', 1, 1);

-- Örnek Konu İçerikleri
INSERT INTO `topic_contents` (`topic_id`, `body_html`, `video_url`, `summary`) VALUES
(1, '<h4>Algoritmaların Temel Özellikleri</h4><p>Algoritma, belirli bir problemi çözmek için tasarlanan mantıksal işlem adımları dizisidir. Her algoritma sonlu olmalı, girdi alabilmeli, çıktı üretebilmeli ve kesinlik taşımalıdır.</p><h5>Akış Şeması Sembolleri</h5><ul><li><strong>Oval:</strong> Başla ve Dur adımları</li><li><strong>Paralelkenar:</strong> Kullanıcıdan veri girişi veya çıktı</li><li><strong>Dikdörtgen:</strong> Aritmetik veya mantıksal işlem</li><li><strong>Eşkenar Dörtgen:</strong> Karar ve koşul yapısı</li></ul>', 'https://www.youtube.com/watch?v=kM9ASKAni_s', 'Algoritmaların tanımı, girdiler, çıktılar ve akış diyagramları temel bilgisi.'),
(2, '<h4>İlişkisel Veritabanı Mimarisi</h4><p>Verilerin tablolar halinde saklandığı ve bu tablolar arasında birincil anahtar (Primary Key) ile yabancı anahtar (Foreign Key) ilişkilerinin kurulduğu sistemlerdir.</p><h5>Temel SQL Komutları</h5><pre class="bg-light p-3 border rounded"><code>SELECT ad, soyad FROM ogrenciler WHERE durum = 1 ORDER BY id DESC;</code></pre>', 'https://www.youtube.com/watch?v=7S_tz1z_5bA', 'SQL DDL ve DML komutları, ilişkisel modelleme ilkeleri.'),
(4, '<h4>SWOT Analizi Nasıl Yapılır?</h4><p>Kurumların Güçlü Yönleri (Strengths), Zayıf Yönleri (Weaknesses), Fırsatları (Opportunities) ve Tehditleri (Threats) inceleyen stratejik bir planlama metodudur.</p>', 'https://www.youtube.com/watch?v=I_6FQ4_G46k', 'Kurumsal çevre analizi ve SWOT matrisinin oluşturulması.');

-- Örnek Sorular ve Seçenekler
INSERT INTO `questions` (`id`, `course_id`, `topic_id`, `question_text`, `explanation`, `points`, `difficulty`) VALUES
(1, 1, 1, 'Akış şemalarında (flowchart) karar veya koşul denetimi için hangi geometrik şekil kullanılır?', 'Koşul ve karşılaştırma işlemleri için eşkenar dörtgen (baklava dilimi) şekli kullanılır.', 10, 'easy'),
(2, 1, 1, 'Aşağıdakilerden hangisi bir algoritmanın temel özelliklerinden biri DEĞİLDİR?', 'Algoritmalar sonsuz döngüde kalamaz, mutlaka sonlu adımda bitmelidir.', 10, 'medium'),
(3, 1, 2, 'İlişkisel bir veritabanında her satırı benzersiz şekilde tanımlayan alana ne ad verilir?', 'Her satırı tekil kılan anahtara Primary Key (Birincil Anahtar) adı verilir.', 10, 'easy'),
(4, 1, 2, 'SQL sorgusunda kayıtları belirli bir alana göre sıralamak için hangi ifade kullanılır?', 'Sıralama için ORDER BY, filtreleme için WHERE kullanılır.', 10, 'easy'),
(5, 2, 4, 'SWOT analizinde kurumun kendi iç dinamiklerini ifade eden bileşenler hangileridir?', 'Güçlü ve zayıf yönler iç çevreye; fırsat ve tehditler dış çevreye aittir.', 10, 'medium'),
(6, 4, 7, 'PHP ile MySQLi bağlantısında SQL Injection saldırılarını önlemenin en güvenli yolu nedir?', 'Parametreleri prepared statements ile bağlamak saldırıları kökten engeller.', 10, 'medium');

INSERT INTO `question_options` (`question_id`, `option_letter`, `option_text`, `is_correct`) VALUES
(1, 'A', 'Dikdörtgen', 0),
(1, 'B', 'Eşkenar Dörtgen (Baklava Dilimi)', 1),
(1, 'C', 'Oval', 0),
(1, 'D', 'Paralelkenar', 0),

(2, 'A', 'Girdi alabilmesi', 0),
(2, 'B', 'Çıktı üretebilmesi', 0),
(2, 'C', 'Sonsuz adımlı olması', 1),
(2, 'D', 'Kesinlik ve netlik taşıması', 0),

(3, 'A', 'Foreign Key', 0),
(3, 'B', 'Primary Key (Birincil Anahtar)', 1),
(3, 'C', 'Index Key', 0),
(3, 'D', 'Unique Constraint', 0),

(4, 'A', 'GROUP BY', 0),
(4, 'B', 'WHERE', 0),
(4, 'C', 'ORDER BY', 1),
(4, 'D', 'HAVING', 0),

(5, 'A', 'Fırsatlar ve Tehditler', 0),
(5, 'B', 'Güçlü ve Zayıf Yönler', 1),
(5, 'C', 'Yalnızca Fırsatlar', 0),
(5, 'D', 'Riskler ve Finansman', 0),

(6, 'A', 'addslashes() fonksiyonu kullanmak', 0),
(6, 'B', 'Prepared Statement (Hazırlanmış İfadeler) ve parametre bağlama', 1),
(6, 'C', 'Tüm girdileri md5 ile şifrelemek', 0),
(6, 'D', 'Veritabanı portunu değiştirmek', 0);

-- Örnek Vize Sınavları
INSERT INTO `exams` (`id`, `course_id`, `title`, `description`, `duration_minutes`, `question_count`, `pass_score`, `max_attempts`, `is_active`) VALUES
(1, 1, 'Bilgisayar Teknolojileri Dönem Sonu Vize Sınavı', 'Algoritmalar, SQL ve temel ağ konularını kapsayan resmi vize sınavıdır.', 25, 4, 60, 2, 1),
(2, 2, 'İşletme Yönetimi Vize Sınavı', 'Stratejik planlama ve SWOT analizini değerlendiren vize sınavıdır.', 20, 2, 50, 2, 1);

INSERT INTO `exam_questions` (`exam_id`, `question_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 5);

-- Örnek Konu Testi
INSERT INTO `tests` (`id`, `course_id`, `topic_id`, `title`, `duration_minutes`, `pass_score`, `is_active`) VALUES
(1, 1, 1, 'Algoritma Mantığı Konu Değerlendirme Testi', 10, 60, 1),
(2, 1, 2, 'SQL Temelleri Alıştırma Testi', 10, 60, 1);

INSERT INTO `test_questions` (`test_id`, `question_id`, `sort_order`) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1),
(2, 4, 2);

-- Örnek Öğrenciler (Şifre: 123456)
INSERT INTO `students` (`id`, `student_number`, `first_name`, `last_name`, `email`, `phone`, `password_hash`, `show_on_scoreboard`) VALUES
(1, '202610101', 'Ahmet', 'Yılmaz', 'ahmet.yilmaz@ogrenci.com', '05419141248', '$2y$10$wT0vA6Qd0C4d3Rz4uJ8CWeUaG5FmZ1l7r9Hn4M2vY1Qo2T8Y.y3bK', 1),
(2, '202610102', 'Mehmet', 'Kaya', 'mehmet.kaya@ogrenci.com', '05421112233', '$2y$10$wT0vA6Qd0C4d3Rz4uJ8CWeUaG5FmZ1l7r9Hn4M2vY1Qo2T8Y.y3bK', 1),
(3, '202610103', 'Ayşe', 'Demir', 'ayse.demir@ogrenci.com', '05433334455', '$2y$10$wT0vA6Qd0C4d3Rz4uJ8CWeUaG5FmZ1l7r9Hn4M2vY1Qo2T8Y.y3bK', 1),
(4, '202610104', 'Zeynep', 'Öztürk', 'zeynep.ozturk@ogrenci.com', '05445556677', '$2y$10$wT0vA6Qd0C4d3Rz4uJ8CWeUaG5FmZ1l7r9Hn4M2vY1Qo2T8Y.y3bK', 1);

-- Örnek Skorboard Kayıtları (Prompt şartı: "Ahmet Y. - 985 Puan, Mehmet K. - 940 Puan, Ayşe D. - 920 Puan")
INSERT INTO `student_scores` (`student_id`, `course_id`, `total_score`, `exam_count`, `success_rate`) VALUES
(1, 1, 985, 10, 98.50),
(2, 2, 940, 9, 94.00),
(3, 3, 920, 9, 92.00),
(4, 4, 890, 8, 89.00);

SET FOREIGN_KEY_CHECKS = 1;
