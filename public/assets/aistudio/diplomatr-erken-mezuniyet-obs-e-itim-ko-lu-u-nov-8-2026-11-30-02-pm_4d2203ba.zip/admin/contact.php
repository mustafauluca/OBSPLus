<?php
/**
 * E-LEARN - İletişim Bilgileri Yönetimi (Contact Settings Management)
 */
$page_title = 'İletişim & Lokasyon Ayarları';
$current_page = 'contact.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// İletişim Bilgilerini Güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone'] ?? '0 541 914 12 48');
    $email = trim($_POST['email'] ?? 'bilgi@diplomatr.com');
    $address = trim($_POST['address'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '905419141248');
    $instagram = trim($_POST['instagram'] ?? '');
    $facebook = trim($_POST['facebook'] ?? '');
    $youtube = trim($_POST['youtube'] ?? '');

    db_execute(
        "UPDATE contact_settings SET phone = ?, email = ?, address = ?, whatsapp = ?, instagram = ?, facebook = ?, youtube = ? WHERE id = 1",
        [$phone, $email, $address, $whatsapp, $instagram, $facebook, $youtube]
    );

    log_audit($_SESSION['admin_id'] ?? 0, 'update_contact', 'contact_settings', 1, "İletişim bilgileri güncellendi.");
    $alert_message = "İletişim bilgileri başarıyla güncellendi.";
}

// Mevcut İletişim Bilgilerini Çek
$contact = db_fetch_one("SELECT * FROM contact_settings WHERE id = 1");
if (!$contact) {
    $contact = [
        'phone' => '0 541 914 12 48',
        'email' => 'bilgi@diplomatr.com',
        'address' => 'Kavaklıdere Mah. Atatürk Bulvarı No: 142 Çankaya / Ankara',
        'whatsapp' => '905419141248',
        'instagram' => 'diplomatr_elearn',
        'facebook' => 'diplomatr_edu',
        'youtube' => 'diplomatr_akademi'
    ];
}
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <h5 class="fw-bold mb-1"><i class="fa-solid fa-headset text-primary me-2"></i> İletişim, WhatsApp ve Sosyal Ağ Bilgileri</h5>
        <p class="text-muted small mb-0">Ana sayfa, başvuru formu ve altbilgi (footer) alanlarında görünen resmi iletişim kanallarını güncelleyin.</p>
    </div>
</div>

<form method="POST" action="contact.php">
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Resmi Telefon Numarası</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-solid fa-phone text-primary"></i></span>
                        <input type="text" name="phone" class="form-control" value="<?php echo e($contact['phone']); ?>" required>
                    </div>
                    <small class="text-muted">Örn: 0 541 914 12 48</small>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Destek ve İletişim E-Postası</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-solid fa-envelope text-info"></i></span>
                        <input type="email" name="email" class="form-control" value="<?php echo e($contact['email']); ?>" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">WhatsApp Destek Hattı</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-brands fa-whatsapp text-success"></i></span>
                        <input type="text" name="whatsapp" class="form-control" value="<?php echo e($contact['whatsapp']); ?>" placeholder="905419141248">
                    </div>
                    <small class="text-muted">Ülke koduyla birlikte bitişik yazınız.</small>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Instagram Kullanıcı Adı</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-brands fa-instagram text-danger"></i></span>
                        <input type="text" name="instagram" class="form-control" value="<?php echo e($contact['instagram'] ?? ''); ?>">
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Facebook Sayfası</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-brands fa-facebook text-primary"></i></span>
                        <input type="text" name="facebook" class="form-control" value="<?php echo e($contact['facebook'] ?? ''); ?>">
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">YouTube Kanalı</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fa-brands fa-youtube text-danger"></i></span>
                        <input type="text" name="youtube" class="form-control" value="<?php echo e($contact['youtube'] ?? ''); ?>">
                    </div>
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold">Merkez Ofis & Kampüs Adresi</label>
                    <textarea name="address" class="form-control" rows="3"><?php echo e($contact['address']); ?></textarea>
                </div>
            </div>
        </div>

        <div class="card-footer bg-light p-3 d-flex justify-content-end">
            <button type="submit" class="btn btn-primary px-4">
                <i class="fa-solid fa-floppy-disk me-2"></i> İletişim Bilgilerini Güncelle
            </button>
        </div>
    </div>
</form>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
