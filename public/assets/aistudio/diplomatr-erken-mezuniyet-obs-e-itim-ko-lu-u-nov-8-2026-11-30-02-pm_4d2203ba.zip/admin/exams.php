<?php
/**
 * E-LEARN - Sınav ve Test Yönetimi (Exams & Tests Management)
 */
$page_title = 'Sınav ve Test Yönetimi';
$current_page = 'exams.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

$courses = db_fetch_all("SELECT id, title, code FROM courses ORDER BY sort_order ASC, title ASC");

// Sınav Ekleme / Güncelleme / Durum Değiştirme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $course_id = (int)($_POST['course_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $exam_type = trim($_POST['exam_type'] ?? 'vize');
        $duration_minutes = max(5, (int)($_POST['duration_minutes'] ?? 30));
        $passing_score = max(1, min(100, (int)($_POST['passing_score'] ?? 50)));
        $total_questions = max(1, (int)($_POST['total_questions'] ?? 5));
        $description = trim($_POST['description'] ?? '');
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));

        if ($course_id <= 0 || empty($title)) {
            $alert_message = 'Lütfen ders ve sınav başlığını eksiksiz girin.';
            $alert_type = 'danger';
        } else {
            if ($action === 'add') {
                db_execute(
                    "INSERT INTO exams (course_id, title, slug, exam_type, description, duration_minutes, passing_score, total_questions, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$course_id, $title, $slug, $exam_type, $description, $duration_minutes, $passing_score, $total_questions, $is_active],
                    "issssiiii"
                );
                $alert_message = "Yeni sınav başarıyla oluşturuldu.";
            } else {
                $id = (int)$_POST['id'];
                db_execute(
                    "UPDATE exams SET course_id = ?, title = ?, slug = ?, exam_type = ?, description = ?, duration_minutes = ?, passing_score = ?, total_questions = ?, is_active = ? WHERE id = ?",
                    [$course_id, $title, $slug, $exam_type, $description, $duration_minutes, $passing_score, $total_questions, $is_active, $id],
                    "issssiiiii"
                );
                $alert_message = "Sınav bilgileri güncellendi.";
            }
        }
    } elseif ($action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $curr = db_fetch_one("SELECT is_active FROM exams WHERE id = ?", [$id], "i");
        if ($curr) {
            $new_val = $curr['is_active'] ? 0 : 1;
            db_execute("UPDATE exams SET is_active = ? WHERE id = ?", [$new_val, $id], "ii");
            $alert_message = "Sınav yayın durumu güncellendi.";
        }
    }
}

// Sınavları Çek
$exams = db_fetch_all(
    "SELECT e.*, c.title AS course_title, c.code AS course_code,
        (SELECT COUNT(*) FROM exam_attempts WHERE exam_id = e.id AND status = 'completed') AS completed_count
     FROM exams e 
     JOIN courses c ON e.course_id = c.id 
     ORDER BY e.id DESC"
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-file-signature text-primary me-2"></i> Sınavlar ve Değerlendirmeler</h5>
                <p class="text-muted small mb-0">Öğrencilerin konu sonu testleri ve ders vize sınavlarını oluşturun ve süresini belirleyin.</p>
            </div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addExamModal">
                <i class="fa-solid fa-plus me-1"></i> Yeni Sınav Oluştur
            </button>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Sınav Başlığı</th>
                        <th>Ders</th>
                        <th>Tür</th>
                        <th>Süre</th>
                        <th>Soru Sayısı</th>
                        <th>Geçme Notu</th>
                        <th>Tamamlayan</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($exams)): ?>
                        <tr><td colspan="10" class="text-center py-4 text-muted">Henüz sınav tanımlanmamış.</td></tr>
                    <?php else: ?>
                        <?php foreach ($exams as $ex): ?>
                            <tr>
                                <td><?php echo $ex['id']; ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($ex['title']); ?></div>
                                    <small class="text-muted"><?php echo e($ex['description']); ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($ex['course_code']); ?></span></td>
                                <td>
                                    <?php if ($ex['exam_type'] === 'vize'): ?>
                                        <span class="badge bg-danger-subtle text-danger">Vize Sınavı</span>
                                    <?php elseif ($ex['exam_type'] === 'final'): ?>
                                        <span class="badge bg-dark-subtle text-dark">Final Sınavı</span>
                                    <?php else: ?>
                                        <span class="badge bg-info-subtle text-info">Konu Testi</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $ex['duration_minutes']; ?> Dk</td>
                                <td><?php echo $ex['total_questions']; ?> Soru</td>
                                <td><span class="badge bg-success-subtle text-success"><?php echo $ex['passing_score']; ?> Puan</span></td>
                                <td>
                                    <a href="results.php?exam_id=<?php echo $ex['id']; ?>" class="badge bg-primary text-decoration-none">
                                        <?php echo $ex['completed_count']; ?> Katılım
                                    </a>
                                </td>
                                <td>
                                    <form method="POST" action="exams.php" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_active">
                                        <input type="hidden" name="id" value="<?php echo $ex['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none">
                                            <?php if ($ex['is_active']): ?>
                                                <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><i class="fa-solid fa-ban me-1"></i> Pasif</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $ex['id']; ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Düzenleme Modalı -->
                            <div class="modal fade" id="editModal<?php echo $ex['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <form method="POST" action="exams.php">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="id" value="<?php echo $ex['id']; ?>">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Sınavı Düzenle: <?php echo e($ex['title']); ?></h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Ders</label>
                                                    <select name="course_id" class="form-select form-select-sm" required>
                                                        <?php foreach ($courses as $c): ?>
                                                            <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $ex['course_id'] ? 'selected' : ''; ?>>
                                                                <?php echo e($c['code'] . ' - ' . $c['title']); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Sınav Başlığı</label>
                                                    <input type="text" name="title" class="form-control form-control-sm" value="<?php echo e($ex['title']); ?>" required>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label small fw-semibold">Sınav Türü</label>
                                                        <select name="exam_type" class="form-select form-select-sm">
                                                            <option value="vize" <?php echo $ex['exam_type'] === 'vize' ? 'selected' : ''; ?>>Vize Sınavı</option>
                                                            <option value="test" <?php echo $ex['exam_type'] === 'test' ? 'selected' : ''; ?>>Konu Testi</option>
                                                            <option value="final" <?php echo $ex['exam_type'] === 'final' ? 'selected' : ''; ?>>Final Sınavı</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="form-label small fw-semibold">Süre (Dk)</label>
                                                        <input type="number" name="duration_minutes" class="form-control form-control-sm" value="<?php echo $ex['duration_minutes']; ?>">
                                                    </div>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label small fw-semibold">Geçme Notu</label>
                                                        <input type="number" name="passing_score" class="form-control form-control-sm" value="<?php echo $ex['passing_score']; ?>">
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="form-label small fw-semibold">Soru Sayısı</label>
                                                        <input type="number" name="total_questions" class="form-control form-control-sm" value="<?php echo $ex['total_questions']; ?>">
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Açıklama</label>
                                                    <textarea name="description" class="form-control form-control-sm" rows="2"><?php echo e($ex['description']); ?></textarea>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" name="is_active" id="actEdit<?php echo $ex['id']; ?>" <?php echo $ex['is_active'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label small" for="actEdit<?php echo $ex['id']; ?>">Sınav aktif olsun</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer p-2">
                                                <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Kaydet</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Sınav Modalı -->
<div class="modal fade" id="addExamModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="exams.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Yeni Sınav Oluştur</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ders</label>
                        <select name="course_id" class="form-select form-select-sm" required>
                            <?php foreach ($courses as $c): ?>
                                <option value="<?php echo $c['id']; ?>"><?php echo e($c['code'] . ' - ' . $c['title']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Sınav Başlığı</label>
                        <input type="text" name="title" class="form-control form-control-sm" placeholder="Örn: 2026 Bahar Dönemi Vize Sınavı" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Sınav Türü</label>
                            <select name="exam_type" class="form-select form-select-sm">
                                <option value="vize" selected>Vize Sınavı</option>
                                <option value="test">Konu Testi</option>
                                <option value="final">Final Sınavı</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Süre (Dk)</label>
                            <input type="number" name="duration_minutes" class="form-control form-control-sm" value="30">
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Geçme Notu</label>
                            <input type="number" name="passing_score" class="form-control form-control-sm" value="50">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Soru Sayısı</label>
                            <input type="number" name="total_questions" class="form-control form-control-sm" value="5">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Açıklama</label>
                        <textarea name="description" class="form-control form-control-sm" rows="2" placeholder="Sınav talimatları ve kapsam..."></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="actNew" checked>
                        <label class="form-check-label small" for="actNew">Sınav hemen yayına alınsın</label>
                    </div>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-sm btn-primary">Sınavı Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
