<?php
/**
 * E-LEARN - Sınav Sonuçları ve Öğrenci Karne Denetimi (Results Management)
 */
$page_title = 'Sınav Sonuçları & Karneler';
$current_page = 'results.php';
require_once __DIR__ . '/includes/admin_header.php';

$filter_exam_id = (int)($_GET['exam_id'] ?? 0);
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 25;
$offset = ($page - 1) * $limit;

$where_clauses = ["a.status = 'completed'"];
$params = [];
$types = "";

if ($filter_exam_id > 0) {
    $where_clauses[] = "a.exam_id = ?";
    $params[] = $filter_exam_id;
    $types .= "i";
}

if (!empty($search)) {
    $where_clauses[] = "(s.student_number LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)";
    $like = "%" . $search . "%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= "sss";
}

if ($status_filter === 'passed') {
    $where_clauses[] = "a.score >= e.passing_score";
} elseif ($status_filter === 'failed') {
    $where_clauses[] = "a.score < e.passing_score";
}

$where_sql = implode(" AND ", $where_clauses);

$count_row = db_fetch_one(
    "SELECT COUNT(*) AS total 
     FROM exam_attempts a 
     JOIN students s ON a.student_id = s.id 
     JOIN exams e ON a.exam_id = e.id 
     WHERE $where_sql",
    $params,
    $types
);
$total_rows = (int)($count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

$attempts = db_fetch_all(
    "SELECT a.*, s.student_number, s.first_name, s.last_name, s.email, 
            e.title AS exam_title, e.passing_score, e.exam_type, c.title AS course_title, c.code AS course_code 
     FROM exam_attempts a 
     JOIN students s ON a.student_id = s.id 
     JOIN exams e ON a.exam_id = e.id 
     JOIN courses c ON e.course_id = c.id 
     WHERE $where_sql 
     ORDER BY a.id DESC 
     LIMIT $limit OFFSET $offset",
    $params,
    $types
);

$all_exams = db_fetch_all("SELECT id, title FROM exams ORDER BY id DESC");
?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="results.php" class="row g-2 align-items-center">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Öğrenci No veya İsim..." value="<?php echo e($search); ?>">
            </div>
            <div class="col-md-3">
                <select name="exam_id" class="form-select form-select-sm">
                    <option value="0">Tüm Sınavlar</option>
                    <?php foreach ($all_exams as $ex): ?>
                        <option value="<?php echo $ex['id']; ?>" <?php echo $ex['id'] == $filter_exam_id ? 'selected' : ''; ?>>
                            <?php echo e($ex['title']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Tüm Sonuçlar</option>
                    <option value="passed" <?php echo $status_filter === 'passed' ? 'selected' : ''; ?>>Geçenler</option>
                    <option value="failed" <?php echo $status_filter === 'failed' ? 'selected' : ''; ?>>Kalanlar</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary flex-fill">
                    <i class="fa-solid fa-filter me-1"></i> Filtrele
                </button>
                <a href="results.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <a href="export.php?type=results" class="btn btn-sm btn-success text-nowrap" title="CSV İndir">
                    <i class="fa-solid fa-file-csv me-1"></i> CSV
                </a>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-square-poll-vertical text-primary me-2"></i> Tamamlanan Sınav Kayıtları (<?php echo number_format($total_rows); ?> Sonuç)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>Öğrenci No</th>
                        <th>Öğrenci Adı</th>
                        <th>Sınav / Ders</th>
                        <th>Tür</th>
                        <th>Puan</th>
                        <th>D / Y / B</th>
                        <th>Durum</th>
                        <th>Tarih</th>
                        <th class="text-end">Karne</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($attempts)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($attempts as $att): ?>
                            <?php $is_passed = ($att['score'] >= $att['passing_score']); ?>
                            <tr>
                                <td><code><?php echo e($att['student_number']); ?></code></td>
                                <td class="fw-semibold text-dark"><?php echo e($att['first_name'] . ' ' . $att['last_name']); ?></td>
                                <td>
                                    <div><strong><?php echo e($att['exam_title']); ?></strong></div>
                                    <small class="text-muted"><?php echo e($att['course_code'] . ' - ' . $att['course_title']); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo strtoupper(e($att['exam_type'])); ?></span>
                                </td>
                                <td>
                                    <h6 class="fw-bold mb-0 <?php echo $is_passed ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo number_format($att['score'], 0); ?>
                                    </h6>
                                </td>
                                <td>
                                    <span class="text-success fw-bold"><?php echo $att['correct_count']; ?>D</span> /
                                    <span class="text-danger fw-bold"><?php echo $att['wrong_count']; ?>Y</span> /
                                    <span class="text-muted"><?php echo $att['empty_count']; ?>B</span>
                                </td>
                                <td>
                                    <?php if ($is_passed): ?>
                                        <span class="badge bg-success-subtle text-success"><i class="fa-solid fa-check me-1"></i> GEÇTİ</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger"><i class="fa-solid fa-xmark me-1"></i> KALDI</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y H:i', strtotime($att['submitted_at'])); ?>
                                </td>
                                <td class="text-end">
                                    <a href="../elearn/result.php?attempt_id=<?php echo $att['id']; ?>" target="_blank" class="btn btn-sm btn-outline-primary" title="Detaylı Öğrenci Karnesini Gör">
                                        <i class="fa-solid fa-file-invoice"></i> Karne
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&exam_id=<?php echo $filter_exam_id; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&exam_id=<?php echo $filter_exam_id; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&exam_id=<?php echo $filter_exam_id; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
