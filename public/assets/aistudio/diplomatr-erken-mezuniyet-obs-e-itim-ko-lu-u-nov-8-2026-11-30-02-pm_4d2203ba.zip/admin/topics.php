<?php
/**
 * E-LEARN - Konu ve Ders İçeriği Yönetimi (Topics Management)
 */
$page_title = 'Konu & İçerik Yönetimi';
$current_page = 'topics.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Tüm Dersleri Çek (Select kutusu için)
$all_courses = db_fetch_all("SELECT id, title, code FROM courses ORDER BY sort_order ASC, title ASC");

$filter_course_id = (int)($_GET['course_id'] ?? 0);
if ($filter_course_id === 0 && !empty($all_courses)) {
    $filter_course_id = (int)$all_courses[0]['id'];
}

// Konu Ekleme / Güncelleme / Silme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $course_id = (int)($_POST['course_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $summary = trim($_POST['summary'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $duration_minutes = max(5, (int)($_POST['duration_minutes'] ?? 20));
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));

        if ($course_id <= 0 || empty($title)) {
            $alert_message = 'Lütfen dersi ve konu başlığını eksiksiz giriniz.';
            $alert_type = 'danger';
        } else {
            if ($action === 'add') {
                db_execute(
                    "INSERT INTO topics (course_id, title, slug, summary, content, video_url, duration_minutes, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)",
                    [$course_id, $title, $slug, $summary, $content, $video_url, $duration_minutes, $sort_order],
                    "isssssii"
                );
                $alert_message = "Yeni konu başarıyla eklendi.";
            } else {
                $id = (int)$_POST['id'];
                db_execute(
                    "UPDATE topics SET course_id = ?, title = ?, slug = ?, summary = ?, content = ?, video_url = ?, duration_minutes = ?, sort_order = ? WHERE id = ?",
                    [$course_id, $title, $slug, $summary, $content, $video_url, $duration_minutes, $sort_order, $id],
                    "isssssiii"
                );
                $alert_message = "Konu başarıyla güncellendi.";
            }
            $filter_course_id = $course_id;
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        db_execute("DELETE FROM topics WHERE id = ?", [$id], "i");
        $alert_message = "Konu silindi.";
    }
}

// Seçili Dersin Konularını Çek
$topics = db_fetch_all(
    "SELECT t.*, c.title AS course_title, c.code AS course_code,
        (SELECT COUNT(*) FROM topic_materials WHERE topic_id = t.id) AS materials_count,
        (SELECT COUNT(*) FROM questions WHERE topic_id = t.id) AS questions_count
     FROM topics t 
     JOIN courses c ON t.course_id = c.id 
     WHERE t.course_id = ? 
     ORDER BY t.sort_order ASC, t.id ASC",
    [$filter_course_id],
    "i"
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-layer-group text-primary me-2"></i> Konu & Müfredat İçerikleri</h5>
                <p class="text-muted small mb-0">Her dersin altındaki konuları, anlatım metinlerini ve video bağlantılarını yönetin.</p>
            </div>
            <div class="d-flex gap-2">
                <form method="GET" action="topics.php" class="d-flex align-items-center">
                    <select name="course_id" class="form-select form-select-sm" onchange="this.form.submit()">
                        <?php foreach ($all_courses as $c): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $filter_course_id ? 'selected' : ''; ?>>
                                <?php echo e($c['code'] . ' - ' . $c['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <button type="button" class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addTopicModal">
                    <i class="fa-solid fa-plus me-1"></i> Yeni Konu Ekle
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>Sıra</th>
                        <th>Konu Başlığı</th>
                        <th>Ders</th>
                        <th>Tahmini Süre</th>
                        <th>Video</th>
                        <th>Soru Havuzu</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($topics)): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Bu derse ait henüz konu bulunmuyor.</td></tr>
                    <?php else: ?>
                        <?php foreach ($topics as $t): ?>
                            <tr>
                                <td class="fw-bold text-muted"><?php echo $t['sort_order']; ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($t['title']); ?></div>
                                    <small class="text-muted text-truncate d-inline-block" style="max-width: 320px;"><?php echo e($t['summary']); ?></small>
                                </td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($t['course_code']); ?></span></td>
                                <td><?php echo $t['duration_minutes']; ?> Dk</td>
                                <td>
                                    <?php if (!empty($t['video_url'])): ?>
                                        <a href="<?php echo e($t['video_url']); ?>" target="_blank" class="text-danger small text-decoration-none">
                                            <i class="fa-brands fa-youtube me-1"></i> Video
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">–</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="questions.php?topic_id=<?php echo $t['id']; ?>" class="btn btn-sm btn-light border py-0 px-2">
                                        <i class="fa-solid fa-circle-question text-info me-1"></i> <?php echo $t['questions_count']; ?> Soru
                                    </a>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $t['id']; ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <form method="POST" action="topics.php" class="d-inline" onsubmit="return confirm('Bu konuyu silmek istediğinize emin misiniz?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Düzenle Modal -->
                            <div class="modal fade" id="editModal<?php echo $t['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <form method="POST" action="topics.php">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                                            <input type="hidden" name="course_id" value="<?php echo $t['course_id']; ?>">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Konuyu Düzenle: <?php echo e($t['title']); ?></h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <div class="row g-2 mb-3">
                                                    <div class="col-8">
                                                        <label class="form-label small fw-semibold">Konu Başlığı</label>
                                                        <input type="text" name="title" class="form-control form-control-sm" value="<?php echo e($t['title']); ?>" required>
                                                    </div>
                                                    <div class="col-2">
                                                        <label class="form-label small fw-semibold">Süre (Dk)</label>
                                                        <input type="number" name="duration_minutes" class="form-control form-control-sm" value="<?php echo $t['duration_minutes']; ?>">
                                                    </div>
                                                    <div class="col-2">
                                                        <label class="form-label small fw-semibold">Sıra No</label>
                                                        <input type="number" name="sort_order" class="form-control form-control-sm" value="<?php echo $t['sort_order']; ?>">
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Kısa Özet / Alt Başlık</label>
                                                    <input type="text" name="summary" class="form-control form-control-sm" value="<?php echo e($t['summary']); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Ders Videosu (YouTube / Video URL)</label>
                                                    <input type="text" name="video_url" class="form-control form-control-sm" value="<?php echo e($t['video_url']); ?>" placeholder="https://www.youtube.com/watch?v=...">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Ders Anlatım Metni (HTML destekli)</label>
                                                    <textarea name="content" class="form-control form-control-sm" rows="8"><?php echo e($t['content']); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer p-2">
                                                <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Kaydet</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Konu Modal -->
<div class="modal fade" id="addTopicModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form method="POST" action="topics.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Yeni Konu Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Bağlı Olduğu Ders</label>
                        <select name="course_id" class="form-select form-select-sm" required>
                            <?php foreach ($all_courses as $c): ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $filter_course_id ? 'selected' : ''; ?>>
                                    <?php echo e($c['code'] . ' - ' . $c['title']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Konu Başlığı</label>
                            <input type="text" name="title" class="form-control form-control-sm" placeholder="Örn: Değişkenler ve Veri Tipleri" required>
                        </div>
                        <div class="col-2">
                            <label class="form-label small fw-semibold">Süre (Dk)</label>
                            <input type="number" name="duration_minutes" class="form-control form-control-sm" value="25">
                        </div>
                        <div class="col-2">
                            <label class="form-label small fw-semibold">Sıra No</label>
                            <input type="number" name="sort_order" class="form-control form-control-sm" value="1">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Kısa Özet</label>
                        <input type="text" name="summary" class="form-control form-control-sm" placeholder="Bu konunun ana kavramları ve hedefleri...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ders Videosu (YouTube URL)</label>
                        <input type="text" name="video_url" class="form-control form-control-sm" placeholder="https://www.youtube.com/watch?v=...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ders Anlatım Metni</label>
                        <textarea name="content" class="form-control form-control-sm" rows="6" placeholder="Öğrencinin okuyacağı ders metni, kod örnekleri ve açıklamalar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-sm btn-primary">Konuyu Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
