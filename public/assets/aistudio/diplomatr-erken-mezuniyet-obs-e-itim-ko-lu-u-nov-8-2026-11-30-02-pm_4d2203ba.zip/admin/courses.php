<?php
/**
 * E-LEARN - Ders ve Eğitim Yönetimi (Courses Management)
 */
$page_title = 'Ders ve Eğitim Yönetimi';
$current_page = 'courses.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Ders Ekleme / Güncelleme / Silme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $category = trim($_POST['category'] ?? 'Lisans');
        $description = trim($_POST['description'] ?? '');
        $duration_hours = max(1, (int)($_POST['duration_hours'] ?? 40));
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Slug oluştur
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));

        if (empty($title) || empty($code)) {
            $alert_message = 'Ders adı ve kodu zorunludur.';
            $alert_type = 'danger';
        } else {
            if ($action === 'add') {
                db_execute(
                    "INSERT INTO courses (title, slug, code, category, description, duration_hours, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [$title, $slug, $code, $category, $description, $duration_hours, $sort_order, $is_active],
                    "sssssiii"
                );
                $alert_message = "Yeni ders başarıyla oluşturuldu.";
            } else {
                $id = (int)$_POST['id'];
                db_execute(
                    "UPDATE courses SET title = ?, slug = ?, code = ?, category = ?, description = ?, duration_hours = ?, sort_order = ?, is_active = ? WHERE id = ?",
                    [$title, $slug, $code, $category, $description, $duration_hours, $sort_order, $is_active, $id],
                    "sssssiiii"
                );
                $alert_message = "Ders bilgileri başarıyla güncellendi.";
            }
        }
    } elseif ($action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $curr = db_fetch_one("SELECT is_active FROM courses WHERE id = ?", [$id], "i");
        if ($curr) {
            $new_val = $curr['is_active'] ? 0 : 1;
            db_execute("UPDATE courses SET is_active = ? WHERE id = ?", [$new_val, $id], "ii");
            $alert_message = "Ders durumu güncellendi.";
        }
    }
}

// Dersleri Çek
$courses = db_fetch_all(
    "SELECT c.*, 
        (SELECT COUNT(*) FROM topics WHERE course_id = c.id) AS topics_count,
        (SELECT COUNT(*) FROM exams WHERE course_id = c.id) AS exams_count
     FROM courses c 
     ORDER BY c.sort_order ASC, c.id DESC"
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-book-bookmark text-primary me-2"></i> Dersler & Müfredat Yönetimi</h5>
                <p class="text-muted small mb-0">Platformda sunulan 2 yıllık ön lisans ve 4 yıllık lisans derslerini tanımlayın ve düzenleyin.</p>
            </div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                <i class="fa-solid fa-plus me-1"></i> Yeni Ders Ekle
            </button>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>Kod</th>
                        <th>Ders Adı</th>
                        <th>Kategori</th>
                        <th>Süre</th>
                        <th>Konular</th>
                        <th>Sınavlar</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($courses)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">Henüz ders eklenmemiş.</td></tr>
                    <?php else: ?>
                        <?php foreach ($courses as $c): ?>
                            <tr>
                                <td><span class="badge bg-dark-subtle text-dark border font-monospace"><?php echo e($c['code']); ?></span></td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($c['title']); ?></div>
                                    <small class="text-muted text-truncate d-inline-block" style="max-width: 250px;"><?php echo e($c['description']); ?></small>
                                </td>
                                <td><span class="badge bg-primary-subtle text-primary"><?php echo e($c['category']); ?></span></td>
                                <td><?php echo $c['duration_hours']; ?> Saat</td>
                                <td>
                                    <a href="topics.php?course_id=<?php echo $c['id']; ?>" class="btn btn-sm btn-light border py-0 px-2">
                                        <i class="fa-solid fa-list-ol text-primary me-1"></i> <?php echo $c['topics_count']; ?> Konu
                                    </a>
                                </td>
                                <td>
                                    <a href="exams.php?course_id=<?php echo $c['id']; ?>" class="btn btn-sm btn-light border py-0 px-2">
                                        <i class="fa-solid fa-file-signature text-success me-1"></i> <?php echo $c['exams_count']; ?> Sınav
                                    </a>
                                </td>
                                <td><?php echo $c['sort_order']; ?></td>
                                <td>
                                    <form method="POST" action="courses.php" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_active">
                                        <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none">
                                            <?php if ($c['is_active']): ?>
                                                <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><i class="fa-solid fa-ban me-1"></i> Pasif</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $c['id']; ?>" title="Düzenle">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Düzenleme Modalı -->
                            <div class="modal fade" id="editModal<?php echo $c['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <form method="POST" action="courses.php">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Dersi Düzenle: <?php echo e($c['title']); ?></h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <div class="row g-2 mb-3">
                                                    <div class="col-8">
                                                        <label class="form-label small fw-semibold">Ders Adı</label>
                                                        <input type="text" name="title" class="form-control form-control-sm" value="<?php echo e($c['title']); ?>" required>
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label small fw-semibold">Ders Kodu</label>
                                                        <input type="text" name="code" class="form-control form-control-sm" value="<?php echo e($c['code']); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label small fw-semibold">Kategori</label>
                                                        <select name="category" class="form-select form-select-sm">
                                                            <option value="Ön Lisans" <?php echo $c['category'] === 'Ön Lisans' ? 'selected' : ''; ?>>Ön Lisans (2 Yıllık)</option>
                                                            <option value="Lisans" <?php echo $c['category'] === 'Lisans' ? 'selected' : ''; ?>>Lisans (4 Yıllık)</option>
                                                            <option value="Sertifika" <?php echo $c['category'] === 'Sertifika' ? 'selected' : ''; ?>>Sertifika Programı</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-3">
                                                        <label class="form-label small fw-semibold">Süre (Saat)</label>
                                                        <input type="number" name="duration_hours" class="form-control form-control-sm" value="<?php echo $c['duration_hours']; ?>">
                                                    </div>
                                                    <div class="col-3">
                                                        <label class="form-label small fw-semibold">Sıra No</label>
                                                        <input type="number" name="sort_order" class="form-control form-control-sm" value="<?php echo $c['sort_order']; ?>">
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Açıklama</label>
                                                    <textarea name="description" class="form-control form-control-sm" rows="3"><?php echo e($c['description']); ?></textarea>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" name="is_active" id="activeEdit<?php echo $c['id']; ?>" <?php echo $c['is_active'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label small" for="activeEdit<?php echo $c['id']; ?>">Ders yayında olsun (Aktif)</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer p-2">
                                                <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Kaydet</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Ders Ekleme Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="courses.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Yeni Ders Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Ders Adı</label>
                            <input type="text" name="title" class="form-control form-control-sm" placeholder="Örn: Bilgisayar Programcılığı" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Ders Kodu</label>
                            <input type="text" name="code" class="form-control form-control-sm" placeholder="Örn: BİL101" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Kategori</label>
                            <select name="category" class="form-select form-select-sm">
                                <option value="Ön Lisans">Ön Lisans (2 Yıllık)</option>
                                <option value="Lisans" selected>Lisans (4 Yıllık)</option>
                                <option value="Sertifika">Sertifika Programı</option>
                            </select>
                        </div>
                        <div class="col-3">
                            <label class="form-label small fw-semibold">Süre (Saat)</label>
                            <input type="number" name="duration_hours" class="form-control form-control-sm" value="48">
                        </div>
                        <div class="col-3">
                            <label class="form-label small fw-semibold">Sıra No</label>
                            <input type="number" name="sort_order" class="form-control form-control-sm" value="1">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Açıklama</label>
                        <textarea name="description" class="form-control form-control-sm" rows="3" placeholder="Ders hakkında kısa tanıtım ve kapsam..."></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="activeNew" checked>
                        <label class="form-check-label small" for="activeNew">Ders hemen yayına alınsın</label>
                    </div>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-sm btn-primary">Dersi Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
