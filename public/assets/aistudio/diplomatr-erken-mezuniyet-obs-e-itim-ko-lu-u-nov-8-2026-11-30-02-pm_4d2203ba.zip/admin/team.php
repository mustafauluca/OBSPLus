<?php
/**
 * E-LEARN - Ekip ve Akademik Danışman Yönetimi (Team Management)
 */
$page_title = 'Ekip ve Danışman Yönetimi';
$current_page = 'team.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Ekip Üyesi Ekleme / Güncelleme / Silme POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $full_name = trim($_POST['full_name'] ?? '');
        $role_title = trim($_POST['role_title'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $degree_info = trim($_POST['degree_info'] ?? '');
        $specialties = trim($_POST['specialties'] ?? '');
        $photo_url = trim($_POST['photo_url'] ?? '');
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (empty($full_name) || empty($role_title)) {
            $alert_message = "Ad Soyad ve Unvan alanları zorunludur.";
            $alert_type = "danger";
        } else {
            if ($action === 'add') {
                db_execute(
                    "INSERT INTO team_members (full_name, role_title, bio, degree_info, specialties, photo_url, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [$full_name, $role_title, $bio, $degree_info, $specialties, $photo_url, $sort_order, $is_active]
                );
                log_audit($_SESSION['admin_id'] ?? 0, 'add_team_member', 'team_members', null, "Yeni danışman eklendi: " . $full_name);
                $alert_message = "Yeni ekip üyesi başarıyla eklendi.";
            } else {
                $id = (int)$_POST['id'];
                db_execute(
                    "UPDATE team_members SET full_name = ?, role_title = ?, bio = ?, degree_info = ?, specialties = ?, photo_url = ?, sort_order = ?, is_active = ? WHERE id = ?",
                    [$full_name, $role_title, $bio, $degree_info, $specialties, $photo_url, $sort_order, $is_active, $id]
                );
                log_audit($_SESSION['admin_id'] ?? 0, 'edit_team_member', 'team_members', $id, "Danışman güncellendi: " . $full_name);
                $alert_message = "Ekip üyesi bilgileri güncellendi.";
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        db_execute("DELETE FROM team_members WHERE id = ?", [$id]);
        log_audit($_SESSION['admin_id'] ?? 0, 'delete_team_member', 'team_members', $id, "Danışman silindi ID: " . $id);
        $alert_message = "Ekip üyesi silindi.";
    } elseif ($action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $curr = db_fetch_one("SELECT is_active FROM team_members WHERE id = ?", [$id]);
        if ($curr) {
            $new_val = $curr['is_active'] ? 0 : 1;
            db_execute("UPDATE team_members SET is_active = ? WHERE id = ?", [$new_val, $id]);
            $alert_message = "Üye görünürlük durumu güncellendi.";
        }
    }
}

// Ekip Üyelerini Çek
$team = db_fetch_all("SELECT * FROM team_members ORDER BY sort_order ASC, id ASC");
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-users-gear text-primary me-2"></i> Akademik Kadro & Danışmanlar</h5>
                <p class="text-muted small mb-0">Ana sayfada ve koçluk süreçlerinde yer alan uzman akademisyen ve danışman ekibini yönetin.</p>
            </div>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                <i class="fa-solid fa-user-plus me-1"></i> Yeni Danışman Ekle
            </button>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th style="width: 60px;">Fotoğraf</th>
                        <th>Ad Soyad & Unvan</th>
                        <th>Akademik Bilgi & Uzmanlık</th>
                        <th>Kısa Biyografi</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($team)): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Kayıtlı danışman bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($team as $m): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($m['photo_url'])): ?>
                                        <img src="<?php echo e($m['photo_url']); ?>" alt="<?php echo e($m['full_name']); ?>" class="rounded-circle border" style="width: 44px; height: 44px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-muted fw-bold border" style="width: 44px; height: 44px;">
                                            <?php echo mb_substr($m['full_name'], 0, 1); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($m['full_name']); ?></div>
                                    <span class="badge bg-primary-subtle text-primary"><?php echo e($m['role_title']); ?></span>
                                </td>
                                <td>
                                    <div><strong><?php echo e($m['degree_info'] ?: '–'); ?></strong></div>
                                    <small class="text-muted"><?php echo e($m['specialties'] ?: '–'); ?></small>
                                </td>
                                <td>
                                    <small class="text-muted text-truncate d-inline-block" style="max-width: 250px;">
                                        <?php echo e($m['bio']); ?>
                                    </small>
                                </td>
                                <td><?php echo $m['sort_order']; ?></td>
                                <td>
                                    <form method="POST" action="team.php" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_active">
                                        <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none">
                                            <?php if ($m['is_active']): ?>
                                                <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><i class="fa-solid fa-ban me-1"></i> Pasif</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $m['id']; ?>">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <form method="POST" action="team.php" class="d-inline" onsubmit="return confirm('Bu danışmanı silmek istediğinize emin misiniz?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>

                            <!-- Düzenleme Modalı -->
                            <div class="modal fade" id="editModal<?php echo $m['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <form method="POST" action="team.php">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Danışmanı Düzenle</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Ad Soyad</label>
                                                    <input type="text" name="full_name" class="form-control form-control-sm" value="<?php echo e($m['full_name']); ?>" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Unvan & Görev</label>
                                                    <input type="text" name="role_title" class="form-control form-control-sm" value="<?php echo e($m['role_title']); ?>" required>
                                                </div>
                                                <div class="row g-2 mb-3">
                                                    <div class="col-8">
                                                        <label class="form-label small fw-semibold">Akademik Bilgi (Üniversite / Fakülte)</label>
                                                        <input type="text" name="degree_info" class="form-control form-control-sm" value="<?php echo e($m['degree_info']); ?>">
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label small fw-semibold">Sıra No</label>
                                                        <input type="number" name="sort_order" class="form-control form-control-sm" value="<?php echo $m['sort_order']; ?>">
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Uzmanlık Alanları (Virgülle ayırın)</label>
                                                    <input type="text" name="specialties" class="form-control form-control-sm" value="<?php echo e($m['specialties']); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Fotoğraf URL</label>
                                                    <input type="text" name="photo_url" class="form-control form-control-sm" value="<?php echo e($m['photo_url']); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Kısa Biyografi</label>
                                                    <textarea name="bio" class="form-control form-control-sm" rows="3"><?php echo e($m['bio']); ?></textarea>
                                                </div>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" name="is_active" id="actEdit<?php echo $m['id']; ?>" <?php echo $m['is_active'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label small" for="actEdit<?php echo $m['id']; ?>">Ana sayfada görünsün</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer p-2">
                                                <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Kaydet</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Danışman Ekleme Modalı -->
<div class="modal fade" id="addMemberModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="team.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Yeni Danışman Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Ad Soyad</label>
                        <input type="text" name="full_name" class="form-control form-control-sm" placeholder="Örn: Prof. Dr. Murat DOĞAN" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Unvan & Görev</label>
                        <input type="text" name="role_title" class="form-control form-control-sm" placeholder="Örn: Eğitim Koordinatörü & Psikoloji Uzmanı" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Akademik Bilgi (Üniversite / Fakülte)</label>
                            <input type="text" name="degree_info" class="form-control form-control-sm" placeholder="Örn: Hacettepe Üniversitesi">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Sıra No</label>
                            <input type="number" name="sort_order" class="form-control form-control-sm" value="7">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Uzmanlık Alanları</label>
                        <input type="text" name="specialties" class="form-control form-control-sm" placeholder="Eğitim Psikolojisi, Sınav Stratejileri">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Fotoğraf URL</label>
                        <input type="text" name="photo_url" class="form-control form-control-sm" placeholder="https://images.unsplash.com/...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Kısa Biyografi</label>
                        <textarea name="bio" class="form-control form-control-sm" rows="3" placeholder="Öğrenme modeli ve uzmanlık geçmişi..."></textarea>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="actNew" checked>
                        <label class="form-check-label small" for="actNew">Ana sayfada yayınlansın</label>
                    </div>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-sm btn-primary">Danışmanı Ekle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
