<?php
/**
 * E-LEARN - Yönetici Giriş Sayfası (Admin Login)
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';
require_once __DIR__ . '/../includes/auth.php';

// Ziyaret kaydı
track_visitor();

// Zaten giriş yapılmışsa doğrudan panele yönlendir
if (is_admin_logged_in()) {
    header("Location: dashboard.php");
    exit;
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($submitted_token)) {
        $error_message = 'Güvenlik doğrulaması (CSRF) geçersiz veya süresi dolmuş. Lütfen sayfayı yenileyip tekrar deneyin.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($username) || empty($password)) {
            $error_message = 'Lütfen kullanıcı adı ve şifrenizi giriniz.';
        } else {
            $login_result = admin_login($username, $password);
            if ($login_result['success']) {
                header("Location: dashboard.php");
                exit;
            } else {
                $error_message = $login_result['message'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetici Girişi – <?php echo e(get_setting('site_name', 'E-LEARN')); ?></title>
    <meta name="robots" content="noindex, nofollow">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            width: 100%;
            max-width: 440px;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .login-header {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            padding: 35px 30px;
            text-align: center;
            color: #ffffff;
        }
        .login-header .shield-icon {
            width: 64px;
            height: 64px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 15px;
            backdrop-filter: blur(8px);
        }
        .login-body {
            padding: 35px 30px;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 16px;
            border: 1.5px solid #e2e8f0;
            font-size: 14px;
            transition: all 0.2s;
        }
        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }
        .btn-login {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            border: none;
            color: #ffffff;
            font-weight: 600;
            padding: 13px;
            border-radius: 10px;
            transition: all 0.2s;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #172554 0%, #1d4ed8 100%);
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3);
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="login-header">
        <div class="shield-icon">
            <i class="fa-solid fa-user-shield"></i>
        </div>
        <h4 class="fw-bold mb-1">Yönetim Paneli</h4>
        <p class="mb-0 text-white-50 small"><?php echo e(get_setting('site_name', 'E-LEARN')); ?> Denetim ve Kontrol Merkezi</p>
    </div>

    <div class="login-body">
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger d-flex align-items-center small py-2 px-3 rounded-3 mb-4" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2 flex-shrink-0"></i>
                <div><?php echo e($error_message); ?></div>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="username" class="form-label small fw-semibold text-secondary">Kullanıcı Adı veya E-Posta</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0 text-muted"><i class="fa-solid fa-user"></i></span>
                    <input type="text" class="form-control border-start-0 ps-0" id="username" name="username" placeholder="admin" required autofocus>
                </div>
            </div>

            <div class="mb-4">
                <label for="password" class="form-label small fw-semibold text-secondary">Yönetici Şifresi</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0 text-muted"><i class="fa-solid fa-key"></i></span>
                    <input type="password" class="form-control border-start-0 ps-0" id="password" name="password" placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn btn-login w-100 py-2 mb-3">
                <i class="fa-solid fa-right-to-bracket me-2"></i> Güvenli Giriş Yap
            </button>

            <div class="text-center">
                <a href="../index.php" class="text-decoration-none small text-muted">
                    <i class="fa-solid fa-arrow-left me-1"></i> Ana Sayfaya Dön
                </a>
            </div>
        </form>
    </div>

    <div class="bg-light p-3 text-center border-top">
        <small class="text-muted d-block">
            <i class="fa-solid fa-lock text-success me-1"></i> 256-bit SSL Güvenli Bağlantı &middot; IP Takibi Aktiftir
        </small>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
