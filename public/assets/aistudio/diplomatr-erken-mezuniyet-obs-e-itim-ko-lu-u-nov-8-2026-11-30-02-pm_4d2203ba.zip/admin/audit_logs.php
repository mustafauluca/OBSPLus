<?php
/**
 * E-LEARN - Sistem ve Yönetici İşlem Logları (Audit Logs)
 */
$page_title = 'Sistem & Yönetici İşlem Logları';
$current_page = 'audit_logs.php';
require_once __DIR__ . '/includes/admin_header.php';

$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 30;
$offset = ($page - 1) * $limit;

$search = trim($_GET['search'] ?? '');

$where = "1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $where .= " AND (al.action LIKE ? OR al.details LIKE ? OR al.ip_address LIKE ? OR adm.username LIKE ?)";
    $like = "%" . $search . "%";
    $params = [$like, $like, $like, $like];
    $types = "ssss";
}

$count_row = db_fetch_one("SELECT COUNT(*) AS total FROM audit_logs al LEFT JOIN admins adm ON al.admin_id = adm.id WHERE $where", $params, $types);
$total_rows = (int)($count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

$logs = db_fetch_all(
    "SELECT al.*, adm.username AS admin_username, adm.full_name AS admin_name 
     FROM audit_logs al 
     LEFT JOIN admins adm ON al.admin_id = adm.id 
     WHERE $where 
     ORDER BY al.id DESC 
     LIMIT $limit OFFSET $offset",
    $params,
    $types
);
?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-clipboard-check text-primary me-2"></i> Sistem & Yönetici Denetim İzi (Audit Trail)</h5>
                <p class="text-muted small mb-0">Yöneticilerin panelde gerçekleştirdiği kritik işlemler, veri değişiklikleri ve güvenlik olaylarının kronolojik kaydı.</p>
            </div>
            <form method="GET" action="audit_logs.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="İşlem, Detay, IP veya Yönetici Ara..." value="<?php echo e($search); ?>">
                <button type="submit" class="btn btn-sm btn-primary text-nowrap"><i class="fa-solid fa-magnifying-glass me-1"></i> Filtrele</button>
                <?php if (!empty($search)): ?>
                    <a href="audit_logs.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>Yönetici</th>
                        <th>İşlem (Action)</th>
                        <th>Hedef Varlık</th>
                        <th>Detay / Açıklama</th>
                        <th>IP Adresi</th>
                        <th>Tarih & Saat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $al): ?>
                            <tr>
                                <td><?php echo $al['id']; ?></td>
                                <td>
                                    <?php if (!empty($al['admin_username'])): ?>
                                        <span class="badge bg-primary-subtle text-primary">
                                            <i class="fa-solid fa-user-shield me-1"></i> <?php echo e($al['admin_username']); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border">Sistem / Otomatik</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="font-monospace fw-bold text-dark"><?php echo e($al['action']); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-light text-secondary border">
                                        <?php echo e($al['target_entity'] ?: 'Genel'); ?><?php echo !empty($al['target_id']) ? ' #' . $al['target_id'] : ''; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="text-dark"><?php echo e($al['details']); ?></span>
                                </td>
                                <td>
                                    <code><?php echo e($al['ip_address']); ?></code>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y H:i:s', strtotime($al['created_at'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
