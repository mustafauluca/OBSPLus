<?php
/**
 * E-LEARN - Güvenli CSV Veri Dışa Aktarma Modülü (CSV Exporter)
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';

// Yalnızca giriş yapmış yöneticiler indirebilir
if (!is_admin_logged_in()) {
    header("Location: login.php");
    exit;
}

$type = trim($_GET['type'] ?? '');
$filename = 'elearn_export_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Excel UTF-8 Türkçe karakter desteği için BOM (Byte Order Mark) ekle
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

if ($type === 'visitors') {
    fputcsv($output, ['ID', 'IP Adresi', 'Sayfa URL', 'Sayfa Basligi', 'Cihaz', 'Isletim Sistemi', 'Tarayici', 'Referans', 'Tarih']);
    $rows = db_fetch_all("SELECT id, ip_address, page_url, page_name, device_type, operating_system, browser, referrer, visit_time FROM visitor_logs ORDER BY id DESC LIMIT 5000");
    foreach ($rows as $r) {
        fputcsv($output, [
            $r['id'],
            $r['ip_address'],
            $r['page_url'],
            $r['page_name'],
            $r['device_type'],
            $r['operating_system'],
            $r['browser'],
            $r['referrer'],
            $r['visit_time']
        ]);
    }
} elseif ($type === 'login_logs') {
    fputcsv($output, ['ID', 'IP Adresi', 'Ogrenci No', 'Girilen Isim', 'Durum', 'Hata Nedeni', 'Cihaz', 'Tarayici', 'Tarih']);
    $rows = db_fetch_all("SELECT id, ip_address, student_number, entered_name, status, failure_reason, device_type, browser, created_at FROM student_login_logs ORDER BY id DESC LIMIT 5000");
    foreach ($rows as $r) {
        fputcsv($output, [
            $r['id'],
            $r['ip_address'],
            $r['student_number'],
            $r['entered_name'],
            $r['status'] === 'success' ? 'Basarili' : 'Basarisiz',
            $r['failure_reason'],
            $r['device_type'],
            $r['browser'],
            $r['created_at']
        ]);
    }
} elseif ($type === 'register_logs') {
    fputcsv($output, ['ID', 'IP Adresi', 'Ogrenci No', 'Ad Soyad', 'E-Posta', 'Durum', 'Hata Nedeni', 'Tarih']);
    $rows = db_fetch_all("SELECT id, ip_address, student_number, full_name, email, status, failure_reason, created_at FROM student_register_logs ORDER BY id DESC LIMIT 5000");
    foreach ($rows as $r) {
        fputcsv($output, [
            $r['id'],
            $r['ip_address'],
            $r['student_number'],
            $r['full_name'],
            $r['email'],
            $r['status'] === 'success' ? 'Basarili' : 'Basarisiz',
            $r['failure_reason'],
            $r['created_at']
        ]);
    }
} elseif ($type === 'results') {
    fputcsv($output, ['Deneme ID', 'Ogrenci No', 'Ad Soyad', 'Sinav Basligi', 'Ders Kodu', 'Puan', 'Durum', 'Dogru', 'Yanlis', 'Bos', 'Tarih']);
    $rows = db_fetch_all(
        "SELECT a.id, s.student_number, CONCAT(s.first_name, ' ', s.last_name) AS full_name, 
                e.title AS exam_title, c.code AS course_code, a.score, e.passing_score,
                a.correct_count, a.wrong_count, a.empty_count, a.submitted_at
         FROM exam_attempts a
         JOIN students s ON a.student_id = s.id
         JOIN exams e ON a.exam_id = e.id
         JOIN courses c ON e.course_id = c.id
         WHERE a.status = 'completed'
         ORDER BY a.id DESC LIMIT 5000"
    );
    foreach ($rows as $r) {
        $passed = ($r['score'] >= $r['passing_score']) ? 'GECTI' : 'KALDI';
        fputcsv($output, [
            $r['id'],
            $r['student_number'],
            $r['full_name'],
            $r['exam_title'],
            $r['course_code'],
            $r['score'],
            $passed,
            $r['correct_count'],
            $r['wrong_count'],
            $r['empty_count'],
            $r['submitted_at']
        ]);
    }
}

fclose($output);
exit;
