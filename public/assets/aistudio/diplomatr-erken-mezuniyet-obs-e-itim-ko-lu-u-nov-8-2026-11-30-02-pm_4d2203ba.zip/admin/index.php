<?php
/**
 * E-LEARN - Yönetim Paneli Ana Yönlendirici
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';

if (is_admin_logged_in()) {
    header("Location: dashboard.php");
} else {
    header("Location: login.php");
}
exit;
