<?php
/**
 * E-LEARN - Yönetici Çıkış İşlemi
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';

admin_logout();
header("Location: login.php");
exit;
