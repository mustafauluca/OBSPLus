<?php
/**
 * E-LEARN - Genel Sistem ve Güvenlik Ayarları (Settings Management)
 */
$page_title = 'Sistem & Güvenlik Ayarları';
$current_page = 'settings.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Ayarları Güncelleme POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings_to_update = [
        'site_name' => trim($_POST['site_name'] ?? 'E-LEARN'),
        'site_description' => trim($_POST['site_description'] ?? ''),
        'footer_text' => trim($_POST['footer_text'] ?? ''),
        'about_content' => trim($_POST['about_content'] ?? ''),
        'kvkk_text' => trim($_POST['kvkk_text'] ?? ''),
        'max_failed_logins' => (string)max(3, min(20, (int)($_POST['max_failed_logins'] ?? 5))),
        'lockout_minutes' => (string)max(5, min(120, (int)($_POST['lockout_minutes'] ?? 15))),
        'log_retention_days' => (string)max(30, min(365, (int)($_POST['log_retention_days'] ?? 180)))
    ];

    foreach ($settings_to_update as $key => $val) {
        db_execute(
            "INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?",
            [$key, $val, $val]
        );
    }

    log_audit($_SESSION['admin_id'] ?? 0, 'update_settings', 'site_settings', null, "Sistem ayarları güncellendi.");
    $alert_message = "Sistem ayarları başarıyla kaydedildi.";
}

// Mevcut Ayarları Çek
$settings_rows = db_fetch_all("SELECT setting_key, setting_value FROM site_settings");
$current_settings = [];
foreach ($settings_rows as $row) {
    $current_settings[$row['setting_key']] = $row['setting_value'];
}
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <h5 class="fw-bold mb-1"><i class="fa-solid fa-sliders text-primary me-2"></i> Platform Parametreleri ve Güvenlik Ayarları</h5>
        <p class="text-muted small mb-0">Platform genel adı, KVKK aydınlatma metni, parola deneme limiti ve IP engelleme sürelerini yapılandırın.</p>
    </div>
</div>

<form method="POST" action="settings.php">
    <div class="row g-4">
        <!-- Genel Platform Bilgileri -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                    <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-globe text-primary me-2"></i> Genel Platform Bilgileri</h6>
                </div>
                <div class="card-body p-3">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Platform Adı / Başlık</label>
                        <input type="text" name="site_name" class="form-control" value="<?php echo e($current_settings['site_name'] ?? 'E-LEARN – Öğrenci Eğitim, Sınav ve İstatistik Platformu'); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Meta Açıklama (SEO)</label>
                        <textarea name="site_description" class="form-control" rows="2"><?php echo e($current_settings['site_description'] ?? ''); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Footer Telif Metni</label>
                        <input type="text" name="footer_text" class="form-control" value="<?php echo e($current_settings['footer_text'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Platform Hakkında / Tanıtım Metni</label>
                        <textarea name="about_content" class="form-control" rows="4"><?php echo e($current_settings['about_content'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Güvenlik ve KVKK Ayarları -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                    <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-shield-halved text-danger me-2"></i> Güvenlik & KVKK Protokolleri</h6>
                </div>
                <div class="card-body p-3">
                    <div class="row g-3 mb-3">
                        <div class="col-sm-6">
                            <label class="form-label small fw-semibold">Maksimum Başarısız Giriş</label>
                            <div class="input-group">
                                <input type="number" name="max_failed_logins" class="form-control" min="3" max="20" value="<?php echo e($current_settings['max_failed_logins'] ?? '5'); ?>" required>
                                <span class="input-group-text small text-muted">deneme</span>
                            </div>
                            <small class="text-muted d-block mt-1">Bu limit aşılınca IP otomatik engellenir.</small>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label small fw-semibold">IP Engelleme Süresi</label>
                            <div class="input-group">
                                <input type="number" name="lockout_minutes" class="form-control" min="5" max="120" value="<?php echo e($current_settings['lockout_minutes'] ?? '15'); ?>" required>
                                <span class="input-group-text small text-muted">dakika</span>
                            </div>
                            <small class="text-muted d-block mt-1">Geçici engelleme bekleme süresi.</small>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Log Saklama Süresi</label>
                        <div class="input-group">
                            <input type="number" name="log_retention_days" class="form-control" min="30" max="365" value="<?php echo e($current_settings['log_retention_days'] ?? '180'); ?>" required>
                            <span class="input-group-text small text-muted">gün</span>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-danger">KVKK Aydınlatma ve Onay Metni</label>
                        <textarea name="kvkk_text" class="form-control" rows="5" required><?php echo e($current_settings['kvkk_text'] ?? ''); ?></textarea>
                        <small class="text-muted d-block mt-1">Öğrencilerin kayıt olurken onayladığı yasal bilgilendirme metnidir.</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card border-0 shadow-sm p-3 d-flex flex-row justify-content-between align-items-center">
                <span class="text-muted small">Değişiklikler anında platform genelinde ve oturum denetleyicilerinde yürürlüğe girer.</span>
                <button type="submit" class="btn btn-primary px-4">
                    <i class="fa-solid fa-floppy-disk me-2"></i> Ayarları Kaydet
                </button>
            </div>
        </div>
    </div>
</form>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
