<?php
/**
 * E-LEARN - Admin Layout Footer
 */
?>
        </div><!-- /container-fluid or page wrapper -->
    </main>
</div><!-- /admin-layout -->

<footer class="bg-white border-top py-3 text-center text-muted small mt-auto">
    <div class="container-fluid">
        <span>&copy; <?php echo date('Y'); ?> <strong><?php echo e(get_setting('site_name', 'E-LEARN')); ?></strong> – Yönetim ve Denetim Paneli. Tüm Hakları Saklıdır.</span>
    </div>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
});
</script>
</body>
</html>
