<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Admin Paneli - Ortak Header ve Yan Menü (Sidebar)
 */

require_once __DIR__ . '/../../config/settings.php';
require_once __DIR__ . '/../../includes/security.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

// Yetki Denetimi: Yalnızca giriş yapmış yöneticiler erişebilir
if (!is_admin_logged_in()) {
    header("Location: /admin/login.php");
    exit;
}

$current_admin = get_current_admin();
$current_page = basename($_SERVER['PHP_SELF']);
$admin_page_title = $admin_title ?? 'Yönetim Paneli';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($admin_page_title); ?> - E-LEARN Yönetim Paneli</title>

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts: Inter & Outfit -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@600;700;800&display=swap" rel="stylesheet">
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    :root {
      --admin-navy: #0b1329;
      --admin-sidebar-bg: #0f172a;
      --admin-hover: #1e293b;
      --admin-active: #0284c7;
      --admin-card: #ffffff;
      --admin-border: #e2e8f0;
    }
    body {
      font-family: 'Inter', -apple-system, sans-serif;
      background-color: #f1f5f9;
      color: #1e293b;
      min-height: 100vh;
    }
    .admin-wrapper {
      display: flex;
      min-height: 100vh;
    }
    .admin-sidebar {
      width: 270px;
      background: var(--admin-sidebar-bg);
      color: #94a3b8;
      flex-shrink: 0;
      display: flex;
      flex-direction: column;
      border-right: 1px solid #1e293b;
      transition: all 0.3s ease;
    }
    .admin-nav-item {
      color: #94a3b8;
      padding: 0.65rem 1.25rem;
      display: flex;
      align-items: center;
      gap: 0.75rem;
      text-decoration: none;
      font-size: 0.85rem;
      font-weight: 500;
      border-radius: 0.5rem;
      margin: 0.15rem 0.75rem;
      transition: all 0.15s ease;
    }
    .admin-nav-item:hover {
      background: var(--admin-hover);
      color: #f8fafc;
    }
    .admin-nav-item.active {
      background: var(--admin-active);
      color: #ffffff;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(2, 132, 199, 0.3);
    }
    .admin-nav-header {
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #475569;
      padding: 0.85rem 1.25rem 0.35rem 1.25rem;
      font-weight: 700;
    }
    .admin-content {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      overflow-x: hidden;
    }
    .admin-topbar {
      background: #ffffff;
      border-bottom: 1px solid var(--admin-border);
      padding: 0.75rem 1.5rem;
    }
    .card-dashboard {
      background: #ffffff;
      border: 1px solid var(--admin-border);
      border-radius: 0.875rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    }
  </style>
</head>
<body>

<div class="admin-wrapper">
  <!-- Yan Menü (Sidebar) -->
  <aside class="admin-sidebar" id="adminSidebar">
    <div class="p-3 border-bottom border-slate-800 d-flex align-items-center justify-content-between">
      <a href="/admin/dashboard.php" class="d-flex align-items-center gap-2 text-decoration-none text-white">
        <div class="rounded-3 bg-info text-dark d-flex align-items-center justify-content-center fw-bold font-monospace" style="width: 32px; height: 32px;">
          E
        </div>
        <div>
          <div class="fw-bold tracking-tight text-white mb-0" style="font-size: 1.05rem;">E-LEARN<span class="text-info">Admin</span></div>
          <div class="text-secondary" style="font-size: 0.65rem;">Yönetim & İstatistik Portali</div>
        </div>
      </a>
      <a href="/index.php" target="_blank" class="btn btn-sm btn-dark text-secondary" title="Siteyi Görüntüle">
        <i class="bi bi-box-arrow-up-right"></i>
      </a>
    </div>

    <!-- Menü Öğeleri -->
    <div class="flex-grow-1 overflow-y-auto py-2" style="max-height: calc(100vh - 120px);">
      <div class="admin-nav-header">Genel Bakış</div>
      <a href="/admin/dashboard.php" class="admin-nav-item <?php echo ($current_page === 'dashboard.php') ? 'active' : ''; ?>">
        <i class="bi bi-speedometer2"></i>Genel Bakış
      </a>

      <div class="admin-nav-header">İstatistik ve Loglar</div>
      <a href="/admin/visitors.php" class="admin-nav-item <?php echo ($current_page === 'visitors.php') ? 'active' : ''; ?>">
        <i class="bi bi-graph-up"></i>Ziyaretçi İstatistikleri
      </a>
      <a href="/admin/login_logs.php" class="admin-nav-item <?php echo ($current_page === 'login_logs.php') ? 'active' : ''; ?>">
        <i class="bi bi-box-arrow-in-right"></i>Öğrenci Giriş Logları
      </a>
      <a href="/admin/register_logs.php" class="admin-nav-item <?php echo ($current_page === 'register_logs.php') ? 'active' : ''; ?>">
        <i class="bi bi-person-lines-fill"></i>Öğrenci Kayıt Logları
      </a>

      <div class="admin-nav-header">Öğrenci & Akademi</div>
      <a href="/admin/students.php" class="admin-nav-item <?php echo ($current_page === 'students.php') ? 'active' : ''; ?>">
        <i class="bi bi-people"></i>Öğrenci Yönetimi
      </a>
      <a href="/admin/scoreboard.php" class="admin-nav-item <?php echo ($current_page === 'scoreboard.php') ? 'active' : ''; ?>">
        <i class="bi bi-trophy"></i>Skorboard Yönetimi
      </a>

      <div class="admin-nav-header">Eğitim & Sınavlar</div>
      <a href="/admin/courses.php" class="admin-nav-item <?php echo ($current_page === 'courses.php') ? 'active' : ''; ?>">
        <i class="bi bi-book"></i>Ders Yönetimi
      </a>
      <a href="/admin/topics.php" class="admin-nav-item <?php echo ($current_page === 'topics.php') ? 'active' : ''; ?>">
        <i class="bi bi-journal-text"></i>Konu Yönetimi
      </a>
      <a href="/admin/questions.php" class="admin-nav-item <?php echo ($current_page === 'questions.php') ? 'active' : ''; ?>">
        <i class="bi bi-patch-question"></i>Soru Havuzu
      </a>
      <a href="/admin/exams.php" class="admin-nav-item <?php echo ($current_page === 'exams.php') ? 'active' : ''; ?>">
        <i class="bi bi-award"></i>Vize Sınavları & Testler
      </a>
      <a href="/admin/results.php" class="admin-nav-item <?php echo ($current_page === 'results.php') ? 'active' : ''; ?>">
        <i class="bi bi-card-checklist"></i>Sınav Sonuçları
      </a>

      <div class="admin-nav-header">Site & Yönetim</div>
      <a href="/admin/team.php" class="admin-nav-item <?php echo ($current_page === 'team.php') ? 'active' : ''; ?>">
        <i class="bi bi-person-badge"></i>Ekip Yönetimi
      </a>
      <a href="/admin/contact.php" class="admin-nav-item <?php echo ($current_page === 'contact.php') ? 'active' : ''; ?>">
        <i class="bi bi-telephone"></i>İletişim Bilgileri
      </a>
      <a href="/admin/settings.php" class="admin-nav-item <?php echo ($current_page === 'settings.php') ? 'active' : ''; ?>">
        <i class="bi bi-gear"></i>Site Ayarları & KVKK
      </a>
    </div>

    <!-- Alt Admin Kullanıcı Bilgisi -->
    <div class="p-3 border-top border-slate-800 d-flex align-items-center justify-content-between small">
      <div>
        <div class="fw-bold text-white"><?php echo e($current_admin['full_name'] ?? 'Yönetici'); ?></div>
        <div class="text-secondary font-monospace" style="font-size: 0.7rem;"><?php echo e($current_admin['role'] ?? 'superadmin'); ?></div>
      </div>
      <a href="/admin/login.php?action=logout" class="btn btn-sm btn-outline-danger py-1 px-2" title="Çıkış Yap">
        <i class="bi bi-box-arrow-right"></i>
      </a>
    </div>
  </aside>

  <!-- İçerik Alanı -->
  <div class="admin-content">
    <!-- Üst Bar -->
    <header class="admin-topbar d-flex align-items-center justify-content-between">
      <div class="d-flex align-items-center gap-2">
        <h5 class="fw-bold text-navy mb-0"><?php echo e($admin_page_title); ?></h5>
      </div>
      <div class="d-flex align-items-center gap-3 small">
        <span class="text-secondary"><i class="bi bi-clock me-1 text-info"></i><?php echo date('d.m.Y H:i'); ?></span>
        <span class="badge bg-success-subtle text-success fw-bold font-monospace">SİSTEM ÇALIŞIYOR</span>
      </div>
    </header>

    <!-- Sayfa Ana İçeriği -->
    <main class="p-4 flex-grow-1">
