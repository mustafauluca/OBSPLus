<?php
/**
 * E-LEARN - Öğrenci Yönetimi (Student Management)
 */
$page_title = 'Öğrenci Yönetimi';
$current_page = 'students.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Durum Değiştirme / Şifre Sıfırlama POST İşlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $student_id = (int)($_POST['student_id'] ?? 0);

    if ($student_id > 0) {
        if ($action === 'toggle_status') {
            $current = db_fetch_one("SELECT is_active FROM students WHERE id = ?", [$student_id], "i");
            if ($current) {
                $new_val = $current['is_active'] ? 0 : 1;
                db_execute("UPDATE students SET is_active = ? WHERE id = ?", [$new_val, $student_id], "ii");
                $alert_message = "Öğrenci aktiflik durumu başarıyla güncellendi.";
            }
        } elseif ($action === 'toggle_scoreboard') {
            $current = db_fetch_one("SELECT show_on_scoreboard FROM students WHERE id = ?", [$student_id], "i");
            if ($current) {
                $new_val = $current['show_on_scoreboard'] ? 0 : 1;
                db_execute("UPDATE students SET show_on_scoreboard = ? WHERE id = ?", [$new_val, $student_id], "ii");
                $alert_message = "Öğrencinin skor tablosu görünürlüğü güncellendi.";
            }
        } elseif ($action === 'reset_password') {
            $new_password = trim($_POST['new_password'] ?? '');
            if (strlen($new_password) < 6) {
                $alert_message = "Şifre en az 6 karakter olmalıdır.";
                $alert_type = 'danger';
            } else {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                db_execute("UPDATE students SET password_hash = ? WHERE id = ?", [$hash, $student_id], "si");
                $alert_message = "Öğrenci şifresi başarıyla yenilendi.";
            }
        }
    }
}

// Filtre ve Arama
$search = trim($_GET['search'] ?? '');
$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$where = "1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $where .= " AND (student_number LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $like = "%" . $search . "%";
    $params = [$like, $like, $like, $like, $like];
    $types = "sssss";
}

$count_row = db_fetch_one("SELECT COUNT(*) AS total FROM students WHERE $where", $params, $types);
$total_rows = (int)($count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

$students = db_fetch_all(
    "SELECT s.*, 
        (SELECT COUNT(*) FROM exam_attempts WHERE student_id = s.id AND status = 'completed') AS exams_count,
        (SELECT COUNT(*) FROM student_topic_progress WHERE student_id = s.id AND is_completed = 1) AS topics_count
     FROM students s 
     WHERE $where 
     ORDER BY s.id DESC 
     LIMIT $limit OFFSET $offset",
    $params,
    $types
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-info me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-user-graduate text-primary me-2"></i> Kayıtlı Öğrenci Listesi</h5>
                <p class="text-muted small mb-0">Platforma üye olan öğrencilerin hesap, aktiflik ve sınav geçmişini yönetin.</p>
            </div>
            <form method="GET" action="students.php" class="d-flex gap-2">
                <input type="text" name="search" class="form-control form-control-sm" placeholder="Öğrenci No, İsim, E-posta..." value="<?php echo e($search); ?>">
                <button type="submit" class="btn btn-sm btn-primary text-nowrap"><i class="fa-solid fa-magnifying-glass me-1"></i> Ara</button>
                <?php if (!empty($search)): ?>
                    <a href="students.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>Öğrenci No</th>
                        <th>Ad Soyad</th>
                        <th>İletişim</th>
                        <th>Puan</th>
                        <th>İlerleme</th>
                        <th>Skor Tablosu</th>
                        <th>Durum</th>
                        <th>Kayıt Tarihi</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">Kayıtlı öğrenci bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($students as $stu): ?>
                            <tr>
                                <td>
                                    <code><?php echo e($stu['student_number']); ?></code>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($stu['first_name'] . ' ' . $stu['last_name']); ?></div>
                                    <small class="text-muted"><?php echo e($stu['city'] ?: 'Şehir Belirtilmedi'); ?></small>
                                </td>
                                <td>
                                    <div><?php echo e($stu['email']); ?></div>
                                    <small class="text-muted"><?php echo e($stu['phone'] ?: '–'); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-warning text-dark fw-bold px-2 py-1">
                                        <i class="fa-solid fa-star me-1 text-warning"></i> <?php echo number_format($stu['total_score']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border me-1" title="Tamamlanan Konu">
                                        <i class="fa-solid fa-book-open text-primary me-1"></i> <?php echo $stu['topics_count']; ?> Konu
                                    </span>
                                    <span class="badge bg-light text-dark border" title="Çözülen Sınav">
                                        <i class="fa-solid fa-file-signature text-success me-1"></i> <?php echo $stu['exams_count']; ?> Sınav
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" action="students.php" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_scoreboard">
                                        <input type="hidden" name="student_id" value="<?php echo $stu['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none" title="Görünürlüğü değiştir">
                                            <?php if ($stu['show_on_scoreboard']): ?>
                                                <span class="badge bg-success-subtle text-success"><i class="fa-solid fa-eye me-1"></i> Açık</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary-subtle text-secondary"><i class="fa-solid fa-eye-slash me-1"></i> Gizli</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" action="students.php" class="d-inline">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="student_id" value="<?php echo $stu['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-link p-0 text-decoration-none" title="Durumu değiştir">
                                            <?php if ($stu['is_active']): ?>
                                                <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><i class="fa-solid fa-ban me-1"></i> Pasif</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y', strtotime($stu['created_at'])); ?>
                                </td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#resetModal<?php echo $stu['id']; ?>" title="Şifre Sıfırla">
                                        <i class="fa-solid fa-key"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Şifre Sıfırlama Modal -->
                            <div class="modal fade" id="resetModal<?php echo $stu['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered modal-sm">
                                    <div class="modal-content">
                                        <form method="POST" action="students.php">
                                            <input type="hidden" name="action" value="reset_password">
                                            <input type="hidden" name="student_id" value="<?php echo $stu['id']; ?>">
                                            <div class="modal-header">
                                                <h6 class="modal-title fw-bold">Şifre Sıfırla</h6>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p class="small text-muted mb-2"><strong><?php echo e($stu['first_name'] . ' ' . $stu['last_name']); ?></strong> için yeni şifre belirleyin:</p>
                                                <input type="password" name="new_password" class="form-control form-control-sm" placeholder="Yeni Şifre (En az 6 karakter)" required>
                                            </div>
                                            <div class="modal-footer p-2">
                                                <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Kaydet</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
