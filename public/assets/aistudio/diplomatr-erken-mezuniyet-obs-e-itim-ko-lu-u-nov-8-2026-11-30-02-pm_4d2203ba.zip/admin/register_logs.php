<?php
/**
 * E-LEARN - Öğrenci Kayıt Denemeleri ve Güvenlik Logları (Register Logs)
 */
$page_title = 'Öğrenci Kayıt Logları';
$current_page = 'register_logs.php';
require_once __DIR__ . '/includes/admin_header.php';

// Filtreler ve Sayfalama
$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 25;
$offset = ($page - 1) * $limit;

$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$where_clauses = ["1=1"];
$params = [];
$types = "";

if (!empty($search)) {
    $where_clauses[] = "(r.student_number LIKE ? OR r.full_name LIKE ? OR r.email LIKE ? OR r.ip_address LIKE ?)";
    $like = "%" . $search . "%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= "ssss";
}

if ($status_filter === 'success' || $status_filter === 'failed') {
    $where_clauses[] = "r.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

$where_sql = implode(" AND ", $where_clauses);

// Toplam Kayıt
$count_row = db_fetch_one("SELECT COUNT(*) AS total FROM student_register_logs r WHERE $where_sql", $params, $types);
$total_rows = (int)($count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

// Logları Çek
$logs = db_fetch_all(
    "SELECT r.* FROM student_register_logs r 
     WHERE $where_sql 
     ORDER BY r.id DESC 
     LIMIT $limit OFFSET $offset",
    $params,
    $types
);

// Özet Metrikler
$stats = db_fetch_one("SELECT 
    COUNT(*) AS total_all,
    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) AS today_total,
    SUM(CASE WHEN DATE(created_at) = CURDATE() AND status = 'success' THEN 1 ELSE 0 END) AS today_success,
    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS total_success
FROM student_register_logs");
?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BUGÜNKÜ KAYIT BAŞVURULARI</span>
            <h4 class="fw-bold my-1"><?php echo number_format($stats['today_total'] ?? 0); ?></h4>
            <span class="text-muted small">Bugün açılan hesap adımları</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BUGÜN BAŞARILI KAYIT</span>
            <h4 class="fw-bold my-1 text-success"><?php echo number_format($stats['today_success'] ?? 0); ?></h4>
            <span class="text-success small"><i class="fa-solid fa-user-plus me-1"></i> Yeni onaylı öğrenci</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">TOPLAM BAŞARILI KAYIT</span>
            <h4 class="fw-bold my-1 text-primary"><?php echo number_format($stats['total_success'] ?? 0); ?></h4>
            <span class="text-primary small"><i class="fa-solid fa-graduation-cap me-1"></i> Doğrulanmış üyelik</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">TOPLAM LOGLANAN İSTEK</span>
            <h4 class="fw-bold my-1"><?php echo number_format($stats['total_all'] ?? 0); ?></h4>
            <span class="text-secondary small">Tüm denemeler</span>
        </div>
    </div>
</div>

<!-- Filtreler -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="register_logs.php" class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Öğrenci No, İsim, E-posta veya IP Ara..." value="<?php echo e($search); ?>">
                </div>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Tüm Kayıt Denemeleri</option>
                    <option value="success" <?php echo $status_filter === 'success' ? 'selected' : ''; ?>>Yalnızca Başarılı</option>
                    <option value="failed" <?php echo $status_filter === 'failed' ? 'selected' : ''; ?>>Yalnızca Başarısız</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary flex-fill">
                    <i class="fa-solid fa-filter me-1"></i> Filtrele
                </button>
                <a href="register_logs.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <a href="export.php?type=register_logs" class="btn btn-sm btn-success text-nowrap" title="CSV İndir">
                    <i class="fa-solid fa-file-csv me-1"></i> CSV
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Log Tablosu -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-user-plus text-primary me-2"></i> Öğrenci Kayıt Denetim Kayıtları (<?php echo number_format($total_rows); ?> Kayıt)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Öğrenci No</th>
                        <th>Ad Soyad</th>
                        <th>E-Posta / Telefon</th>
                        <th>IP Adresi</th>
                        <th>Cihaz / Tarayıcı</th>
                        <th>Durum</th>
                        <th>Açıklama / Hata</th>
                        <th>Tarih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td class="fw-semibold">
                                    <code><?php echo e($row['student_number']); ?></code>
                                </td>
                                <td class="fw-semibold text-dark">
                                    <?php echo e($row['full_name']); ?>
                                </td>
                                <td>
                                    <span><?php echo e($row['email']); ?></span><br>
                                    <span class="text-muted small"><?php echo e($row['phone'] ?: '–'); ?></span>
                                </td>
                                <td>
                                    <code><?php echo e($row['ip_address']); ?></code>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border me-1"><?php echo ucfirst(e($row['device_type'])); ?></span>
                                    <span class="text-muted"><?php echo e($row['browser']); ?></span>
                                </td>
                                <td>
                                    <?php if ($row['status'] === 'success'): ?>
                                        <span class="badge bg-success-subtle text-success">
                                            <i class="fa-solid fa-circle-check me-1"></i> Başarılı
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">
                                            <i class="fa-solid fa-circle-xmark me-1"></i> Başarısız
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['failure_reason'])): ?>
                                        <span class="text-danger small"><?php echo e($row['failure_reason']); ?></span>
                                    <?php else: ?>
                                        <span class="text-success small">Hesap Açıldı</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y H:i:s', strtotime($row['created_at'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
