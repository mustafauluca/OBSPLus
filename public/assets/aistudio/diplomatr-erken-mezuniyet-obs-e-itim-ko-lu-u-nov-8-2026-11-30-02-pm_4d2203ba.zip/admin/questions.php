<?php
/**
 * E-LEARN - Soru Havuzu Yönetimi (Question Pool)
 */
$page_title = 'Soru Havuzu Yönetimi';
$current_page = 'questions.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

$courses = db_fetch_all("SELECT id, title, code FROM courses ORDER BY sort_order ASC, title ASC");

$filter_course_id = (int)($_GET['course_id'] ?? ($courses[0]['id'] ?? 0));
$filter_topic_id = (int)($_GET['topic_id'] ?? 0);

$topics = [];
if ($filter_course_id > 0) {
    $topics = db_fetch_all("SELECT id, title FROM topics WHERE course_id = ? ORDER BY sort_order ASC, id ASC", [$filter_course_id], "i");
}

// Soru Ekleme / Silme
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $course_id = (int)($_POST['course_id'] ?? 0);
        $topic_id = (int)($_POST['topic_id'] ?? 0);
        $question_text = trim($_POST['question_text'] ?? '');
        $explanation = trim($_POST['explanation'] ?? '');
        $points = max(1, (int)($_POST['points'] ?? 20));
        $difficulty = trim($_POST['difficulty'] ?? 'medium');
        $correct_opt = trim($_POST['correct_option'] ?? 'A');

        $options = [
            'A' => trim($_POST['opt_a'] ?? ''),
            'B' => trim($_POST['opt_b'] ?? ''),
            'C' => trim($_POST['opt_c'] ?? ''),
            'D' => trim($_POST['opt_d'] ?? ''),
        ];
        if (!empty($_POST['opt_e'])) {
            $options['E'] = trim($_POST['opt_e']);
        }

        if (empty($question_text) || empty($options['A']) || empty($options['B']) || empty($options['C']) || empty($options['D'])) {
            $alert_message = 'Soru metni ve en az 4 seçenek (A, B, C, D) zorunludur.';
            $alert_type = 'danger';
        } else {
            // Soruyu ekle
            $q_insert = db_execute(
                "INSERT INTO questions (course_id, topic_id, question_text, explanation, points, difficulty, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)",
                [$course_id, $topic_id, $question_text, $explanation, $points, $difficulty],
                "iissis"
            );

            // Son eklenen ID'yi al
            $last_q = db_fetch_one("SELECT LAST_INSERT_ID() as id");
            $qid = (int)$last_q['id'];

            if ($qid > 0) {
                $sort = 1;
                foreach ($options as $key => $text) {
                    $is_corr = ($key === $correct_opt) ? 1 : 0;
                    db_execute(
                        "INSERT INTO question_options (question_id, option_key, option_text, is_correct, sort_order) VALUES (?, ?, ?, ?, ?)",
                        [$qid, $key, $text, $is_corr, $sort],
                        "issii"
                    );
                    $sort++;
                }
                $alert_message = "Soru ve şıkları başarıyla eklendi.";
            }
        }
    } elseif ($action === 'delete') {
        $qid = (int)$_POST['id'];
        db_execute("DELETE FROM question_options WHERE question_id = ?", [$qid], "i");
        db_execute("DELETE FROM questions WHERE id = ?", [$qid], "i");
        $alert_message = "Soru havuzdan silindi.";
    }
}

// Soruları Listele
$where_clauses = ["1=1"];
$params = [];
$types = "";

if ($filter_course_id > 0) {
    $where_clauses[] = "q.course_id = ?";
    $params[] = $filter_course_id;
    $types .= "i";
}
if ($filter_topic_id > 0) {
    $where_clauses[] = "q.topic_id = ?";
    $params[] = $filter_topic_id;
    $types .= "i";
}

$where_sql = implode(" AND ", $where_clauses);

$questions = db_fetch_all(
    "SELECT q.*, c.title AS course_title, c.code AS course_code, t.title AS topic_title 
     FROM questions q 
     JOIN courses c ON q.course_id = c.id 
     LEFT JOIN topics t ON q.topic_id = t.id 
     WHERE $where_sql 
     ORDER BY q.id DESC",
    $params,
    $types
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-database text-primary me-2"></i> Soru Havuzu & Değerlendirme Bankası</h5>
                <p class="text-muted small mb-0">Konu testleri ve vize sınavlarında kullanılan çoktan seçmeli soruları yönetin.</p>
            </div>
            <div class="d-flex gap-2">
                <form method="GET" action="questions.php" class="d-flex gap-2">
                    <select name="course_id" class="form-select form-select-sm" onchange="this.form.submit()">
                        <?php foreach ($courses as $c): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $filter_course_id ? 'selected' : ''; ?>>
                                <?php echo e($c['code'] . ' - ' . $c['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <button type="button" class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addQuestionModal">
                    <i class="fa-solid fa-plus me-1"></i> Yeni Soru Ekle
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-list-ol text-primary me-2"></i> Sorular (<?php echo count($questions); ?> Kayıt)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>Soru Metni</th>
                        <th>Ders & Konu</th>
                        <th>Puan</th>
                        <th>Zorluk</th>
                        <th>Doğru Şık & Seçenekler</th>
                        <th class="text-end">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($questions)): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Seçilen derse ait soru bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($questions as $q): ?>
                            <?php
                            $options = db_fetch_all("SELECT * FROM question_options WHERE question_id = ? ORDER BY sort_order ASC", [$q['id']], "i");
                            ?>
                            <tr>
                                <td><?php echo $q['id']; ?></td>
                                <td>
                                    <div class="fw-bold text-dark mb-1"><?php echo e($q['question_text']); ?></div>
                                    <?php if (!empty($q['explanation'])): ?>
                                        <small class="text-muted"><i class="fa-regular fa-lightbulb text-warning me-1"></i> <?php echo e($q['explanation']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><span class="badge bg-light text-dark border"><?php echo e($q['course_code']); ?></span></div>
                                    <small class="text-muted"><?php echo e($q['topic_title'] ?: 'Genel'); ?></small>
                                </td>
                                <td><span class="badge bg-primary-subtle text-primary"><?php echo $q['points']; ?> Puan</span></td>
                                <td>
                                    <?php
                                    $diff_badge = 'bg-success-subtle text-success';
                                    if ($q['difficulty'] === 'medium') $diff_badge = 'bg-warning-subtle text-warning';
                                    if ($q['difficulty'] === 'hard') $diff_badge = 'bg-danger-subtle text-danger';
                                    ?>
                                    <span class="badge <?php echo $diff_badge; ?>"><?php echo ucfirst(e($q['difficulty'])); ?></span>
                                </td>
                                <td>
                                    <div class="d-flex flex-wrap gap-1">
                                        <?php foreach ($options as $opt): ?>
                                            <span class="badge <?php echo $opt['is_correct'] ? 'bg-success' : 'bg-light text-secondary border'; ?>">
                                                <strong><?php echo $opt['option_key']; ?>:</strong> <?php echo e(mb_strimwidth($opt['option_text'], 0, 20, '...')); ?>
                                                <?php if ($opt['is_correct']): ?><i class="fa-solid fa-check ms-1"></i><?php endif; ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <form method="POST" action="questions.php" class="d-inline" onsubmit="return confirm('Bu soruyu havuzdan silmek istediğinize emin misiniz?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $q['id']; ?>">
                                        <input type="hidden" name="course_id" value="<?php echo $filter_course_id; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Soru Ekleme Modal -->
<div class="modal fade" id="addQuestionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form method="POST" action="questions.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h6 class="modal-title fw-bold">Havuzuna Yeni Soru Ekle</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Ders</label>
                            <select name="course_id" class="form-select form-select-sm" required>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $filter_course_id ? 'selected' : ''; ?>>
                                        <?php echo e($c['code'] . ' - ' . $c['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Konu</label>
                            <select name="topic_id" class="form-select form-select-sm">
                                <option value="0">Tüm Konular / Genel Havuz</option>
                                <?php foreach ($topics as $tp): ?>
                                    <option value="<?php echo $tp['id']; ?>"><?php echo e($tp['title']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Soru Metni</label>
                        <textarea name="question_text" class="form-control form-control-sm" rows="3" placeholder="Soru kökünü ve detaylarını buraya yazın..." required></textarea>
                    </div>

                    <!-- Şıklar -->
                    <h6 class="small fw-bold text-muted border-bottom pb-1 mb-2">Çoktan Seçmeli Şıklar</h6>
                    <div class="row g-2 mb-2">
                        <div class="col-12">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text fw-bold">A</span>
                                <input type="text" name="opt_a" class="form-control" placeholder="A şıkkı metni" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text fw-bold">B</span>
                                <input type="text" name="opt_b" class="form-control" placeholder="B şıkkı metni" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text fw-bold">C</span>
                                <input type="text" name="opt_c" class="form-control" placeholder="C şıkkı metni" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text fw-bold">D</span>
                                <input type="text" name="opt_d" class="form-control" placeholder="D şıkkı metni" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group input-group-sm">
                                <span class="input-group-text fw-bold">E</span>
                                <input type="text" name="opt_e" class="form-control" placeholder="E şıkkı metni (Opsiyonel)">
                            </div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <label class="form-label small fw-semibold text-success">Doğru Cevap Şıkkı</label>
                            <select name="correct_option" class="form-select form-select-sm border-success">
                                <option value="A">A Şıkkı</option>
                                <option value="B">B Şıkkı</option>
                                <option value="C">C Şıkkı</option>
                                <option value="D">D Şıkkı</option>
                                <option value="E">E Şıkkı</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Puan Değeri</label>
                            <input type="number" name="points" class="form-control form-control-sm" value="20" min="1" max="100">
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Zorluk Seviyesi</label>
                            <select name="difficulty" class="form-select form-select-sm">
                                <option value="easy">Kolay</option>
                                <option value="medium" selected>Orta</option>
                                <option value="hard">Zor</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Çözüm ve Açıklama (Öğrenci Sınav Sonrası Analizinde Görür)</label>
                        <input type="text" name="explanation" class="form-control form-control-sm" placeholder="Doğru cevabın kısa açıklaması...">
                    </div>
                </div>
                <div class="modal-footer p-2">
                    <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-sm btn-primary">Soruyu Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
