<?php
/**
 * E-LEARN - Öğrenci Giriş Denemeleri ve Güvenlik Logları (Login Logs)
 */
$page_title = 'Öğrenci Giriş Logları';
$current_page = 'login_logs.php';
require_once __DIR__ . '/includes/admin_header.php';

// Filtreler ve Sayfalama
$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 25;
$offset = ($page - 1) * $limit;

$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$where_clauses = ["1=1"];
$params = [];
$types = "";

if (!empty($search)) {
    $where_clauses[] = "(l.student_number LIKE ? OR l.entered_name LIKE ? OR l.ip_address LIKE ?)";
    $like = "%" . $search . "%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= "sss";
}

if ($status_filter === 'success' || $status_filter === 'failed') {
    $where_clauses[] = "l.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

$where_sql = implode(" AND ", $where_clauses);

// Toplam Kayıt
$count_row = db_fetch_one("SELECT COUNT(*) AS total FROM student_login_logs l WHERE $where_sql", $params, $types);
$total_rows = (int)($count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

// Logları Çek
$logs = db_fetch_all(
    "SELECT l.*, s.first_name, s.last_name 
     FROM student_login_logs l 
     LEFT JOIN students s ON l.student_id = s.id 
     WHERE $where_sql 
     ORDER BY l.id DESC 
     LIMIT $limit OFFSET $offset",
    $params,
    $types
);

// Özet Metrikler
$stats = db_fetch_one("SELECT 
    COUNT(*) AS total_all,
    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) AS today_total,
    SUM(CASE WHEN DATE(created_at) = CURDATE() AND status = 'success' THEN 1 ELSE 0 END) AS today_success,
    SUM(CASE WHEN DATE(created_at) = CURDATE() AND status = 'failed' THEN 1 ELSE 0 END) AS today_failed
FROM student_login_logs");
?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BUGÜNKÜ GİRİŞ DENEMELERİ</span>
            <h4 class="fw-bold my-1"><?php echo number_format($stats['today_total'] ?? 0); ?></h4>
            <span class="text-muted small">Toplam istek sayısı</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BAŞARILI GİRİŞLER</span>
            <h4 class="fw-bold my-1 text-success"><?php echo number_format($stats['today_success'] ?? 0); ?></h4>
            <span class="text-success small"><i class="fa-solid fa-check-circle me-1"></i> Doğrulanmış oturumlar</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BAŞARISIZ GİRİŞLER</span>
            <h4 class="fw-bold my-1 text-danger"><?php echo number_format($stats['today_failed'] ?? 0); ?></h4>
            <span class="text-danger small"><i class="fa-solid fa-triangle-exclamation me-1"></i> Şüpheli / Hatalı deneme</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">TÜM ZAMANLAR</span>
            <h4 class="fw-bold my-1"><?php echo number_format($stats['total_all'] ?? 0); ?></h4>
            <span class="text-secondary small">Toplam log kaydı</span>
        </div>
    </div>
</div>

<!-- Filtreler -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="login_logs.php" class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Öğrenci No, İsim veya IP Adresi Ara..." value="<?php echo e($search); ?>">
                </div>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select form-select-sm">
                    <option value="">Tüm Durumlar (Başarılı / Başarısız)</option>
                    <option value="success" <?php echo $status_filter === 'success' ? 'selected' : ''; ?>>Yalnızca Başarılı</option>
                    <option value="failed" <?php echo $status_filter === 'failed' ? 'selected' : ''; ?>>Yalnızca Başarısız</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary flex-fill">
                    <i class="fa-solid fa-filter me-1"></i> Filtrele
                </button>
                <a href="login_logs.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <a href="export.php?type=login_logs" class="btn btn-sm btn-success text-nowrap" title="CSV İndir">
                    <i class="fa-solid fa-file-csv me-1"></i> CSV
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Log Tablosu -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-shield-halved text-primary me-2"></i> Öğrenci Giriş ve Denetim Kayıtları (<?php echo number_format($total_rows); ?> Kayıt)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Öğrenci No</th>
                        <th>Girilen İsim / Eşleşen Profil</th>
                        <th>IP Adresi</th>
                        <th>Cihaz / OS / Tarayıcı</th>
                        <th>Durum</th>
                        <th>Hata Nedeni</th>
                        <th>Zaman</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td class="fw-semibold">
                                    <code><?php echo e($row['student_number'] ?: '–'); ?></code>
                                </td>
                                <td>
                                    <?php if (!empty($row['first_name'])): ?>
                                        <span class="fw-bold text-dark"><?php echo e($row['first_name'] . ' ' . $row['last_name']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted"><?php echo e($row['entered_name'] ?: '–'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <code><?php echo e($row['ip_address']); ?></code>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border me-1"><?php echo ucfirst(e($row['device_type'])); ?></span>
                                    <span class="text-muted"><?php echo e($row['operating_system']); ?> / <?php echo e($row['browser']); ?></span>
                                </td>
                                <td>
                                    <?php if ($row['status'] === 'success'): ?>
                                        <span class="badge bg-success-subtle text-success">
                                            <i class="fa-solid fa-circle-check me-1"></i> Başarılı
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">
                                            <i class="fa-solid fa-circle-xmark me-1"></i> Başarısız
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['failure_reason'])): ?>
                                        <span class="text-danger small"><?php echo e($row['failure_reason']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">–</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y H:i:s', strtotime($row['created_at'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
