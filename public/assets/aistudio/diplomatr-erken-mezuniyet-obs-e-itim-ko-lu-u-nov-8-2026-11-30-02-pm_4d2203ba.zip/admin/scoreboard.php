<?php
/**
 * E-LEARN - Skor Tablosu ve Sıralama Yönetimi (Scoreboard Management)
 */
$page_title = 'Skor Tablosu & Başarı Sıralaması';
$current_page = 'scoreboard.php';
require_once __DIR__ . '/includes/admin_header.php';

$alert_message = '';
$alert_type = 'success';

// Sıralamaları Yeniden Hesapla POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recalculate'])) {
    $students = db_fetch_all("SELECT id FROM students");
    foreach ($students as $stu) {
        update_student_total_score((int)$stu['id']);
    }
    $alert_message = "Tüm öğrenci puanları ve sıralamaları başarıyla güncellendi.";
}

// Kurs bazlı #1 öğrenciler
$course_leaders = get_course_top_students();

// Genel En Yüksek Puanlı Öğrenciler (Top 25)
$top_students = db_fetch_all(
    "SELECT s.*, 
        (SELECT COUNT(*) FROM exam_attempts WHERE student_id = s.id AND status = 'completed') AS completed_exams
     FROM students s 
     ORDER BY s.total_score DESC 
     LIMIT 25"
);
?>

<?php if (!empty($alert_message)): ?>
    <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo e($alert_message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-trophy text-warning me-2"></i> Başarı Skor Tablosu ve Sıralamalar</h5>
                <p class="text-muted small mb-0">Ana sayfada yayınlanan ders birincileri ve genel başarı sıralamalarını denetleyin. (KVKK gereği ana sayfada öğrenci isimleri "Ahmet Y." şeklinde maskelenmektedir).</p>
            </div>
            <form method="POST" action="scoreboard.php">
                <button type="submit" name="recalculate" value="1" class="btn btn-outline-primary btn-sm">
                    <i class="fa-solid fa-rotate me-1"></i> Puanları Yeniden Hesapla
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Ders Birincileri Kartları (Ana Sayfada Gözüken) -->
<h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-crown text-warning me-2"></i> Ders Bazında Birinciler (Ana Sayfa Vitrini)</h6>
<div class="row g-3 mb-4">
    <?php if (empty($course_leaders)): ?>
        <div class="col-12"><div class="alert alert-light border">Henüz sınav tamamlayan öğrenci bulunmuyor.</div></div>
    <?php else: ?>
        <?php foreach ($course_leaders as $lead): ?>
            <div class="col-md-4 col-sm-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-primary-subtle text-primary"><?php echo e($lead['course_code']); ?></span>
                            <span class="badge bg-warning text-dark"><i class="fa-solid fa-star me-1"></i> <?php echo number_format($lead['top_score']); ?> Puan</span>
                        </div>
                        <h6 class="fw-bold text-dark mb-1"><?php echo e($lead['course_title']); ?></h6>
                        <hr class="my-2">
                        <div class="small">
                            <span class="text-muted">Gerçek İsim:</span> <strong><?php echo e($lead['first_name'] . ' ' . $lead['last_name']); ?></strong><br>
                            <span class="text-muted">Ana Sayfa Maskeli:</span> <span class="badge bg-light text-dark border"><?php echo e($lead['masked_name']); ?></span><br>
                            <span class="text-muted">Öğrenci No:</span> <code><?php echo e($lead['student_number']); ?></code>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Genel Başarı Sıralaması -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-ranking-star text-primary me-2"></i> Genel Puan Sıralaması (Top 25 Öğrenci)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th style="width: 50px;">Sıra</th>
                        <th>Öğrenci No</th>
                        <th>Ad Soyad (Gerçek)</th>
                        <th>Maskeli İsim (KVKK)</th>
                        <th>Toplam Puan</th>
                        <th>Tamamlanan Sınav</th>
                        <th>Skor Tablosu İzni</th>
                        <th>Kayıt Tarihi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($top_students)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">Kayıtlı öğrenci bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php $rank = 1; ?>
                        <?php foreach ($top_students as $st): ?>
                            <tr>
                                <td>
                                    <?php if ($rank === 1): ?>
                                        <span class="badge bg-warning text-dark px-2 py-1"><i class="fa-solid fa-crown me-1"></i> 1.</span>
                                    <?php elseif ($rank === 2): ?>
                                        <span class="badge bg-secondary text-white px-2 py-1"><i class="fa-solid fa-medal me-1"></i> 2.</span>
                                    <?php elseif ($rank === 3): ?>
                                        <span class="badge bg-danger-subtle text-danger px-2 py-1"><i class="fa-solid fa-medal me-1"></i> 3.</span>
                                    <?php else: ?>
                                        <span class="fw-bold text-muted ps-2"><?php echo $rank; ?>.</span>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($st['student_number']); ?></code></td>
                                <td class="fw-bold text-dark"><?php echo e($st['first_name'] . ' ' . $st['last_name']); ?></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e(mask_student_name($st['first_name'], $st['last_name'])); ?></span></td>
                                <td>
                                    <h6 class="fw-bold mb-0 text-primary"><?php echo number_format($st['total_score']); ?></h6>
                                </td>
                                <td><?php echo $st['completed_exams']; ?> Sınav</td>
                                <td>
                                    <?php if ($st['show_on_scoreboard']): ?>
                                        <span class="badge bg-success-subtle text-success">İzin Verildi</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary">Gizli</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted text-nowrap"><?php echo date('d.m.Y', strtotime($st['created_at'])); ?></td>
                            </tr>
                            <?php $rank++; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
