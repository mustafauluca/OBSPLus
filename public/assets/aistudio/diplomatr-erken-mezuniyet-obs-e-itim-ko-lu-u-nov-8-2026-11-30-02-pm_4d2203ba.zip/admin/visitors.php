<?php
/**
 * E-LEARN - Detaylı Ziyaretçi ve Trafik Analitiği (Visitors Analytics)
 */
$page_title = 'Ziyaretçi & Trafik Analitiği';
$current_page = 'visitors.php';
require_once __DIR__ . '/includes/admin_header.php';

// Filtreler ve Sayfalama
$page = max(1, (int)($_GET['p'] ?? 1));
$limit = 25;
$offset = ($page - 1) * $limit;

$search_ip = trim($_GET['ip'] ?? '');
$filter_device = trim($_GET['device'] ?? '');

$where_clauses = ["1=1"];
$params = [];
$types = "";

if (!empty($search_ip)) {
    $where_clauses[] = "v.ip_address LIKE ?";
    $params[] = "%" . $search_ip . "%";
    $types .= "s";
}
if (!empty($filter_device)) {
    $where_clauses[] = "v.device_type = ?";
    $params[] = $filter_device;
    $types .= "s";
}

$where_sql = implode(" AND ", $where_clauses);

// Toplam Kayıt Sayısı
$count_query = "SELECT COUNT(*) AS total FROM visitor_logs v WHERE " . $where_sql;
$total_count_row = db_fetch_one($count_query, $params, $types);
$total_rows = (int)($total_count_row['total'] ?? 0);
$total_pages = ceil($total_rows / $limit);

// Ziyaret Loglarını Çek
$logs_query = "SELECT v.*, s.student_number, s.first_name, s.last_name 
               FROM visitor_logs v 
               LEFT JOIN students s ON v.student_id = s.id 
               WHERE $where_sql 
               ORDER BY v.id DESC 
               LIMIT $limit OFFSET $offset";
$logs = db_fetch_all($logs_query, $params, $types);

// İstatistiksel Özetler
$today_stats = db_fetch_one("SELECT COUNT(*) AS total, COUNT(DISTINCT visitor_hash) AS uniq FROM visitor_logs WHERE DATE(visit_time) = CURDATE()");
$last7_stats = db_fetch_one("SELECT COUNT(*) AS total, COUNT(DISTINCT visitor_hash) AS uniq FROM visitor_logs WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$last30_stats = db_fetch_one("SELECT COUNT(*) AS total, COUNT(DISTINCT visitor_hash) AS uniq FROM visitor_logs WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
$all_time_stats = db_fetch_one("SELECT COUNT(*) AS total, COUNT(DISTINCT visitor_hash) AS uniq FROM visitor_logs");

// En Çok Ziyaret Edilen Sayfalar (Top 8)
$top_pages = db_fetch_all("SELECT page_url, page_name, COUNT(*) AS hit_count FROM visitor_logs GROUP BY page_url, page_name ORDER BY hit_count DESC LIMIT 8");

// Tarayıcı Dağılımı (Top 5)
$top_browsers = db_fetch_all("SELECT browser, COUNT(*) AS cnt FROM visitor_logs WHERE browser != '' GROUP BY browser ORDER BY cnt DESC LIMIT 5");

// Saatlik Dağılım (00 - 23 saatleri)
$hourly_rows = db_fetch_all("SELECT HOUR(visit_time) AS h, COUNT(*) AS cnt FROM visitor_logs WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY HOUR(visit_time) ORDER BY h ASC");
$hourly_data = array_fill(0, 24, 0);
foreach ($hourly_rows as $hr) {
    $hourly_data[(int)$hr['h']] = (int)$hr['cnt'];
}
$hours_labels = [];
for ($i = 0; $i < 24; $i++) {
    $hours_labels[] = sprintf('%02d:00', $i);
}

// 30 Günlük Ziyaret Grafiği
$thirty_days_chart = get_visitor_chart_data(30);
?>

<!-- Özet Kartları -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">BUGÜN</span>
            <h4 class="fw-bold my-1"><?php echo number_format($today_stats['total'] ?? 0); ?></h4>
            <span class="text-success small"><i class="fa-solid fa-user me-1"></i> <?php echo number_format($today_stats['uniq'] ?? 0); ?> tekil ziyaretçi</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">SON 7 GÜN</span>
            <h4 class="fw-bold my-1"><?php echo number_format($last7_stats['total'] ?? 0); ?></h4>
            <span class="text-primary small"><i class="fa-solid fa-users me-1"></i> <?php echo number_format($last7_stats['uniq'] ?? 0); ?> tekil</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">SON 30 GÜN</span>
            <h4 class="fw-bold my-1"><?php echo number_format($last30_stats['total'] ?? 0); ?></h4>
            <span class="text-info small"><i class="fa-solid fa-calendar-check me-1"></i> <?php echo number_format($last30_stats['uniq'] ?? 0); ?> tekil</span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3">
            <span class="text-muted small fw-semibold">TÜM ZAMANLAR</span>
            <h4 class="fw-bold my-1"><?php echo number_format($all_time_stats['total'] ?? 0); ?></h4>
            <span class="text-dark small"><i class="fa-solid fa-chart-pie me-1"></i> <?php echo number_format($all_time_stats['uniq'] ?? 0); ?> tekil</span>
        </div>
    </div>
</div>

<!-- Grafikler Bölümü -->
<div class="row g-3 mb-4">
    <!-- Son 30 Günlük Ziyaret Grafiği -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-chart-line text-primary me-2"></i> Son 30 Günlük Ziyaret & Tekil Ziyaretçi Dağılımı
                </h6>
            </div>
            <div class="card-body px-3 pb-3">
                <div style="height: 260px;">
                    <canvas id="chart30Days"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Saatlik Ziyaret Dağılımı -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-clock text-warning me-2"></i> Ziyaret Saatleri Dağılımı (00-23)
                </h6>
            </div>
            <div class="card-body px-3 pb-3">
                <div style="height: 260px;">
                    <canvas id="chartHourly"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <!-- En Çok Ziyaret Edilen Sayfalar -->
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-fire text-danger me-2"></i> En Çok Ziyaret Edilen Sayfalar
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead class="table-light">
                            <tr>
                                <th>Sayfa / Başlık</th>
                                <th>URL</th>
                                <th class="text-end">Ziyaret Sayısı</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_pages as $tp): ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo e($tp['page_name'] ?: 'Belirtilmemiş'); ?></td>
                                    <td><code><?php echo e($tp['page_url']); ?></code></td>
                                    <td class="text-end"><span class="badge bg-primary"><?php echo number_format($tp['hit_count']); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Tarayıcı Dağılımı -->
    <div class="col-lg-5">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-compass text-info me-2"></i> Tarayıcı Dağılımı
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead class="table-light">
                            <tr>
                                <th>Tarayıcı</th>
                                <th class="text-end">Hit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_browsers as $tb): ?>
                                <tr>
                                    <td><i class="fa-brands fa-chrome text-primary me-2"></i> <?php echo e($tb['browser']); ?></td>
                                    <td class="text-end fw-semibold"><?php echo number_format($tb['cnt']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filtreleme ve Arama -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="visitors.php" class="row g-2 align-items-center">
            <div class="col-md-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" name="ip" class="form-control" placeholder="IP Adresi Ara..." value="<?php echo e($search_ip); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="device" class="form-select form-select-sm">
                    <option value="">Tüm Cihaz Türleri</option>
                    <option value="desktop" <?php echo $filter_device === 'desktop' ? 'selected' : ''; ?>>Masaüstü</option>
                    <option value="mobile" <?php echo $filter_device === 'mobile' ? 'selected' : ''; ?>>Mobil</option>
                    <option value="tablet" <?php echo $filter_device === 'tablet' ? 'selected' : ''; ?>>Tablet</option>
                    <option value="bot" <?php echo $filter_device === 'bot' ? 'selected' : ''; ?>>Bot / Tarayıcı</option>
                </select>
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary flex-fill">
                    <i class="fa-solid fa-filter me-1"></i> Filtrele
                </button>
                <a href="visitors.php" class="btn btn-sm btn-light border text-muted">Sıfırla</a>
                <a href="export.php?type=visitors" class="btn btn-sm btn-success text-nowrap" title="CSV Olarak İndir">
                    <i class="fa-solid fa-file-csv me-1"></i> CSV
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Ziyaretçi Logları Tablosu -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
        <h6 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-list-check text-primary me-2"></i> Ziyaret Geçmişi ve Oturum Logları (<?php echo number_format($total_rows); ?> Kayıt)
        </h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>IP Adresi</th>
                        <th>Kullanıcı / Öğrenci</th>
                        <th>Sayfa URL</th>
                        <th>Cihaz / OS / Tarayıcı</th>
                        <th>Referans (Kaynak)</th>
                        <th>Tarih & Saat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">Kayıt bulunamadı.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td>
                                    <code><?php echo e($row['ip_address']); ?></code>
                                </td>
                                <td>
                                    <?php if (!empty($row['student_number'])): ?>
                                        <span class="badge bg-primary-subtle text-primary">
                                            <i class="fa-solid fa-graduation-cap me-1"></i> <?php echo e($row['student_number']); ?> (<?php echo e($row['first_name'] . ' ' . $row['last_name']); ?>)
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-muted border">Anonim Ziyaretçi</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-truncate" style="max-width: 200px;" title="<?php echo e($row['page_url']); ?>">
                                    <strong><?php echo e($row['page_name'] ?: '–'); ?></strong><br>
                                    <span class="text-muted"><?php echo e($row['page_url']); ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border me-1"><?php echo ucfirst(e($row['device_type'])); ?></span>
                                    <span class="text-muted"><?php echo e($row['operating_system']); ?> / <?php echo e($row['browser']); ?></span>
                                </td>
                                <td class="text-muted text-truncate" style="max-width: 140px;" title="<?php echo e($row['referrer']); ?>">
                                    <?php echo e($row['referrer'] ?: 'Doğrudan (Direct)'); ?>
                                </td>
                                <td class="text-muted text-nowrap">
                                    <?php echo date('d.m.Y H:i:s', strtotime($row['visit_time'])); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Sayfalama (Pagination) -->
    <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-transparent border-0 d-flex justify-content-center py-3">
            <nav>
                <ul class="pagination pagination-sm mb-0">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page - 1); ?>&ip=<?php echo urlencode($search_ip); ?>&device=<?php echo urlencode($filter_device); ?>">&laquo; Önceki</a></li>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?p=<?php echo $i; ?>&ip=<?php echo urlencode($search_ip); ?>&device=<?php echo urlencode($filter_device); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?p=<?php echo ($page + 1); ?>&ip=<?php echo urlencode($search_ip); ?>&device=<?php echo urlencode($filter_device); ?>">Sonraki &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 30 Günlük Chart
    const ctx30 = document.getElementById('chart30Days');
    if (ctx30) {
        new Chart(ctx30, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($thirty_days_chart['labels']); ?>,
                datasets: [
                    {
                        type: 'line',
                        label: 'Tekil Ziyaretçi',
                        data: <?php echo json_encode($thirty_days_chart['unique_visitors']); ?>,
                        borderColor: '#10b981',
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 2,
                        yAxisID: 'y'
                    },
                    {
                        type: 'bar',
                        label: 'Toplam Hit',
                        data: <?php echo json_encode($thirty_days_chart['total_hits']); ?>,
                        backgroundColor: 'rgba(37, 99, 235, 0.4)',
                        borderColor: '#2563eb',
                        borderWidth: 1,
                        yAxisID: 'y'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // Saatlik Chart
    const ctxH = document.getElementById('chartHourly');
    if (ctxH) {
        new Chart(ctxH, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($hours_labels); ?>,
                datasets: [{
                    label: 'Ziyaret Sayısı',
                    data: <?php echo json_encode($hourly_data); ?>,
                    backgroundColor: 'rgba(245, 158, 11, 0.7)',
                    borderColor: '#f59e0b',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
