<?php
/**
 * E-LEARN - Yönetici Kontrol Paneli (Admin Dashboard)
 */
$page_title = 'Yönetim Paneli – Genel Bakış';
$current_page = 'dashboard.php';
require_once __DIR__ . '/includes/admin_header.php';

// Temel İstatistikleri Çek
$today_visitors_res = db_fetch_one("SELECT COUNT(*) AS total_hits, COUNT(DISTINCT visitor_hash) AS unique_visitors FROM visitor_logs WHERE DATE(visit_time) = CURDATE()");
$today_hits = (int)($today_visitors_res['total_hits'] ?? 0);
$today_unique = (int)($today_visitors_res['unique_visitors'] ?? 0);

$total_students_res = db_fetch_one("SELECT COUNT(*) AS total FROM students");
$total_students = (int)($total_students_res['total'] ?? 0);

$total_exams_res = db_fetch_one("SELECT COUNT(*) AS total FROM exam_attempts WHERE status = 'completed'");
$total_exams = (int)($total_exams_res['total'] ?? 0);

$total_courses_res = db_fetch_one("SELECT COUNT(*) AS total FROM courses WHERE is_active = 1");
$total_courses = (int)($total_courses_res['total'] ?? 0);

$today_logins_res = db_fetch_one("SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS success_cnt FROM student_login_logs WHERE DATE(created_at) = CURDATE()");
$today_logins = (int)($today_logins_res['total'] ?? 0);
$today_success_logins = (int)($today_logins_res['success_cnt'] ?? 0);

// Son 7 Günlük Ziyaret Grafiği Verileri
$seven_days_data = get_visitor_chart_data(7);

// Cihaz Dağılımı Verileri
$device_stats = get_device_stats();

// Son 8 Ziyaretçi Kaydı
$recent_visitors = db_fetch_all("SELECT * FROM visitor_logs ORDER BY id DESC LIMIT 8");

// Son 8 Öğrenci Giriş Denemesi
$recent_logins = db_fetch_all("SELECT * FROM student_login_logs ORDER BY id DESC LIMIT 8");

// Son 6 Sınav Sonucu
$recent_exam_attempts = db_fetch_all(
    "SELECT a.*, s.student_number, s.first_name, s.last_name, e.title AS exam_title, c.title AS course_title
     FROM exam_attempts a
     JOIN students s ON a.student_id = s.id
     JOIN exams e ON a.exam_id = e.id
     JOIN courses c ON e.course_id = c.id
     WHERE a.status = 'completed'
     ORDER BY a.id DESC LIMIT 6"
);
?>

<div class="row g-3 mb-4">
    <!-- Stat 1: Bugünkü Ziyaretçi -->
    <div class="col-xl-3 col-sm-6">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Bugünkü Ziyaret</span>
                        <h3 class="fw-bold my-1 text-dark"><?php echo number_format($today_hits); ?></h3>
                        <span class="text-success small fw-medium">
                            <i class="fa-solid fa-user-check me-1"></i> <?php echo number_format($today_unique); ?> tekil ziyaretçi
                        </span>
                    </div>
                    <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                        <i class="fa-solid fa-chart-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stat 2: Kayıtlı Öğrenci -->
    <div class="col-xl-3 col-sm-6">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Toplam Öğrenci</span>
                        <h3 class="fw-bold my-1 text-dark"><?php echo number_format($total_students); ?></h3>
                        <span class="text-primary small fw-medium">
                            <i class="fa-solid fa-arrow-trend-up me-1"></i> Aktif Öğrenci Havuzu
                        </span>
                    </div>
                    <div class="stat-icon bg-info bg-opacity-10 text-info">
                        <i class="fa-solid fa-user-graduate"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stat 3: Tamamlanan Sınavlar -->
    <div class="col-xl-3 col-sm-6">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Tamamlanan Sınav</span>
                        <h3 class="fw-bold my-1 text-dark"><?php echo number_format($total_exams); ?></h3>
                        <span class="text-success small fw-medium">
                            <i class="fa-solid fa-circle-check me-1"></i> Başarı Değerlendirmesi
                        </span>
                    </div>
                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                        <i class="fa-solid fa-file-signature"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stat 4: Bugünkü Girişler -->
    <div class="col-xl-3 col-sm-6">
        <div class="card stat-card border-0 shadow-sm">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Bugünkü Girişler</span>
                        <h3 class="fw-bold my-1 text-dark"><?php echo number_format($today_logins); ?></h3>
                        <span class="text-secondary small fw-medium">
                            <i class="fa-solid fa-lock me-1"></i> <?php echo number_format($today_success_logins); ?> başarılı giriş
                        </span>
                    </div>
                    <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                        <i class="fa-solid fa-fingerprint"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="row g-3 mb-4">
    <!-- Son 7 Günlük Ziyaret Grafiği -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-chart-area text-primary me-2"></i> Son 7 Gün Ziyaretçi Eğilimi
                </h6>
                <a href="visitors.php" class="btn btn-sm btn-light border text-muted">Detaylı İstatistikler &raquo;</a>
            </div>
            <div class="card-body px-3 pb-3">
                <div style="height: 280px;">
                    <canvas id="visitorTrendChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Cihaz Dağılımı -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-pie-chart text-info me-2"></i> Ziyaretçi Cihaz Dağılımı
                </h6>
            </div>
            <div class="card-body px-3 pb-3 d-flex flex-column align-items-center justify-content-center">
                <div style="height: 200px; width: 100%;">
                    <canvas id="deviceChart"></canvas>
                </div>
                <div class="row w-100 mt-3 text-center small">
                    <div class="col-6 mb-2">
                        <span class="badge bg-primary me-1">&bull;</span> Masaüstü: <strong><?php echo $device_stats['desktop']; ?></strong>
                    </div>
                    <div class="col-6 mb-2">
                        <span class="badge bg-info me-1">&bull;</span> Mobil: <strong><?php echo $device_stats['mobile']; ?></strong>
                    </div>
                    <div class="col-6">
                        <span class="badge bg-warning me-1">&bull;</span> Tablet: <strong><?php echo $device_stats['tablet']; ?></strong>
                    </div>
                    <div class="col-6">
                        <span class="badge bg-secondary me-1">&bull;</span> Bot / Diğer: <strong><?php echo $device_stats['bot']; ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Tables Section -->
<div class="row g-3">
    <!-- Son Ziyaretçiler -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-globe text-primary me-2"></i> Anlık Ziyaretçi Kayıtları
                </h6>
                <a href="visitors.php" class="btn btn-sm btn-link text-decoration-none p-0">Tümünü Gör</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead class="table-light">
                            <tr>
                                <th>IP Adresi</th>
                                <th>Sayfa</th>
                                <th>Cihaz / Tarayıcı</th>
                                <th>Zaman</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_visitors)): ?>
                                <tr><td colspan="4" class="text-center py-3 text-muted">Henüz ziyaret kaydı yok.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_visitors as $v): ?>
                                    <tr>
                                        <td>
                                            <code><?php echo e($v['ip_address']); ?></code>
                                            <?php if (!empty($v['student_id'])): ?>
                                                <span class="badge bg-primary-subtle text-primary ms-1">Öğrenci</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-truncate" style="max-width: 140px;" title="<?php echo e($v['page_url']); ?>">
                                            <?php echo e($v['page_name'] ?: $v['page_url']); ?>
                                        </td>
                                        <td>
                                            <?php
                                            $device_icon = 'fa-desktop';
                                            if ($v['device_type'] === 'mobile') $device_icon = 'fa-mobile-screen';
                                            if ($v['device_type'] === 'tablet') $device_icon = 'fa-tablet-screen-button';
                                            if ($v['device_type'] === 'bot') $device_icon = 'fa-robot text-danger';
                                            ?>
                                            <i class="fa-solid <?php echo $device_icon; ?> me-1 text-muted"></i>
                                            <?php echo e($v['browser'] ?: 'Diğer'); ?>
                                        </td>
                                        <td class="text-muted text-nowrap">
                                            <?php echo date('H:i:s', strtotime($v['visit_time'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Son Öğrenci Giriş Denemeleri -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-transparent border-0 d-flex justify-content-between align-items-center pt-3 pb-2 px-3">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-fingerprint text-warning me-2"></i> Son Öğrenci Giriş Denemeleri
                </h6>
                <a href="login_logs.php" class="btn btn-sm btn-link text-decoration-none p-0">Tümünü Gör</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead class="table-light">
                            <tr>
                                <th>Öğrenci No</th>
                                <th>IP Adresi</th>
                                <th>Durum</th>
                                <th>Zaman</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_logins)): ?>
                                <tr><td colspan="4" class="text-center py-3 text-muted">Henüz giriş kaydı yok.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_logins as $l): ?>
                                    <tr>
                                        <td class="fw-semibold">
                                            <?php echo e($l['student_number']); ?>
                                        </td>
                                        <td>
                                            <code><?php echo e($l['ip_address']); ?></code>
                                        </td>
                                        <td>
                                            <?php if ($l['status'] === 'success'): ?>
                                                <span class="badge bg-success-subtle text-success">
                                                    <i class="fa-solid fa-check me-1"></i> Başarılı
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger" title="<?php echo e($l['failure_reason']); ?>">
                                                    <i class="fa-solid fa-xmark me-1"></i> Başarısız
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-muted text-nowrap">
                                            <?php echo date('H:i:s', strtotime($l['created_at'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Ziyaretçi Trend Grafiği (Line Chart)
    const ctxVisitor = document.getElementById('visitorTrendChart');
    if (ctxVisitor) {
        new Chart(ctxVisitor, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($seven_days_data['labels']); ?>,
                datasets: [
                    {
                        label: 'Toplam Ziyaret',
                        data: <?php echo json_encode($seven_days_data['total_hits']); ?>,
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        fill: true,
                        tension: 0.35,
                        borderWidth: 2.5
                    },
                    {
                        label: 'Tekil Ziyaretçi',
                        data: <?php echo json_encode($seven_days_data['unique_visitors']); ?>,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        fill: true,
                        tension: 0.35,
                        borderWidth: 2.5
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: { boxWidth: 12, font: { family: 'Plus Jakarta Sans', size: 12 } }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { precision: 0 }
                    }
                }
            }
        });
    }

    // 2. Cihaz Dağılımı Grafiği (Doughnut Chart)
    const ctxDevice = document.getElementById('deviceChart');
    if (ctxDevice) {
        new Chart(ctxDevice, {
            type: 'doughnut',
            data: {
                labels: ['Masaüstü', 'Mobil', 'Tablet', 'Bot / Diğer'],
                datasets: [{
                    data: [
                        <?php echo (int)$device_stats['desktop']; ?>,
                        <?php echo (int)$device_stats['mobile']; ?>,
                        <?php echo (int)$device_stats['tablet']; ?>,
                        <?php echo (int)$device_stats['bot']; ?>
                    ],
                    backgroundColor: ['#2563eb', '#06b6d4', '#f59e0b', '#64748b'],
                    borderWidth: 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                cutout: '65%'
            }
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
