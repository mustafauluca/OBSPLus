<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Genel Sistem ve Güvenlik Ayarları
 */

require_once __DIR__ . '/database.php';

// Güvenli Oturum Yapılandırması
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_samesite', 'Lax');
    
    // HTTPS aktifse secure cookie
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }
    
    session_start();
}

// Varsayılan Sabitler
define('SITE_NAME', 'E-LEARN – Öğrenci Eğitim, Sınav ve İstatistik Platformu');
define('SITE_URL', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10 MB

/**
 * Dinamik Site Ayarlarını Veritabanından Al
 * @param string $key Ayar anahtarı
 * @param string $default Varsayılan değer
 * @return string
 */
function get_setting($key, $default = '') {
    static $settings_cache = null;

    if ($settings_cache === null) {
        $settings_cache = [];
        $rows = db_fetch_all("SELECT setting_key, setting_value FROM site_settings");
        if ($rows) {
            foreach ($rows as $r) {
                $settings_cache[$r['setting_key']] = $r['setting_value'];
            }
        }
    }

    return $settings_cache[$key] ?? $default;
}

/**
 * İletişim Ayarlarını Al
 * @return array
 */
function get_contact_settings() {
    static $contact_cache = null;
    if ($contact_cache === null) {
        $row = db_fetch_one("SELECT * FROM contact_settings WHERE id = 1");
        $contact_cache = $row ?: [
            'phone' => '0 541 914 12 48',
            'email' => 'bilgi@diplomatr.com',
            'address' => 'Kavaklıdere Mah. Atatürk Bulvarı No: 142 Çankaya / Ankara',
            'whatsapp' => '905419141248',
            'instagram' => 'diplomatr_elearn',
            'facebook' => 'diplomatr_edu',
            'youtube' => 'diplomatr_akademi'
        ];
    }
    return $contact_cache;
}

/**
 * Ayar Güncelle
 */
function update_setting($key, $value) {
    return db_execute(
        "INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?",
        "sss",
        [$key, $value, $value]
    );
}
