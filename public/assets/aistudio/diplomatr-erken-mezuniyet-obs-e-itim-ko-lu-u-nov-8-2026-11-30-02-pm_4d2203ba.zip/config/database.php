<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Veritabanı Bağlantı ve Yönetim Modülü (MySQLi)
 * 
 * Sunucu yapılandırması:
 * DB_HOST: localhost
 * DB_NAME: u988165477_eventpi
 * DB_USER: u988165477_eventpi
 * DB_PASS: Ortam değişkeni veya sunucu yapılandırması
 */

// Türkiye Saat Dilimi
date_default_timezone_set('Europe/Istanbul');

// Hata raporlama: Üretimde hataları ekrana basma, logla
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../uploads/php_errors.log');

// Veritabanı Erişim Bilgileri (Çevre değişkenleri öncelikli)
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'u988165477_eventpi');
define('DB_USER', getenv('DB_USER') ?: 'u988165477_eventpi');
define('DB_PASS', getenv('DB_PASS') ?: 'EventPi_2026!Secure');
define('DB_PORT', (int)(getenv('DB_PORT') ?: 3306));
define('DB_CHARSET', 'utf8mb4');

// Global mysqli bağlantı referansı
$db = null;
$db_connected = false;
$db_error_message = '';

/**
 * MySQLi Veritabanı Bağlantısını Kur ve Döndür
 * @return mysqli|null
 */
function get_db_connection() {
    global $db, $db_connected, $db_error_message;

    if ($db instanceof mysqli && $db->ping()) {
        return $db;
    }

    // mysqli hata modunu ayarla
    mysqli_report(MYSQLI_REPORT_OFF);

    try {
        $connection = mysqli_init();
        if (!$connection) {
            $db_error_message = "MySQLi başlatılamadı.";
            return null;
        }

        $connection->options(MYSQLI_OPT_CONNECT_TIMEOUT, 3);

        $connected = @$connection->real_connect(
            DB_HOST,
            DB_USER,
            DB_PASS,
            DB_NAME,
            DB_PORT
        );

        if (!$connected) {
            $db_error_message = $connection->connect_error;
            error_log("[DB CONNECTION FAILED] " . date('Y-m-d H:i:s') . " - " . $db_error_message);
            $db = null;
            $db_connected = false;
            return null;
        }

        // utf8mb4 ve saat dilimi
        $connection->set_charset(DB_CHARSET);
        $connection->query("SET time_zone = '+03:00'");
        $connection->query("SET sql_mode = 'NO_ENGINE_SUBSTITUTION'");

        $db = $connection;
        $db_connected = true;
        $db_error_message = '';
        return $db;
    } catch (Throwable $e) {
        $db_error_message = $e->getMessage();
        error_log("[DB EXCEPTION] " . $e->getMessage());
        $db = null;
        $db_connected = false;
        return null;
    }
}

// Bağlantıyı ilk çağrıda oluştur
$db = get_db_connection();

/**
 * Güvenli Prepared Statement ile Parametreli Sorgu Çalıştırma
 * @param string $sql SQL sorgusu (? yer tutuculu)
 * @param string $types Parametre türleri (s=string, i=int, d=double, b=blob)
 * @param array $params Parametre değerleri dizisi
 * @return array|bool Sonuç dizisi veya etkilenen satır sayısı / true-false
 */
function db_query_params($sql, $types = "", $params = []) {
    $conn = get_db_connection();
    if (!$conn) {
        return false;
    }

    // Parametre ve tip sırası esnekliği (argüman takası ve otomatik algılama desteği)
    if (is_array($types)) {
        $actual_params = $types;
        $actual_types = is_string($params) ? $params : "";
    } elseif (is_array($params)) {
        $actual_params = $params;
        $actual_types = is_string($types) ? $types : "";
    } else {
        $actual_params = [];
        $actual_types = "";
    }

    // Eğer types belirtilmemişse parametre değerlerinden otomatik oluştur
    if (empty($actual_types) && !empty($actual_params)) {
        $actual_types = "";
        foreach ($actual_params as $val) {
            if (is_int($val)) {
                $actual_types .= "i";
            } elseif (is_float($val)) {
                $actual_types .= "d";
            } else {
                $actual_types .= "s";
            }
        }
    }

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("[SQL PREPARE ERROR] " . $conn->error . " | SQL: " . $sql);
        return false;
    }

    if (!empty($actual_types) && !empty($actual_params)) {
        $stmt->bind_param($actual_types, ...$actual_params);
    }

    $executed = $stmt->execute();
    if (!$executed) {
        error_log("[SQL EXECUTE ERROR] " . $stmt->error . " | SQL: " . $sql);
        $stmt->close();
        return false;
    }

    $result = $stmt->get_result();
    if ($result === false) {
        // INSERT, UPDATE, DELETE sorguları için etkilenen satır veya insert_id döndür
        $affected = $stmt->affected_rows;
        $insert_id = $stmt->insert_id;
        $stmt->close();
        return ($insert_id > 0) ? $insert_id : $affected;
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    $result->free();
    $stmt->close();
    return $data;
}

/**
 * Tekil Satır Döndüren Sorgu
 */
function db_fetch_one($sql, $types = "", $params = []) {
    $results = db_query_params($sql, $types, $params);
    if (is_array($results) && !empty($results)) {
        return $results[0];
    }
    return null;
}

/**
 * Tüm Satırları Döndüren Sorgu
 */
function db_fetch_all($sql, $types = "", $params = []) {
    $results = db_query_params($sql, $types, $params);
    return is_array($results) ? $results : [];
}

/**
 * Basit DML Çalıştırma (INSERT/UPDATE/DELETE)
 */
function db_execute($sql, $types = "", $params = []) {
    return db_query_params($sql, $types, $params);
}

/**
 * Güvenli Kaçış Fonksiyonu (Yalnızca dinamik identifier veya ek güvenlik için)
 */
function db_escape($string) {
    $conn = get_db_connection();
    if ($conn) {
        return $conn->real_escape_string($string);
    }
    return addslashes($string);
}
