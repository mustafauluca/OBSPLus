<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Genel HTML Üst Bilgi (Header)
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

$page_title_full = !empty($page_title) ? e($page_title) . ' - ' . e(get_setting('site_name', 'E-LEARN')) : e(get_setting('site_name', 'E-LEARN'));
$contact = get_contact_settings();
$current_student = get_current_student();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $page_title_full; ?></title>
  <meta name="description" content="<?php echo e(get_setting('site_description', 'E-LEARN')); ?>">

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Google Fonts: Inter & Outfit -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">

  <style>
    :root {
      --primary-navy: #0f172a;
      --secondary-navy: #1e293b;
      --accent-blue: #0284c7;
      --accent-cyan: #06b6d4;
      --light-bg: #f8fafc;
      --card-border: #e2e8f0;
    }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background-color: var(--light-bg);
      color: #1e293b;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    h1, h2, h3, h4, h5, h6, .brand-font {
      font-family: 'Outfit', sans-serif;
    }
    .bg-navy { background-color: var(--primary-navy) !important; }
    .bg-navy-light { background-color: var(--secondary-navy) !important; }
    .text-accent { color: var(--accent-cyan) !important; }
    .btn-accent {
      background: linear-gradient(135deg, var(--accent-blue), var(--accent-cyan));
      color: #fff;
      font-weight: 600;
      border: none;
      transition: all 0.2s ease;
    }
    .btn-accent:hover {
      opacity: 0.92;
      color: #fff;
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(6, 182, 212, 0.25);
    }
    .card-custom {
      background: #ffffff;
      border: 1px solid var(--card-border);
      border-radius: 1rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.03);
      transition: all 0.2s ease;
    }
    .card-custom:hover {
      box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08);
    }
    .navbar-brand-badge {
      width: 38px;
      height: 38px;
      border-radius: 10px;
      background: linear-gradient(135deg, #0284c7, #06b6d4);
      color: white;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 1.15rem;
    }
  </style>
</head>
<body>

  <!-- Top Announcement Bar -->
  <div class="bg-navy text-slate-300 py-1 px-3 border-bottom border-slate-800" style="font-size: 0.8rem;">
    <div class="container d-flex flex-wrap justify-content-between align-items-center">
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-info text-dark font-monospace fw-bold">E-LEARN</span>
        <span>Öğrenci Eğitim, Sınav ve İstatistik Platformu</span>
      </div>
      <div class="d-flex align-items-center gap-3">
        <a href="tel:<?php echo preg_replace('/\s+/', '', e($contact['phone'])); ?>" class="text-slate-300 text-decoration-none hover-white">
          <i class="bi bi-telephone-fill text-info me-1"></i><?php echo e($contact['phone']); ?>
        </a>
        <span class="text-secondary d-none d-sm-inline">|</span>
        <span class="d-none d-sm-inline text-slate-400">Türkiye Saat Dilimi (UTC+3)</span>
      </div>
    </div>
  </div>

  <!-- Main Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-navy sticky-top shadow-sm py-2">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center gap-2" href="/index.php">
        <div class="navbar-brand-badge">
          <i class="bi bi-mortarboard-fill"></i>
        </div>
        <div>
          <div class="fw-bold tracking-tight text-white mb-0" style="font-size: 1.25rem;">
            E-LEARN<span class="text-accent">.pro</span>
          </div>
          <div class="text-secondary" style="font-size: 0.68rem; margin-top: -3px;">
            Öğrenci Bilgi ve Sınav Portali
          </div>
        </div>
      </a>

      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarMain">
        <ul class="navbar-nav me-auto ms-lg-4 mb-2 mb-lg-0 fw-semibold text-uppercase" style="font-size: 0.85rem;">
          <li class="nav-item">
            <a class="nav-link text-white-50 hover-white px-2" href="/index.php">
              <i class="bi bi-house-door me-1"></i>Ana Sayfa
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white-50 hover-white px-2" href="/elearn/index.php">
              <i class="bi bi-book me-1"></i>E-Learn Dersler
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white-50 hover-white px-2" href="/index.php#skorboard">
              <i class="bi bi-trophy me-1 text-warning"></i>Skorboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white-50 hover-white px-2" href="/index.php#ekip">
              <i class="bi bi-people me-1"></i>Ekibimiz
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white-50 hover-white px-2" href="/index.php#iletisim">
              <i class="bi bi-envelope me-1"></i>İletişim
            </a>
          </li>
        </ul>

        <!-- Right Side Auth Buttons -->
        <div class="d-flex align-items-center gap-2">
          <?php if ($current_student): ?>
            <!-- Öğrenci Giriş Yapmış -->
            <div class="dropdown">
              <button class="btn btn-sm btn-outline-light dropdown-toggle d-flex align-items-center gap-2 py-1 px-3" type="button" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle text-info"></i>
                <span class="fw-semibold"><?php echo e($current_student['first_name'] . ' ' . mb_substr($current_student['last_name'], 0, 1) . '.'); ?></span>
                <span class="badge bg-secondary font-monospace"><?php echo e($current_student['student_number']); ?></span>
              </button>
              <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                <li><h6 class="dropdown-header">Öğrenci Menüsü</h6></li>
                <li><a class="dropdown-item" href="/elearn/profile.php"><i class="bi bi-person me-2"></i>Profilim & Notlarım</a></li>
                <li><a class="dropdown-item" href="/elearn/index.php"><i class="bi bi-journal-check me-2"></i>Kayıtlı Derslerim</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="/elearn/profile.php?action=logout"><i class="bi bi-box-arrow-right me-2"></i>Çıkış Yap</a></li>
              </ul>
            </div>
          <?php else: ?>
            <!-- Öğrenci Giriş / Kayıt Butonları -->
            <button type="button" class="btn btn-sm btn-outline-light fw-bold px-3" data-bs-toggle="modal" data-bs-target="#loginModal">
              <i class="bi bi-box-arrow-in-right me-1"></i>Öğrenci Girişi
            </button>
            <button type="button" class="btn btn-sm btn-accent px-3" data-bs-toggle="modal" data-bs-target="#registerModal">
              <i class="bi bi-person-plus-fill me-1"></i>Kayıt Ol
            </button>
          <?php endif; ?>

          <!-- Admin Giriş Linki -->
          <a href="/admin/index.php" class="btn btn-sm btn-dark text-secondary border-secondary px-2 ms-1" title="Yönetim Paneli Girişi">
            <i class="bi bi-shield-lock"></i>
          </a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Ana İçerik Başlangıcı -->
  <main class="flex-grow-1">
