<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Genel İş Mantığı, Skorboard, Sınav ve İstatistik Fonksiyonları
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/security.php';

/**
 * Öğrenci Soyadını Maskele: "Ahmet Y." (KVKK Uyumlu)
 * @param string $first_name
 * @param string $last_name
 * @return string
 */
function mask_student_name($first_name, $last_name) {
    $first = trim($first_name);
    $last = trim($last_name);
    $initial = mb_substr($last, 0, 1, 'UTF-8');
    return $first . ' ' . $initial . '.';
}

/**
 * Ana Sayfa Skorboard Verisi
 * Her ders için en başarılı 1. öğrenciyi döndürür (Yalnızca izin verenler)
 * @return array
 */
function get_scoreboard_data() {
    $sql = "SELECT 
                c.id AS course_id,
                c.title AS course_title,
                c.slug AS course_slug,
                s.id AS student_id,
                s.first_name,
                s.last_name,
                sc.total_score,
                sc.success_rate,
                sc.exam_count
            FROM courses c
            INNER JOIN (
                SELECT course_id, student_id, total_score, success_rate, exam_count,
                       ROW_NUMBER() OVER (PARTITION BY course_id ORDER BY total_score DESC, success_rate DESC, exam_count DESC) as rn
                FROM student_scores
            ) sc ON c.id = sc.course_id AND sc.rn = 1
            INNER JOIN students s ON sc.student_id = s.id AND s.show_on_scoreboard = 1 AND s.is_active = 1
            WHERE c.is_active = 1
            ORDER BY c.sort_order ASC, c.id ASC";

    $results = db_fetch_all($sql);
    
    // Eğer MySQL sürümü ROW_NUMBER() desteklemiyorsa veya sonuç boşsa fallback sorgusu
    if (empty($results)) {
        $courses = db_fetch_all("SELECT id, title, slug FROM courses WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 6");
        $results = [];
        foreach ($courses as $c) {
            $top = db_fetch_one(
                "SELECT s.first_name, s.last_name, sc.total_score, sc.success_rate, sc.exam_count
                 FROM student_scores sc
                 INNER JOIN students s ON sc.student_id = s.id AND s.show_on_scoreboard = 1 AND s.is_active = 1
                 WHERE sc.course_id = ?
                 ORDER BY sc.total_score DESC, sc.success_rate DESC
                 LIMIT 1",
                "i",
                [$c['id']]
            );
            if ($top) {
                $results[] = [
                    'course_id' => $c['id'],
                    'course_title' => $c['title'],
                    'course_slug' => $c['slug'],
                    'first_name' => $top['first_name'],
                    'last_name' => $top['last_name'],
                    'total_score' => $top['total_score'],
                    'success_rate' => $top['success_rate'],
                    'exam_count' => $top['exam_count']
                ];
            }
        }
    }

    return $results;
}

/**
 * Aktif Dersleri Listele
 */
function get_active_courses($limit = null) {
    $sql = "SELECT c.*, 
            (SELECT COUNT(*) FROM course_topics ct WHERE ct.course_id = c.id AND ct.is_active = 1) AS topic_count,
            (SELECT COUNT(*) FROM exams e WHERE e.course_id = c.id AND e.is_active = 1) AS exam_count
            FROM courses c
            WHERE c.is_active = 1 
            ORDER BY c.sort_order ASC, c.id ASC";
    if ($limit) {
        $sql .= " LIMIT " . (int)$limit;
    }
    return db_fetch_all($sql);
}

/**
 * Slug ile Ders Getir
 */
function get_course_by_slug($slug) {
    return db_fetch_one("SELECT * FROM courses WHERE slug = ? AND is_active = 1", "s", [$slug]);
}

/**
 * Derse Ait Konuları Getir
 */
function get_course_topics($course_id) {
    return db_fetch_all(
        "SELECT ct.*, 
         (SELECT COUNT(*) FROM questions q WHERE q.topic_id = ct.id AND q.is_active = 1) as question_count,
         (SELECT COUNT(*) FROM tests t WHERE t.topic_id = ct.id AND t.is_active = 1) as test_count
         FROM course_topics ct 
         WHERE ct.course_id = ? AND ct.is_active = 1 
         ORDER BY ct.sort_order ASC, ct.id ASC",
        "i",
        [$course_id]
    );
}

/**
 * Konu İçeriğini ve Materyallerini Getir
 */
function get_topic_with_content($topic_id) {
    $topic = db_fetch_one("SELECT * FROM course_topics WHERE id = ? AND is_active = 1", "i", [$topic_id]);
    if (!$topic) return null;

    $content = db_fetch_one("SELECT * FROM topic_contents WHERE topic_id = ?", "i", [$topic_id]);
    $materials = db_fetch_all("SELECT * FROM course_materials WHERE topic_id = ?", "i", [$topic_id]);

    $topic['content'] = $content;
    $topic['materials'] = $materials;
    return $topic;
}

/**
 * Öğrencinin Konuyu Tamamlama Durumu
 */
function is_topic_completed($student_id, $topic_id) {
    if (!$student_id) return false;
    $row = db_fetch_one("SELECT id FROM student_progress WHERE student_id = ? AND topic_id = ?", "ii", [$student_id, $topic_id]);
    return !empty($row);
}

/**
 * Konuyu Tamamlandı Olarak İşaretle
 */
function mark_topic_completed($student_id, $course_id, $topic_id) {
    return db_execute(
        "INSERT INTO student_progress (student_id, course_id, topic_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE is_completed = 1, completed_at = NOW()",
        "iii",
        [$student_id, $course_id, $topic_id]
    );
}

/**
 * Sınav Sorularını ve Seçeneklerini Getir
 */
function get_exam_questions_with_options($exam_id) {
    $questions = db_fetch_all(
        "SELECT q.* FROM questions q 
         INNER JOIN exam_questions eq ON q.id = eq.question_id 
         WHERE eq.exam_id = ? AND q.is_active = 1",
        "i",
        [$exam_id]
    );

    foreach ($questions as &$q) {
        $q['options'] = db_fetch_all(
            "SELECT id, option_letter, option_text FROM question_options WHERE question_id = ? ORDER BY option_letter ASC",
            "i",
            [$q['id']]
        );
    }
    return $questions;
}

/**
 * Test Sorularını ve Seçeneklerini Getir
 */
function get_test_questions_with_options($test_id) {
    $questions = db_fetch_all(
        "SELECT q.* FROM questions q 
         INNER JOIN test_questions tq ON q.id = tq.question_id 
         WHERE tq.test_id = ? AND q.is_active = 1 
         ORDER BY tq.sort_order ASC",
        "i",
        [$test_id]
    );

    foreach ($questions as &$q) {
        $q['options'] = db_fetch_all(
            "SELECT id, option_letter, option_text FROM question_options WHERE question_id = ? ORDER BY option_letter ASC",
            "i",
            [$q['id']]
        );
    }
    return $questions;
}

/**
 * Sınav veya Test Girişimi Başlat (Sayfa yenilense de sunucuda korunur)
 */
function start_exam_attempt($student_id, $item_id, $type = 'exam') {
    $ip = get_client_ip();

    // Devam eden açık girişim var mı?
    $field = ($type === 'exam') ? 'exam_id' : 'test_id';
    $existing = db_fetch_one(
        "SELECT * FROM exam_attempts WHERE student_id = ? AND {$field} = ? AND status = 'in_progress' ORDER BY id DESC LIMIT 1",
        "ii",
        [$student_id, $item_id]
    );

    if ($existing) {
        return $existing['id'];
    }

    $total_q = ($type === 'exam')
        ? db_fetch_one("SELECT COUNT(*) as c FROM exam_questions WHERE exam_id = ?", "i", [$item_id])['c']
        : db_fetch_one("SELECT COUNT(*) as c FROM test_questions WHERE test_id = ?", "i", [$item_id])['c'];

    $insert_sql = "INSERT INTO exam_attempts 
                   (student_id, {$field}, type, start_time, total_questions, status, attempt_ip) 
                   VALUES (?, ?, ?, NOW(), ?, 'in_progress', ?)";
    
    return db_execute($insert_sql, "iisis", [$student_id, $item_id, $type, $total_q, $ip]);
}

/**
 * Sınav Cevabını Kaydet (Tek tek veya toplu)
 */
function save_attempt_answer($attempt_id, $question_id, $selected_option_id) {
    // Doğru mu kontrol et
    $correct = db_fetch_one("SELECT is_correct FROM question_options WHERE id = ? AND question_id = ?", "ii", [$selected_option_id, $question_id]);
    $is_correct = ($correct && (int)$correct['is_correct'] === 1) ? 1 : 0;
    
    $points = db_fetch_one("SELECT points FROM questions WHERE id = ?", "i", [$question_id])['points'] ?? 10;
    $points_earned = $is_correct ? (int)$points : 0;

    return db_execute(
        "INSERT INTO exam_answers (attempt_id, question_id, selected_option_id, is_correct, points_earned)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE selected_option_id = ?, is_correct = ?, points_earned = ?",
        "iiiiiiii",
        [$attempt_id, $question_id, $selected_option_id, $is_correct, $points_earned, $selected_option_id, $is_correct, $points_earned]
    );
}

/**
 * Sınavı Tamamla ve Notlandır
 */
function finish_exam_attempt($attempt_id) {
    $attempt = db_fetch_one("SELECT * FROM exam_attempts WHERE id = ?", "i", [$attempt_id]);
    if (!$attempt || $attempt['status'] === 'completed') {
        return $attempt;
    }

    // Cevapları ve doğruları analiz et
    $stats = db_fetch_one(
        "SELECT 
            COUNT(CASE WHEN is_correct = 1 THEN 1 END) as correct_count,
            COUNT(CASE WHEN is_correct = 0 AND selected_option_id IS NOT NULL THEN 1 END) as wrong_count,
            SUM(points_earned) as total_earned
         FROM exam_answers WHERE attempt_id = ?",
        "i",
        [$attempt_id]
    );

    $correct_count = (int)($stats['correct_count'] ?? 0);
    $wrong_count = (int)($stats['wrong_count'] ?? 0);
    $total_q = (int)$attempt['total_questions'];
    $answered_q = $correct_count + $wrong_count;
    $empty_count = max(0, $total_q - $answered_q);

    // Başarı yüzdesi / Skor
    $score = ($total_q > 0) ? round(($correct_count / $total_q) * 100, 2) : 0;

    // Geçme barajı kontrolü
    $pass_score = 50;
    if ($attempt['type'] === 'exam' && $attempt['exam_id']) {
        $exam = db_fetch_one("SELECT pass_score, course_id FROM exams WHERE id = ?", "i", [$attempt['exam_id']]);
        $pass_score = $exam['pass_score'] ?? 50;
        $course_id = $exam['course_id'] ?? 1;
    } else {
        $test = db_fetch_one("SELECT pass_score, course_id FROM tests WHERE id = ?", "i", [$attempt['test_id']]);
        $pass_score = $test['pass_score'] ?? 60;
        $course_id = $test['course_id'] ?? 1;
    }

    $is_passed = ($score >= $pass_score) ? 1 : 0;

    // Sınav süresi hesabı
    $start = strtotime($attempt['start_time']);
    $time_spent = time() - $start;

    db_execute(
        "UPDATE exam_attempts SET 
            end_time = NOW(),
            time_spent_seconds = ?,
            correct_count = ?,
            wrong_count = ?,
            empty_count = ?,
            score = ?,
            is_passed = ?,
            status = 'completed'
         WHERE id = ?",
        "iiiiidi",
        [$time_spent, $correct_count, $wrong_count, $empty_count, $score, $is_passed, $attempt_id]
    );

    // Öğrencinin genel skorboard tablosunu güncelle
    if ($attempt['student_id'] && $course_id) {
        update_student_course_score($attempt['student_id'], $course_id);
    }

    return db_fetch_one("SELECT * FROM exam_attempts WHERE id = ?", "i", [$attempt_id]);
}

/**
 * Öğrencinin Bir Dersteki Toplam Puan ve Skorunu Güncelle
 */
function update_student_course_score($student_id, $course_id) {
    // Tüm tamamlanan sınav ve testlerin ortalaması ve toplamı
    $stats = db_fetch_one(
        "SELECT 
            SUM(score) as total_pts,
            AVG(score) as avg_score,
            COUNT(*) as attempt_count
         FROM exam_attempts ea
         LEFT JOIN exams e ON ea.exam_id = e.id
         LEFT JOIN tests t ON ea.test_id = t.id
         WHERE ea.student_id = ? 
           AND ea.status = 'completed'
           AND (e.course_id = ? OR t.course_id = ?)",
        "iii",
        [$student_id, $course_id, $course_id]
    );

    $total_score = (int)($stats['total_pts'] ?? 0);
    $avg = round((float)($stats['avg_score'] ?? 0), 2);
    $count = (int)($stats['attempt_count'] ?? 0);

    return db_execute(
        "INSERT INTO student_scores (student_id, course_id, total_score, exam_count, success_rate) 
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE total_score = ?, exam_count = ?, success_rate = ?",
        "iiiid iid",
        [$student_id, $course_id, $total_score, $count, $avg, $total_score, $count, $avg]
    );
}

/**
 * Ekip Üyelerini Getir
 */
function get_team_members() {
    return db_fetch_all("SELECT * FROM team_members WHERE is_active = 1 ORDER BY sort_order ASC, id ASC");
}

/**
 * Güvenli Dosya Yükleme (MIME, Boyut ve Uzantı Denetimli)
 */
function upload_file($file, $sub_dir = 'materials') {
    if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Dosya yüklenemedi veya seçilmedi.'];
    }

    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'message' => 'Dosya boyutu 10 MB sınırını aşıyor.'];
    }

    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'zip'];
    $allowed_mimes = [
        'image/jpeg', 'image/png', 'image/gif', 'application/pdf',
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/zip', 'application/x-zip-compressed'
    ];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_extensions)) {
        return ['success' => false, 'message' => 'İzin verilmeyen dosya uzantısı.'];
    }

    // MIME denetimi
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed_mimes)) {
        return ['success' => false, 'message' => 'Geçersiz dosya içeriği / MIME türü.'];
    }

    $target_dir = UPLOAD_DIR . trim($sub_dir, '/') . '/';
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $safe_name = bin2hex(random_bytes(16)) . '.' . $ext;
    $target_path = $target_dir . $safe_name;

    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return [
            'success' => true,
            'file_name' => $safe_name,
            'file_url' => '/uploads/' . trim($sub_dir, '/') . '/' . $safe_name,
            'file_size' => $file['size']
        ];
    }

    return ['success' => false, 'message' => 'Dosya hedefe taşınırken bir hata oluştu.'];
}

/**
 * İstatistik Fonksiyonları
 */
function get_today_visitors_count() {
    $row = db_fetch_one("SELECT COUNT(*) as c FROM visitor_logs WHERE DATE(created_at) = CURDATE() AND device_type != 'bot'");
    return (int)($row['c'] ?? 0);
}

function get_today_unique_visitors_count() {
    $row = db_fetch_one("SELECT COUNT(DISTINCT visitor_hash) as c FROM visitor_logs WHERE DATE(created_at) = CURDATE() AND device_type != 'bot'");
    return (int)($row['c'] ?? 0);
}

function get_total_visits_count() {
    $row = db_fetch_one("SELECT COUNT(*) as c FROM visitor_logs WHERE device_type != 'bot'");
    return (int)($row['c'] ?? 0);
}

function get_total_students_count() {
    $row = db_fetch_one("SELECT COUNT(*) as c FROM students WHERE is_active = 1");
    return (int)($row['c'] ?? 0);
}

function get_total_exams_completed_count() {
    $row = db_fetch_one("SELECT COUNT(*) as c FROM exam_attempts WHERE status = 'completed'");
    return (int)($row['c'] ?? 0);
}
