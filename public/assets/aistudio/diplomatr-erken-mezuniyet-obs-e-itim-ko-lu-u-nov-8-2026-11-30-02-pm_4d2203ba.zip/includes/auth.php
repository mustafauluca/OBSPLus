<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Kimlik Doğrulama, Oturum Yönetimi ve Giriş/Kayıt Loglama Modülü
 */

require_once __DIR__ . '/security.php';
require_once __DIR__ . '/../config/settings.php';

/**
 * Giriş Yapmış Aktif Öğrenciyi Döndür
 * @return array|null
 */
function get_current_student() {
    if (!empty($_SESSION['student_id'])) {
        $student = db_fetch_one("SELECT * FROM students WHERE id = ? AND is_active = 1", "i", [$_SESSION['student_id']]);
        return $student;
    }

    // Beni hatırla çerezi kontrolü
    if (!empty($_COOKIE['remember_student'])) {
        $token = $_COOKIE['remember_student'];
        $student = db_fetch_one("SELECT * FROM students WHERE remember_token = ? AND is_active = 1", "s", [$token]);
        if ($student) {
            $_SESSION['student_id'] = $student['id'];
            $_SESSION['student_number'] = $student['student_number'];
            $_SESSION['student_name'] = $student['first_name'] . ' ' . $student['last_name'];
            session_regenerate_id(true);
            return $student;
        }
    }

    return null;
}

/**
 * Öğrenci Giriş Durumu Kontrolü
 * @return bool
 */
function is_student_logged_in() {
    return get_current_student() !== null;
}

/**
 * Öğrenci Giriş İşlemi
 * @param string $student_number
 * @param string $password
 * @param bool $remember
 * @return array ['success' => bool, 'message' => string]
 */
function student_login($student_number, $password, $remember = false) {
    $ip = get_client_ip();
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $browser = detect_browser($ua);
    $device = detect_device_type($ua);

    // IP Engellenmiş mi kontrol et
    if (is_ip_blocked($ip)) {
        return [
            'success' => false,
            'message' => 'Çok sayıda başarısız giriş nedeniyle IP adresiniz geçici olarak engellenmiştir. Lütfen daha sonra tekrar deneyiniz.'
        ];
    }

    $clean_number = clean_input($student_number);
    if (empty($clean_number) || empty($password)) {
        return ['success' => false, 'message' => 'Öğrenci numarası ve şifre gereklidir.'];
    }

    // Öğrenciyi sorgula
    $student = db_fetch_one("SELECT * FROM students WHERE student_number = ?", "s", [$clean_number]);

    if (!$student) {
        // Logla
        db_execute(
            "INSERT INTO student_login_logs (ip_address, student_number, entered_name, is_success, failure_reason, user_agent, browser, device_type) VALUES (?, ?, ?, 0, ?, ?, ?, ?)",
            "sssssss",
            [$ip, $clean_number, 'Bilinmiyor', 'Öğrenci numarası bulunamadı', $ua, $browser, $device]
        );
        record_failed_login_attempt($ip);
        return ['success' => false, 'message' => 'Girdiğiniz öğrenci numarası sistemde kayıtlı değildir.'];
    }

    $full_name = $student['first_name'] . ' ' . $student['last_name'];

    // Hesap aktif mi?
    if ((int)$student['is_active'] !== 1) {
        db_execute(
            "INSERT INTO student_login_logs (ip_address, student_number, entered_name, is_success, failure_reason, user_agent, browser, device_type) VALUES (?, ?, ?, 0, ?, ?, ?, ?)",
            "sssssss",
            [$ip, $clean_number, $full_name, 'Hesap pasife alınmış', $ua, $browser, $device]
        );
        return ['success' => false, 'message' => 'Öğrenci hesabınız dondurulmuş veya pasif durumdadır. Öğrenci işleri ile iletişime geçiniz.'];
    }

    // Parola doğrulama
    if (!password_verify($password, $student['password_hash'])) {
        db_execute(
            "INSERT INTO student_login_logs (ip_address, student_number, entered_name, is_success, failure_reason, user_agent, browser, device_type) VALUES (?, ?, ?, 0, ?, ?, ?, ?)",
            "sssssss",
            [$ip, $clean_number, $full_name, 'Hatalı parola', $ua, $browser, $device]
        );
        record_failed_login_attempt($ip);
        return ['success' => false, 'message' => 'Girdiğiniz şifre hatalıdır. Lütfen kontrol ediniz.'];
    }

    // Başarılı Giriş: Session Fixation önleme
    session_regenerate_id(true);
    $_SESSION['student_id'] = $student['id'];
    $_SESSION['student_number'] = $student['student_number'];
    $_SESSION['student_name'] = $full_name;
    $_SESSION['student_email'] = $student['email'];

    // Son giriş bilgisi güncelle
    db_execute("UPDATE students SET last_login = NOW(), last_login_ip = ? WHERE id = ?", "si", [$ip, $student['id']]);

    // Beni hatırla token'ı
    if ($remember) {
        $token = bin2hex(random_bytes(32));
        db_execute("UPDATE students SET remember_token = ? WHERE id = ?", "si", [$token, $student['id']]);
        setcookie('remember_student', $token, time() + (86400 * 30), '/', '', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), true);
    }

    // Başarılı giriş logu
    db_execute(
        "INSERT INTO student_login_logs (ip_address, student_number, entered_name, is_success, failure_reason, user_agent, browser, device_type) VALUES (?, ?, ?, 1, NULL, ?, ?, ?)",
        "ssssss",
        [$ip, $clean_number, $full_name, $ua, $browser, $device]
    );

    // Başarısız giriş sayaçlarını sıfırla
    reset_failed_login_attempts($ip);

    return ['success' => true, 'message' => 'Giriş başarılı.', 'student' => $student];
}

/**
 * Öğrenci Kayıt İşlemi
 * @param array $data
 * @return array
 */
function student_register($data) {
    $ip = get_client_ip();

    $student_number = clean_input($data['student_number'] ?? '');
    $first_name = clean_input($data['first_name'] ?? '');
    $last_name = clean_input($data['last_name'] ?? '');
    $email = clean_input($data['email'] ?? '');
    $phone = clean_input($data['phone'] ?? '');
    $password = $data['password'] ?? '';
    $password_confirm = $data['password_confirm'] ?? '';
    $kvkk_accepted = !empty($data['kvkk_accepted']) ? 1 : 0;

    $full_name = trim($first_name . ' ' . $last_name);

    // Doğrulamalar
    if (empty($student_number) || empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
        $msg = 'Lütfen tüm zorunlu alanları doldurunuz.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    if (!$kvkk_accepted) {
        $msg = 'KVKK aydınlatma metnini onaylamanız gerekmektedir.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = 'Geçerli bir e-posta adresi giriniz.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    if (strlen($password) < 6) {
        $msg = 'Şifreniz en az 6 karakterden oluşmalıdır.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    if ($password !== $password_confirm) {
        $msg = 'Girdiğiniz şifreler birbiriyle eşleşmemektedir.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    // Benzersizlik kontrolleri
    $exists = db_fetch_one("SELECT id FROM students WHERE student_number = ?", "s", [$student_number]);
    if ($exists) {
        $msg = 'Bu öğrenci numarası zaten sisteme kayıtlıdır.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    $email_exists = db_fetch_one("SELECT id FROM students WHERE email = ?", "s", [$email]);
    if ($email_exists) {
        $msg = 'Bu e-posta adresi ile daha önce kayıt oluşturulmuştur.';
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, failure_reason) VALUES (?, ?, ?, ?, 0, ?)", "sssss", [$ip, $student_number, $full_name, $email, $msg]);
        return ['success' => false, 'message' => $msg];
    }

    // Parolayı hashle
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Kaydı oluştur
    $insert_sql = "INSERT INTO students 
                   (student_number, first_name, last_name, email, phone, password_hash, kvkk_accepted, register_ip, is_active) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)";
    $new_id = db_execute(
        $insert_sql,
        "ssssssis",
        [$student_number, $first_name, $last_name, $email, $phone, $password_hash, $kvkk_accepted, $ip]
    );

    if ($new_id) {
        // Kayıt logu
        db_execute("INSERT INTO student_register_logs (ip_address, student_number, full_name, email, is_success, verification_status) VALUES (?, ?, ?, ?, 1, 'verified')", "ssss", [$ip, $student_number, $full_name, $email]);

        // Otomatik oturum aç
        session_regenerate_id(true);
        $_SESSION['student_id'] = $new_id;
        $_SESSION['student_number'] = $student_number;
        $_SESSION['student_name'] = $full_name;
        $_SESSION['student_email'] = $email;

        return ['success' => true, 'message' => 'Kaydınız başarıyla oluşturuldu.', 'student_id' => $new_id];
    }

    return ['success' => false, 'message' => 'Kayıt sırasında sistemsel bir hata oluştu. Lütfen tekrar deneyiniz.'];
}

/**
 * Öğrenci Çıkış İşlemi
 */
function student_logout() {
    if (!empty($_SESSION['student_id'])) {
        db_execute("UPDATE students SET remember_token = NULL WHERE id = ?", "i", [$_SESSION['student_id']]);
    }
    unset($_SESSION['student_id'], $_SESSION['student_number'], $_SESSION['student_name'], $_SESSION['student_email']);
    setcookie('remember_student', '', time() - 3600, '/');
    session_regenerate_id(true);
}

/**
 * Admin Giriş Durumu
 */
function is_admin_logged_in() {
    return !empty($_SESSION['admin_id']);
}

/**
 * Aktif Admin Kullanıcı Bilgisi
 */
function get_current_admin() {
    if (is_admin_logged_in()) {
        return db_fetch_one("SELECT * FROM admins WHERE id = ? AND is_active = 1", "i", [$_SESSION['admin_id']]);
    }
    return null;
}

/**
 * Admin Giriş İşlemi
 */
function admin_login($username, $password) {
    $ip = get_client_ip();
    $clean_user = clean_input($username);

    $admin = db_fetch_one("SELECT * FROM admins WHERE username = ? OR email = ?", "ss", [$clean_user, $clean_user]);
    if (!$admin) {
        return ['success' => false, 'message' => 'Yönetici hesabı bulunamadı.'];
    }

    if ((int)$admin['is_active'] !== 1) {
        return ['success' => false, 'message' => 'Yönetici hesabı pasif duruma alınmıştır.'];
    }

    if (!password_verify($password, $admin['password_hash'])) {
        return ['success' => false, 'message' => 'Hatalı yönetici şifresi.'];
    }

    session_regenerate_id(true);
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_name'] = $admin['full_name'];
    $_SESSION['admin_role'] = $admin['role'];

    db_execute("UPDATE admins SET last_login = NOW(), last_login_ip = ? WHERE id = ?", "si", [$ip, $admin['id']]);
    log_audit($admin['id'], 'admin_login', 'admins', $admin['id'], "Yönetici girişi yapıldı.");

    return ['success' => true, 'message' => 'Yönetici girişi başarılı.'];
}

/**
 * Admin Çıkış İşlemi
 */
function admin_logout() {
    if (!empty($_SESSION['admin_id'])) {
        log_audit($_SESSION['admin_id'], 'admin_logout', 'admins', $_SESSION['admin_id'], "Yönetici çıkışı yapıldı.");
    }
    unset($_SESSION['admin_id'], $_SESSION['admin_username'], $_SESSION['admin_name'], $_SESSION['admin_role']);
    session_regenerate_id(true);
}
