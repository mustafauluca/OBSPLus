<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Güvenlik, CSRF, Rate Limiting ve IP Doğrulama Modülü
 */

require_once __DIR__ . '/../config/database.php';

/**
 * İstemci IP Adresini Güvenli Şekilde Al
 * Proxy başlıkları yalnızca güvenilir ve geçerli formatta ise dikkate alınır.
 * @return string
 */
function get_client_ip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

    // Cloudflare veya Nginx Reverse Proxy kontrolü
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $candidate = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
        if (filter_var($candidate, FILTER_VALIDATE_IP)) {
            return $candidate;
        }
    }

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $first_ip = trim($ips[0]);
        if (filter_var($first_ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return $first_ip;
        }
    }

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $candidate = trim($_SERVER['HTTP_CLIENT_IP']);
        if (filter_var($candidate, FILTER_VALIDATE_IP)) {
            return $candidate;
        }
    }

    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '127.0.0.1';
}

/**
 * XSS Korumalı Çıktı Üretimi
 * @param string|null $data
 * @return string
 */
function e($data) {
    if ($data === null) return '';
    return htmlspecialchars((string)$data, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Girdi Temizleme (Sanitization)
 * @param mixed $data
 * @return mixed
 */
function clean_input($data) {
    if (is_array($data)) {
        return array_map('clean_input', $data);
    }
    return trim(strip_tags((string)$data));
}

/**
 * CSRF Token Üret ve Oturuma Kaydet
 * @return string
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token']) || empty($_SESSION['csrf_token_time']) || (time() - $_SESSION['csrf_token_time'] > 7200)) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token Doğrula
 * @param string|null $token
 * @return bool
 */
function verify_csrf_token($token) {
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Formlar için Gizli CSRF Input HTML'i
 * @return string
 */
function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . e(generate_csrf_token()) . '">';
}

/**
 * Bot ve Crawler Trafiğini Tespit Et
 * @param string $user_agent
 * @return bool
 */
function is_bot($user_agent = null) {
    $ua = $user_agent ?: ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (empty($ua)) return true;

    $bot_patterns = [
        'bot', 'crawl', 'spider', 'slurp', 'mediapartners', 'googlebot',
        'bingbot', 'yandex', 'duckduckbot', 'baiduspider', 'curl', 'wget',
        'python', 'facebookexternalhit', 'ahrefs', 'semrush'
    ];

    $ua_lower = strtolower($ua);
    foreach ($bot_patterns as $pattern) {
        if (strpos($ua_lower, $pattern) !== false) {
            return true;
        }
    }
    return false;
}

/**
 * Cihaz Türünü Belirle (Mobile, Tablet, Desktop)
 * @param string $user_agent
 * @return string
 */
function detect_device_type($user_agent = null) {
    $ua = strtolower($user_agent ?: ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (is_bot($ua)) return 'bot';
    if (preg_match('/(tablet|ipad|playbook|silk)|(android(?!.*mobile))/i', $ua)) return 'tablet';
    if (preg_match('/(mobile|iphone|ipod|blackberry|opera mini|iemobile|windows phone)/i', $ua)) return 'mobile';
    return 'desktop';
}

/**
 * Tarayıcı Adını Tespit Et
 */
function detect_browser($user_agent = null) {
    $ua = strtolower($user_agent ?: ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (strpos($ua, 'edg') !== false) return 'Edge';
    if (strpos($ua, 'chrome') !== false) return 'Chrome';
    if (strpos($ua, 'firefox') !== false) return 'Firefox';
    if (strpos($ua, 'safari') !== false) return 'Safari';
    if (strpos($ua, 'opera') !== false || strpos($ua, 'opr') !== false) return 'Opera';
    if (strpos($ua, 'msie') !== false || strpos($ua, 'trident') !== false) return 'IE';
    return 'Diğer';
}

/**
 * İşletim Sistemini Tespit Et
 */
function detect_os($user_agent = null) {
    $ua = strtolower($user_agent ?: ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    if (strpos($ua, 'windows nt 10') !== false) return 'Windows 10/11';
    if (strpos($ua, 'windows') !== false) return 'Windows';
    if (strpos($ua, 'macintosh') !== false || strpos($ua, 'mac os x') !== false) return 'macOS';
    if (strpos($ua, 'android') !== false) return 'Android';
    if (strpos($ua, 'iphone') !== false || strpos($ua, 'ipad') !== false) return 'iOS';
    if (strpos($ua, 'linux') !== false) return 'Linux';
    return 'Diğer';
}

/**
 * IP Engelleme Kontrolü
 * @param string|null $ip
 * @return bool
 */
function is_ip_blocked($ip = null) {
    $client_ip = $ip ?: get_client_ip();
    $row = db_fetch_one(
        "SELECT id, blocked_until FROM blocked_ips WHERE ip_address = ? AND (blocked_until IS NULL OR blocked_until > NOW())",
        "s",
        [$client_ip]
    );
    return !empty($row);
}

/**
 * Başarısız Giriş Denemesini Kaydet ve Gerekirse IP'yi Engelle
 * @param string $ip
 * @param int $max_attempts
 * @param int $lockout_minutes
 */
function record_failed_login_attempt($ip, $max_attempts = 5, $lockout_minutes = 15) {
    $client_ip = $ip ?: get_client_ip();
    
    // blocked_ips tablosunda mevcut mu kontrol et
    $existing = db_fetch_one("SELECT * FROM blocked_ips WHERE ip_address = ?", "s", [$client_ip]);

    if ($existing) {
        $attempts = $existing['failed_attempts'] + 1;
        $blocked_until = ($attempts >= $max_attempts) ? date('Y-m-d H:i:s', strtotime("+{$lockout_minutes} minutes")) : null;

        db_execute(
            "UPDATE blocked_ips SET failed_attempts = ?, blocked_until = ? WHERE ip_address = ?",
            "iss",
            [$attempts, $blocked_until, $client_ip]
        );
    } else {
        db_execute(
            "INSERT INTO blocked_ips (ip_address, failed_attempts, reason) VALUES (?, 1, 'Başarısız giriş denemesi')",
            "s",
            [$client_ip]
        );
    }
}

/**
 * Başarılı Giriş Sonrası Başarısız Denemeleri Temizle
 */
function reset_failed_login_attempts($ip) {
    $client_ip = $ip ?: get_client_ip();
    db_execute("DELETE FROM blocked_ips WHERE ip_address = ? AND blocked_until IS NULL", "s", [$client_ip]);
}

/**
 * Yönetici İşlem Denetim Logu (Audit Log)
 */
function log_audit($admin_id, $action, $target_entity = null, $target_id = null, $details = '') {
    $ip = get_client_ip();
    return db_execute(
        "INSERT INTO audit_logs (admin_id, action, target_entity, target_id, ip_address, details) VALUES (?, ?, ?, ?, ?, ?)",
        "ississ",
        [$admin_id, $action, $target_entity, $target_id, $ip, $details]
    );
}
