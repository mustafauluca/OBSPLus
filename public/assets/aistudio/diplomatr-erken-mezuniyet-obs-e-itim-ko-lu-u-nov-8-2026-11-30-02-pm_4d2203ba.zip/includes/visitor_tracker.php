<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Otomatik Ziyaretçi ve Trafik Takip Sistemi
 */

require_once __DIR__ . '/security.php';

/**
 * Sayfayı Ziyaret Eden Kullanıcıyı Otomatik Olarak Kaydet
 * @param string $page_title Açılan sayfa başlığı
 * @return int|bool Kayıt ID'si
 */
function track_visitor($page_title = '') {
    // Statik dosya veya AJAX polling ise kaydetme
    $url = $_SERVER['REQUEST_URI'] ?? '/';
    if (preg_match('/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|map)$/i', $url)) {
        return false;
    }

    $ip = get_client_ip();
    $session_id = session_id() ?: 'anon_' . substr(md5($ip . ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 16);
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Ziyaretçi parmak izi (Tekil ziyaretçi hesabı için)
    $visitor_hash = hash('sha256', $ip . '|' . $user_agent);

    // Giriş yapmış öğrenci var mı?
    $student_id = $_SESSION['student_id'] ?? null;

    $referrer = $_SERVER['HTTP_REFERER'] ?? '';
    $device_type = detect_device_type($user_agent);
    $browser = detect_browser($user_agent);
    $os = detect_os($user_agent);

    // Ziyaret Kaynağı Belirleme
    $visit_source = 'direct';
    if (!empty($referrer)) {
        $ref_host = parse_url($referrer, PHP_URL_HOST);
        $curr_host = $_SERVER['HTTP_HOST'] ?? '';
        if ($ref_host && strpos($ref_host, $curr_host) === false) {
            if (preg_match('/(google|yandex|bing|yahoo|duckduckgo)/i', $ref_host)) {
                $visit_source = 'search_engine';
            } elseif (preg_match('/(instagram|facebook|twitter|t\.co|linkedin|youtube|tiktok)/i', $ref_host)) {
                $visit_source = 'social_media';
            } else {
                $visit_source = 'referral';
            }
        } else {
            $visit_source = 'internal';
        }
    }

    // Başlık belirtilmemişse URL'den türet
    if (empty($page_title)) {
        $page_title = basename(parse_url($url, PHP_URL_PATH)) ?: 'Ana Sayfa';
    }

    // Veritabanına kaydet
    $sql = "INSERT INTO visitor_logs 
            (session_id, visitor_hash, ip_address, student_id, page_title, page_url, referrer, user_agent, browser, os, device_type, visit_source) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    return db_execute(
        $sql,
        "sssissssssss",
        [
            $session_id,
            $visitor_hash,
            $ip,
            $student_id,
            mb_substr($page_title, 0, 150),
            $url,
            $referrer,
            $user_agent,
            $browser,
            $os,
            $device_type,
            $visit_source
        ]
    );
}

// Otomatik izleme (Doğrudan include edildiğinde çalışır)
if (!defined('DISABLE_AUTO_TRACK')) {
    track_visitor();
}
