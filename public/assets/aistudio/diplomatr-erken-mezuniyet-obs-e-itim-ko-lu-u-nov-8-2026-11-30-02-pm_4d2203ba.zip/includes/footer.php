<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Genel HTML Alt Bilgi (Footer) ve Oturum Modalları
 */

$contact = get_contact_settings();
$footer_text = get_setting('footer_text', '© 2026 E-LEARN. Tüm hakları saklıdır.');
?>
  </main>
  <!-- Ana İçerik Sonu -->

  <!-- Genel Footer -->
  <footer class="bg-navy text-white pt-5 pb-4 mt-5 border-top border-slate-800">
    <div class="container">
      <div class="row g-4 mb-4">
        <!-- Kolon 1: Logo ve Hakkında -->
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <div class="navbar-brand-badge" style="width: 32px; height: 32px; font-size: 1rem;">
              <i class="bi bi-mortarboard-fill"></i>
            </div>
            <h5 class="fw-bold mb-0 text-white">E-LEARN<span class="text-accent">.pro</span></h5>
          </div>
          <p class="text-secondary small leading-relaxed pe-lg-3">
            <?php echo e(get_setting('about_content', 'E-LEARN, öğrencilerin eksik kaldıkları akademik konuları hızla tespit eden, özel çalışma planı ve vize hazırlık sınavları sunan yeni nesil dijital öğrenme merkezidir.')); ?>
          </p>
          <div class="d-flex align-items-center gap-2 mt-3">
            <?php if (!empty($contact['whatsapp'])): ?>
              <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $contact['whatsapp']); ?>" target="_blank" class="btn btn-sm btn-outline-light rounded-circle" style="width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center;">
                <i class="bi bi-whatsapp"></i>
              </a>
            <?php endif; ?>
            <?php if (!empty($contact['instagram'])): ?>
              <a href="https://instagram.com/<?php echo e($contact['instagram']); ?>" target="_blank" class="btn btn-sm btn-outline-light rounded-circle" style="width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center;">
                <i class="bi bi-instagram"></i>
              </a>
            <?php endif; ?>
            <?php if (!empty($contact['facebook'])): ?>
              <a href="https://facebook.com/<?php echo e($contact['facebook']); ?>" target="_blank" class="btn btn-sm btn-outline-light rounded-circle" style="width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center;">
                <i class="bi bi-facebook"></i>
              </a>
            <?php endif; ?>
            <?php if (!empty($contact['youtube'])): ?>
              <a href="https://youtube.com/@<?php echo e($contact['youtube']); ?>" target="_blank" class="btn btn-sm btn-outline-light rounded-circle" style="width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center;">
                <i class="bi bi-youtube"></i>
              </a>
            <?php endif; ?>
          </div>
        </div>

        <!-- Kolon 2: Hızlı Menü -->
        <div class="col-lg-2 col-md-6 col-6">
          <h6 class="text-uppercase text-white fw-bold mb-3 small tracking-wider">Hızlı Erişim</h6>
          <ul class="list-unstyled text-secondary small space-y-2 mb-0">
            <li class="mb-2"><a href="/index.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-info"></i>Ana Sayfa</a></li>
            <li class="mb-2"><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-info"></i>Tüm Dersler</a></li>
            <li class="mb-2"><a href="/index.php#skorboard" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-info"></i>Skorboard</a></li>
            <li class="mb-2"><a href="/index.php#ekip" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-info"></i>Akademik Ekip</a></li>
            <li><a href="/admin/index.php" class="text-secondary text-decoration-none hover-white"><i class="bi bi-shield-lock me-1 text-info"></i>Admin Paneli</a></li>
          </ul>
        </div>

        <!-- Kolon 3: Ders Kategorileri -->
        <div class="col-lg-3 col-md-6 col-6">
          <h6 class="text-uppercase text-white fw-bold mb-3 small tracking-wider">Popüler Dersler</h6>
          <ul class="list-unstyled text-secondary small mb-0">
            <li class="mb-2"><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white">Bilgisayar Teknolojileri</a></li>
            <li class="mb-2"><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white">İşletme Yönetimi</a></li>
            <li class="mb-2"><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white">Grafik Tasarım</a></li>
            <li class="mb-2"><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white">Web Geliştirme</a></li>
            <li><a href="/elearn/index.php" class="text-secondary text-decoration-none hover-white">Veri Analizi ve İstatistik</a></li>
          </ul>
        </div>

        <!-- Kolon 4: İletişim Bilgileri -->
        <div class="col-lg-3 col-md-6" id="iletisim">
          <h6 class="text-uppercase text-white fw-bold mb-3 small tracking-wider">İletişim & Danışma</h6>
          <ul class="list-unstyled text-secondary small mb-0">
            <li class="d-flex align-items-start gap-2 mb-2">
              <i class="bi bi-geo-alt text-info mt-1"></i>
              <span><?php echo e($contact['address']); ?></span>
            </li>
            <li class="d-flex align-items-center gap-2 mb-2">
              <i class="bi bi-telephone text-info"></i>
              <a href="tel:<?php echo preg_replace('/\s+/', '', e($contact['phone'])); ?>" class="text-white text-decoration-none fw-bold"><?php echo e($contact['phone']); ?></a>
            </li>
            <li class="d-flex align-items-center gap-2 mb-3">
              <i class="bi bi-envelope text-info"></i>
              <a href="mailto:<?php echo e($contact['email']); ?>" class="text-secondary text-decoration-none"><?php echo e($contact['email']); ?></a>
            </li>
            <li>
              <div class="p-2 rounded bg-slate-900 border border-slate-800 text-slate-400 small">
                <i class="bi bi-shield-check text-success me-1"></i>KVKK & Veri Güvenliği Standartları
              </div>
            </li>
          </ul>
        </div>
      </div>

      <hr class="border-slate-800 my-4">

      <div class="row align-items-center small text-secondary">
        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
          <?php echo e($footer_text); ?>
        </div>
        <div class="col-md-6 text-center text-md-end">
          <button type="button" class="btn btn-link text-secondary p-0 text-decoration-none small me-3" data-bs-toggle="modal" data-bs-target="#kvkkModal">
            KVKK Aydınlatma Metni
          </button>
          <span>Türkiye Saat Dilimi: <strong>Europe/Istanbul</strong></span>
        </div>
      </div>
    </div>
  </footer>

  <!-- 1. ÖĞRENCİ GİRİŞ MODALI -->
  <div class="modal fade" id="loginModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="modal-header bg-navy text-white py-3 px-4">
          <div class="d-flex align-items-center gap-2">
            <i class="bi bi-box-arrow-in-right text-info fs-5"></i>
            <h5 class="modal-title fw-bold mb-0">Öğrenci Giriş Portali</h5>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div id="loginAlert" class="alert d-none small mb-3"></div>

          <form id="studentLoginForm" method="POST" action="/elearn/index.php">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="student_login">

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">Öğrenci Numarası</label>
              <div class="input-group">
                <span class="input-group-text bg-light border-end-0 text-secondary"><i class="bi bi-person-badge"></i></span>
                <input type="text" name="student_number" class="form-control border-start-0" placeholder="Örn: 202610101" required>
              </div>
            </div>

            <div class="mb-3">
              <div class="d-flex justify-content-between">
                <label class="form-label small fw-semibold text-secondary">Şifre</label>
                <a href="javascript:void(0)" onclick="alert('Lütfen şifre sıfırlama için öğrenci işleri ile iletişime geçiniz: <?php echo e($contact['phone']); ?>')" class="text-decoration-none small text-info">Şifremi Unuttum?</a>
              </div>
              <div class="input-group">
                <span class="input-group-text bg-light border-end-0 text-secondary"><i class="bi bi-lock"></i></span>
                <input type="password" name="password" class="form-control border-start-0" placeholder="••••••••" required>
              </div>
            </div>

            <div class="form-check mb-4">
              <input class="form-check-input" type="checkbox" name="remember" id="rememberMe">
              <label class="form-check-label small text-secondary" for="rememberMe">
                Beni Hatırla (Güvenli Çerez ile 30 Gün)
              </label>
            </div>

            <button type="submit" class="btn btn-accent w-full w-100 py-2.5 fw-bold">
              <i class="bi bi-box-arrow-in-right me-1"></i>Giriş Yap
            </button>
          </form>
        </div>
        <div class="modal-footer bg-light border-top-0 py-3 text-center justify-content-center">
          <span class="small text-secondary">Henüz bir hesabınız yok mu?</span>
          <button type="button" class="btn btn-sm btn-link text-info fw-bold p-0 text-decoration-none" data-bs-toggle="modal" data-bs-target="#registerModal">
            Hemen Kayıt Ol
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- 2. ÖĞRENCİ KAYIT MODALI -->
  <div class="modal fade" id="registerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="modal-header bg-navy text-white py-3 px-4">
          <div class="d-flex align-items-center gap-2">
            <i class="bi bi-person-plus-fill text-info fs-5"></i>
            <h5 class="modal-title fw-bold mb-0">Öğrenci Kayıt Formu</h5>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body p-4">
          <div id="registerAlert" class="alert d-none small mb-3"></div>

          <form id="studentRegisterForm" method="POST" action="/elearn/index.php">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="student_register">

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">Öğrenci Numarası <span class="text-danger">*</span></label>
              <input type="text" name="student_number" class="form-control" placeholder="Örn: 202610555" required>
            </div>

            <div class="row g-2 mb-3">
              <div class="col-6">
                <label class="form-label small fw-semibold text-secondary">Adınız <span class="text-danger">*</span></label>
                <input type="text" name="first_name" class="form-control" placeholder="Ad" required>
              </div>
              <div class="col-6">
                <label class="form-label small fw-semibold text-secondary">Soyadınız <span class="text-danger">*</span></label>
                <input type="text" name="last_name" class="form-control" placeholder="Soyad" required>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">E-Posta Adresi <span class="text-danger">*</span></label>
              <input type="email" name="email" class="form-control" placeholder="ornek@ogrenci.com" required>
            </div>

            <div class="mb-3">
              <label class="form-label small fw-semibold text-secondary">Telefon Numarası (İsteğe Bağlı)</label>
              <input type="tel" name="phone" class="form-control" placeholder="0 5xx xxx xx xx">
            </div>

            <div class="row g-2 mb-3">
              <div class="col-6">
                <label class="form-label small fw-semibold text-secondary">Şifre <span class="text-danger">*</span></label>
                <input type="password" name="password" class="form-control" placeholder="En az 6 karakter" required>
              </div>
              <div class="col-6">
                <label class="form-label small fw-semibold text-secondary">Şifre Tekrar <span class="text-danger">*</span></label>
                <input type="password" name="password_confirm" class="form-control" placeholder="Şifre doğrulama" required>
              </div>
            </div>

            <div class="form-check mb-4">
              <input class="form-check-input" type="checkbox" name="kvkk_accepted" id="kvkkCheck" required checked>
              <label class="form-check-label small text-secondary" for="kvkkCheck">
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#kvkkModal" class="text-info text-decoration-none">KVKK Aydınlatma Metni</a>'ni okudum, anladım ve kabul ediyorum.
              </label>
            </div>

            <button type="submit" class="btn btn-accent w-100 py-2.5 fw-bold">
              <i class="bi bi-check-circle-fill me-1"></i>Kaydı Tamamla
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- 3. KVKK AYDINLATMA METNİ MODALI -->
  <div class="modal fade" id="kvkkModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content border-0 shadow rounded-4">
        <div class="modal-header bg-navy text-white">
          <h5 class="modal-title fw-bold">KVKK Aydınlatma ve Veri Politikası</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body small text-secondary p-4 leading-relaxed">
          <h6>1. Veri Sorumlusu</h6>
          <p>6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) uyarınca, kişisel verileriniz veri sorumlusu olarak E-LEARN platformu tarafından işlenmektedir.</p>
          <h6>2. İşlenen Kişisel Veriler ve Amaçları</h6>
          <p>Öğrenci numarası, ad, soyad, e-posta, iletişim telefonu, sınav sonuçları ve başarı yüzdeleriniz yalnızca eğitim hizmetlerinin yürütülmesi, sınav değerlendirmeleri ve skorboard sıralaması amaçlarıyla işlenir.</p>
          <h6>3. Veri Minimizasyonu ve Gizlilik</h6>
          <p>Şifreleriniz kesinlikle geri döndürülemez kriptografik hashleme algoritmalarıyla korunur. Genel skorboard ekranında soyadınız yalnızca ilk harfi ile gösterilir ("Ahmet Y."), tam kimlik ve iletişim bilgileriniz asla kamuya açılmaz.</p>
          <h6>4. Saklama Süresi ve İmha Politikası</h6>
          <p>Log kayıtları ve denetim izleri yönetmelik gereği belirlenen azami saklama süresi (varsayılan 180 gün) sonunda otomatik olarak arşivlenir veya silinir.</p>
        </div>
        <div class="modal-footer bg-light py-2">
          <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Kapat</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap 5 Bundle JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- jQuery 3.7.1 -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- Global AJAX Form Handler -->
  <script>
    $(document).ready(function() {
      // Login Form AJAX
      $('#studentLoginForm').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $alert = $('#loginAlert');
        var $btn = $form.find('button[type="submit"]');

        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Giriş yapılıyor...');
        $alert.addClass('d-none').removeClass('alert-danger alert-success');

        $.ajax({
          url: '/elearn/index.php',
          type: 'POST',
          data: $form.serialize(),
          dataType: 'json',
          success: function(res) {
            $btn.prop('disabled', false).html('<i class="bi bi-box-arrow-in-right me-1"></i>Giriş Yap');
            if (res.success) {
              $alert.removeClass('d-none').addClass('alert-success').text(res.message || 'Giriş başarılı! Yönlendiriliyorsunuz...');
              setTimeout(function() {
                window.location.href = res.redirect || '/elearn/profile.php';
              }, 800);
            } else {
              $alert.removeClass('d-none').addClass('alert-danger').text(res.message || 'Giriş başarısız.');
            }
          },
          error: function() {
            // Standalone fallback: form submit doğrudan yönlensin
            $form.off('submit').submit();
          }
        });
      });

      // Register Form AJAX
      $('#studentRegisterForm').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $alert = $('#registerAlert');
        var $btn = $form.find('button[type="submit"]');

        $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Kayıt yapılıyor...');
        $alert.addClass('d-none').removeClass('alert-danger alert-success');

        $.ajax({
          url: '/elearn/index.php',
          type: 'POST',
          data: $form.serialize(),
          dataType: 'json',
          success: function(res) {
            $btn.prop('disabled', false).html('<i class="bi bi-check-circle-fill me-1"></i>Kaydı Tamamla');
            if (res.success) {
              $alert.removeClass('d-none').addClass('alert-success').text(res.message || 'Kayıt başarılı! Yönlendiriliyorsunuz...');
              setTimeout(function() {
                window.location.href = '/elearn/profile.php';
              }, 1000);
            } else {
              $alert.removeClass('d-none').addClass('alert-danger').text(res.message || 'Kayıt başarısız.');
            }
          },
          error: function() {
            $form.off('submit').submit();
          }
        });
      });
    });
  </script>
</body>
</html>
