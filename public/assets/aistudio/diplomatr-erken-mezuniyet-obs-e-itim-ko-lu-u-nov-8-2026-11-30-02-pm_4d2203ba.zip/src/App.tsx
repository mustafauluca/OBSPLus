import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TeamSection } from './components/TeamSection';
import { DepartmentsSection } from './components/DepartmentsSection';
import { OgrenciOBS } from './modules/ogrenci/OgrenciOBS';
import { AdminDashboard } from './modules/admin/AdminDashboard';
import { AuthModal } from './modules/ogrenci/AuthModal';
import { AkademisyenLoginModal } from './modules/akademi/AkademisyenLoginModal';
import { StudentCardModal } from './components/StudentCardModal';
import { DiplomaModal } from './components/DiplomaModal';
import { Footer } from './components/Footer';

import {
  DEPARTMENTS,
  INITIAL_UNIVERSITIES,
  CONSULTANTS_AND_STAFF,
} from './data/departmentsAndUniversities';
import { Department, StudentProfile, University } from './types';
import {
  generateStudentNumber,
  generateTcNo,
  generateInitialCurriculum,
  calculateGPA,
  calculateFinancials,
  getDepartmentThesis,
  getStudentAvatar,
} from './utils/academicRules';
import {
  getStoredUniversities,
  addUniversity,
  deleteUniversity,
} from './modules/universites/universityService';

export default function App() {
  const [universities, setUniversities] = useState<University[]>(getStoredUniversities());
  const [departments] = useState<Department[]>(DEPARTMENTS);
  const [currentView, setCurrentView] = useState<'home' | 'obs' | 'admin'>('home');

  // Modals state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('register');
  const [isAkademiModalOpen, setIsAkademiModalOpen] = useState(false);
  const [isIdCardModalOpen, setIsIdCardModalOpen] = useState(false);
  const [isDiplomaModalOpen, setIsDiplomaModalOpen] = useState(false);
  const [preselectedDeptId, setPreselectedDeptId] = useState<string | undefined>();

  // Students list and active student in OBS
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [activeStudent, setActiveStudent] = useState<StudentProfile | null>(null);

  // Initialize with initial registered active student record
  useEffect(() => {
    const defaultUni = universities[0] || INITIAL_UNIVERSITIES[0];
    const defaultDept = DEPARTMENTS[3]; // Bilgisayar Programcılığı (2 Yıllık Ön Lisans)
    const initialName = 'Ahmet Yılmaz';
    const initialAge = 25;
    const initialStudentNumber = generateStudentNumber(defaultUni.code, defaultDept.id, initialAge, initialName);
    const initialTc = generateTcNo(initialName, initialAge);

    const initialCourses = generateInitialCurriculum(
      defaultDept,
      'Uzatmalı (Artık Yıl)',
      2,
      'dismissed_amnesty',
      initialName
    );

    const missing = initialCourses.filter((c) => !c.passed);
    const missingAkts = missing.reduce((sum, c) => sum + c.akts, 0);

    const financials = calculateFinancials(
      2,
      missing.length,
      missingAkts,
      defaultDept.termFee,
      defaultDept.perCreditFee,
      'dismissed_amnesty'
    );

    const initialProfile: StudentProfile = {
      id: 'std-20261108',
      userId: 'usr-std-88',
      fullName: initialName,
      age: initialAge,
      tcNo: initialTc,
      email: 'ahmet.yilmaz@ogrenci.com',
      phone: '0541 914 12 48',
      studentNumber: initialStudentNumber,
      universityId: defaultUni.id,
      departmentId: defaultDept.id,
      status: 'dismissed_amnesty',
      currentClass: 'Uzatmalı (Artık Yıl)',
      delayedYears: 2,
      avatarUrl: getStudentAvatar(initialName),
      bloodType: 'A Rh(+)',
      registrationDate: '2026.09.15',
      registerIp: '176.234.88.14',
      assignedAdvisor: CONSULTANTS_AND_STAFF[0].name,
      thesisTopic: getDepartmentThesis(defaultDept, initialName),
      courses: initialCourses,
      financials,
      hasCommitted: false,
      isGraduated: false,
      gpa: calculateGPA(initialCourses),
      transcriptSubmissions: [],
      examAttempts: [],
    };

    setStudents([initialProfile]);
    setActiveStudent(initialProfile);

    // Support autostart query param
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1' || params.get('view') === 'obs') {
      setCurrentView('obs');
    } else if (params.get('view') === 'admin') {
      setCurrentView('admin');
    }
  }, []);

  // Handlers
  const handleOpenRegister = (deptId?: string) => {
    setPreselectedDeptId(deptId);
    setAuthModalMode('register');
    setIsAuthModalOpen(true);
  };

  const handleOpenLogin = () => {
    setAuthModalMode('login');
    setIsAuthModalOpen(true);
  };

  const handleAuthenticated = (profile: StudentProfile) => {
    setStudents((prev) => [profile, ...prev.filter((p) => p.id !== profile.id)]);
    setActiveStudent(profile);
    setCurrentView('obs');
  };

  const handleUpdateActiveStudent = (updated: StudentProfile) => {
    setActiveStudent(updated);
    setStudents((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  };

  const handleAddUniversity = (newUni: University) => {
    const updated = addUniversity(newUni);
    setUniversities(updated);
  };

  const handleDeleteUniversity = (uniId: string) => {
    const updated = deleteUniversity(uniId);
    setUniversities(updated);
  };

  const currentUni =
    universities.find((u) => u.id === activeStudent?.universityId) || universities[0];
  const currentDept =
    departments.find((d) => d.id === activeStudent?.departmentId) || departments[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-amber-100 selection:text-amber-900">
      {/* Universal Top Header Bar */}
      <Header
        onStartSimulation={() => handleOpenRegister()}
        onOpenObs={() => {
          if (activeStudent) {
            setCurrentView('obs');
          } else {
            handleOpenLogin();
          }
        }}
        onOpenAdmin={() => setIsAkademiModalOpen(true)}
        currentView={currentView}
        setCurrentView={setCurrentView}
        hasActiveStudent={Boolean(activeStudent)}
      />

      {/* Main Content Area Based on Active View */}
      <main className="flex-1">
        {currentView === 'home' && (
          <>
            <Hero
              onStartSimulation={() => handleOpenRegister()}
              onOpenConsultants={() => {
                document.getElementById('koclar')?.scrollIntoView({ behavior: 'smooth' });
              }}
            />
            <DepartmentsSection
              departments={departments}
              onSelectDepartmentForSimulation={(deptId) => handleOpenRegister(deptId)}
            />
            <TeamSection onStartSimulation={() => handleOpenRegister()} />
          </>
        )}

        {currentView === 'obs' && activeStudent && (
          <OgrenciOBS
            profile={activeStudent}
            university={currentUni}
            department={currentDept}
            onUpdateProfile={handleUpdateActiveStudent}
            onOpenIdCard={() => setIsIdCardModalOpen(true)}
            onOpenDiploma={() => setIsDiplomaModalOpen(true)}
            onReturnToHome={() => setCurrentView('home')}
          />
        )}

        {currentView === 'admin' && (
          <AdminDashboard
            universities={universities}
            onAddUniversity={handleAddUniversity}
            onDeleteUniversity={handleDeleteUniversity}
            students={students}
            departments={departments}
            onSelectStudent={(std) => {
              setActiveStudent(std);
              setCurrentView('obs');
            }}
            onReturnToHome={() => setCurrentView('home')}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onStartSimulation={() => handleOpenRegister()}
        onOpenAdmin={() => setIsAkademiModalOpen(true)}
        onOpenObs={() => {
          if (activeStudent) {
            setCurrentView('obs');
          } else {
            handleOpenLogin();
          }
        }}
      />

      {/* Student Authentication & Registration Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        universities={universities}
        departments={departments}
        initialMode={authModalMode}
        preselectedDepartmentId={preselectedDeptId}
        onAuthenticated={handleAuthenticated}
        existingStudents={students}
      />

      {/* Academician & Advisor Login Modal */}
      <AkademisyenLoginModal
        isOpen={isAkademiModalOpen}
        onClose={() => setIsAkademiModalOpen(false)}
        onLoginSuccess={(advisorName, role) => {
          setCurrentView('admin');
        }}
      />

      {/* Student Identity Card Modal (sablon_kimlik.html) */}
      {activeStudent && (
        <StudentCardModal
          isOpen={isIdCardModalOpen}
          onClose={() => setIsIdCardModalOpen(false)}
          profile={activeStudent}
          university={currentUni}
          department={currentDept}
        />
      )}

      {/* Official Diploma Modal (sablon_diploma.html) */}
      {activeStudent && (
        <DiplomaModal
          isOpen={isDiplomaModalOpen}
          onClose={() => setIsDiplomaModalOpen(false)}
          profile={activeStudent}
          university={currentUni}
          department={currentDept}
        />
      )}
    </div>
  );
}
