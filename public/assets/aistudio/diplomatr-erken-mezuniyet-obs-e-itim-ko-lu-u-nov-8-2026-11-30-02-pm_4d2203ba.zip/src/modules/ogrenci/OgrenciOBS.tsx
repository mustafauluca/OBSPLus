import React, { useState } from 'react';
import {
  GraduationCap,
  Award,
  BookOpen,
  DollarSign,
  FileCheck2,
  AlertTriangle,
  CheckCircle2,
  Send,
  UserCheck,
  CreditCard,
  Download,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building,
  HelpCircle,
  FileText,
  Clock,
  Edit3,
  X,
} from 'lucide-react';
import {
  CourseGrade,
  Department,
  StudentProfile,
  University,
  TranscriptSubmission,
  ExamAttempt,
} from '../../types';
import {
  calculateGPA,
  calculateFinancials,
  applyCoachingRemediation,
  formatTL,
  scoreToLetter,
} from '../../utils/academicRules';
import { logAuditEvent } from '../admin/auditService';
import { TranscriptSubmissionModal } from './TranscriptSubmissionModal';
import { ExamModal } from '../exams/ExamModal';
import { TemporaryCertificateModal } from '../exams/TemporaryCertificateModal';

interface OgrenciOBSProps {
  profile: StudentProfile;
  university: University;
  department: Department;
  onUpdateProfile: (updated: StudentProfile) => void;
  onOpenIdCard: () => void;
  onOpenDiploma: () => void;
  onReturnToHome: () => void;
}

export const OgrenciOBS: React.FC<OgrenciOBSProps> = ({
  profile,
  university,
  department,
  onUpdateProfile,
  onOpenIdCard,
  onOpenDiploma,
  onReturnToHome,
}) => {
  const [activeTab, setActiveTab] = useState<'curriculum' | 'financials' | 'thesis' | 'exams'>('curriculum');
  const [isCommitModalOpen, setIsCommitModalOpen] = useState(false);
  const [commitmentAgreed, setCommitmentAgreed] = useState(false);
  const [isEditingCourse, setIsEditingCourse] = useState<CourseGrade | null>(null);
  const [editMidterm, setEditMidterm] = useState<number>(50);
  const [editFinal, setEditFinal] = useState<number>(60);
  const [isTranscriptModalOpen, setIsTranscriptModalOpen] = useState(false);
  const [isExamModalOpen, setIsExamModalOpen] = useState(false);
  const [isCertificateModalOpen, setIsCertificateModalOpen] = useState(false);
  const [activeExamAttempt, setActiveExamAttempt] = useState<ExamAttempt | undefined>(
    profile.examAttempts?.[0]
  );

  const missingCourses = profile.courses.filter((c) => !c.passed);
  const passedCourses = profile.courses.filter((c) => c.passed);
  const totalAkts = profile.courses.reduce((sum, c) => sum + c.akts, 0);
  const earnedAkts = passedCourses.reduce((sum, c) => sum + c.akts, 0);

  // Group courses by term
  const coursesByTerm: { [term: number]: CourseGrade[] } = {};
  profile.courses.forEach((c) => {
    if (!coursesByTerm[c.term]) coursesByTerm[c.term] = [];
    coursesByTerm[c.term].push(c);
  });

  // Apply coaching remediation
  const handleApplyCoaching = () => {
    const remediatedCourses = applyCoachingRemediation(profile.courses);
    const newGpa = calculateGPA(remediatedCourses);
    const missing = remediatedCourses.filter((c) => !c.passed);
    const missingAkts = missing.reduce((sum, c) => sum + c.akts, 0);

    const newFinancials = calculateFinancials(
      profile.delayedYears,
      missing.length,
      missingAkts,
      department.termFee,
      department.perCreditFee,
      profile.status
    );

    const updated: StudentProfile = {
      ...profile,
      courses: remediatedCourses,
      financials: newFinancials,
      gpa: newGpa,
    };

    logAuditEvent(
      'grade_update',
      { id: profile.userId, name: profile.fullName, role: 'student' },
      `Akademik koçluk not ataması uygulandı. Yeni GNO: ${newGpa.toFixed(2)}`
    );

    onUpdateProfile(updated);
  };

  // Save manual course grade edit
  const handleSaveCourseEdit = () => {
    if (!isEditingCourse) return;

    const { letterGrade, gradePoint, passed } = scoreToLetter(editMidterm, editFinal);
    const updatedCourses = profile.courses.map((c) => {
      if (c.code === isEditingCourse.code) {
        return {
          ...c,
          midterm: editMidterm,
          final: editFinal,
          letterGrade,
          gradePoint,
          passed,
          status: 'student_entered' as const,
        };
      }
      return c;
    });

    const newGpa = calculateGPA(updatedCourses);
    const missing = updatedCourses.filter((c) => !c.passed);
    const missingAkts = missing.reduce((sum, c) => sum + c.akts, 0);

    const newFinancials = calculateFinancials(
      profile.delayedYears,
      missing.length,
      missingAkts,
      department.termFee,
      department.perCreditFee,
      profile.status
    );

    const updated: StudentProfile = {
      ...profile,
      courses: updatedCourses,
      financials: newFinancials,
      gpa: newGpa,
    };

    logAuditEvent(
      'grade_update',
      { id: profile.userId, name: profile.fullName, role: 'student' },
      `Ders notu güncellendi: ${isEditingCourse.code} (${editMidterm}/${editFinal} -> ${letterGrade})`
    );

    onUpdateProfile(updated);
    setIsEditingCourse(null);
  };

  // Sign financial & academic commitment
  const handleSignCommitment = () => {
    const updated: StudentProfile = {
      ...profile,
      hasCommitted: true,
      isGraduated: true,
      graduationDate: '08 Kasım 2026',
      diplomaNumber: `DIP-${university.code}-${profile.studentNumber.slice(-6)}`,
    };

    logAuditEvent(
      'commitment_sign',
      { id: profile.userId, name: profile.fullName, role: 'student' },
      `Mezuniyet taahhütnamesi dijital olarak imzalandı. Mezuniyet onaylandı.`
    );

    onUpdateProfile(updated);
    setIsCommitModalOpen(false);
  };

  // Handle transcript submission
  const handleTranscriptSubmit = (submission: TranscriptSubmission) => {
    const updated: StudentProfile = {
      ...profile,
      transcriptSubmissions: [submission, ...(profile.transcriptSubmissions || [])],
    };
    onUpdateProfile(updated);
  };

  // Handle exam passed
  const handleExamPassed = (attempt: ExamAttempt) => {
    setActiveExamAttempt(attempt);
    const updated: StudentProfile = {
      ...profile,
      examAttempts: [attempt, ...(profile.examAttempts || [])],
    };
    onUpdateProfile(updated);
  };

  return (
    <div className="bg-slate-100 min-h-screen py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        {/* OBS Navigation & Title Bar */}
        <div className="bg-slate-900 rounded-2xl p-5 sm:p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={profile.avatarUrl}
                alt={profile.fullName}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400 shadow-md bg-slate-800"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-white">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-mono text-xs font-bold border border-amber-500/30">
                  Öğrenci No: {profile.studentNumber}
                </span>
                <span className="px-2.5 py-0.5 rounded-md bg-slate-800 text-slate-300 text-xs font-medium">
                  {profile.status === 'dismissed_amnesty'
                    ? 'Öğrenci Affı İntibak'
                    : profile.status === 'passive'
                    ? 'Pasif Kayıt / Yenileme'
                    : 'Aktif Öğrenci'}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-1">
                {profile.fullName}
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                {university.name} • {department.name} ({department.type})
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenIdCard}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 border border-slate-700 transition-colors cursor-pointer"
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              <span>Öğrenci Kimliğini Aç / İndir</span>
            </button>

            {profile.isGraduated ? (
              <button
                onClick={onOpenDiploma}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
              >
                <Award className="w-4 h-4" />
                <span>Resmi Diplomanı Aç / İndir</span>
              </button>
            ) : (
              <button
                onClick={() => setIsCommitModalOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-2 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
              >
                <FileCheck2 className="w-4 h-4" />
                <span>Mezuniyet & Taahhüt Onayı</span>
              </button>
            )}

            <button
              onClick={onReturnToHome}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-medium transition-colors cursor-pointer"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>

        {/* Graduation Notification Banner (If Graduated) */}
        {profile.isGraduated && (
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-900 via-slate-900 to-slate-950 text-white border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/40">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-emerald-300">
                  Tebrikler! Resmi Mezuniyetiniz Onaylandı
                </h3>
                <p className="text-xs text-slate-300">
                  Tüm akademik ve mali şartlar tamamlanmıştır. Diplomanız {university.code} rektörlük onayından geçmiştir.
                </p>
              </div>
            </div>
            <button
              onClick={onOpenDiploma}
              className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black flex items-center gap-2 shadow-md shrink-0 cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Diplomayı Gör & İndir</span>
            </button>
          </div>
        )}

        {/* Student Metrics 4-Card Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Genel Not Ortalaması
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900">
                {profile.gpa.toFixed(2)}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ 4.00</span>
            </div>
            <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{profile.gpa >= 2.0 ? 'Mezuniyet Şartını Sağlıyor' : 'Baraj Altında'}</span>
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Tamamlanan AKTS Kredisi
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black font-mono text-slate-900">
                {earnedAkts}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ {totalAkts} AKTS</span>
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-1">
              {missingCourses.length > 0 ? `${missingCourses.length} eksik ders mevcut` : 'Tüm krediler tamamlandı'}
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Atanan Baş Danışman
            </div>
            <div className="text-sm sm:text-base font-bold text-slate-900 mt-1 truncate">
              {profile.assignedAdvisor}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-amber-600" />
              <span>İntibak Danışmanlığı Aktif</span>
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Toplam Mali Yükümlülük
            </div>
            <div className="text-xl sm:text-2xl font-black font-mono text-amber-700 mt-1">
              {formatTL(profile.financials.totalPayable)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 truncate">
              Harç + Kredi + 10.000 TL Burs
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="bg-white rounded-2xl border border-slate-200 p-2 flex flex-wrap gap-2 shadow-xs">
          <button
            onClick={() => setActiveTab('curriculum')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'curriculum'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>Müfredat ve Transkript Durumu ({profile.courses.length} Ders)</span>
          </button>

          <button
            onClick={() => setActiveTab('financials')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'financials'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <DollarSign className="w-4 h-4 text-amber-400" />
            <span>Harç, Borç ve Burs Hesabı</span>
          </button>

          <button
            onClick={() => setActiveTab('thesis')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'thesis'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>Bitirme Projesi / Tez Konusu</span>
          </button>

          <button
            onClick={() => setActiveTab('exams')}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'exams'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>Sınavlar & Geçici Mezuniyet Belgesi</span>
          </button>
        </div>

        {/* Tab 1: Curriculum & Transcripts */}
        {activeTab === 'curriculum' && (
          <div className="space-y-6">
            {/* Remediation and Action Bar */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span>Ders İntibakı ve Not Durumu</span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-semibold">
                    {department.totalSemesters} Yarıyıl
                  </span>
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                  Öğrencinin transkriptindeki eksik veya başarısız dersler aşağıda listelenmiştir. İster manuel not girişi yapabilir,
                  isterseniz koçluk sistemiyle eksik dersleri geçme notu ve fazlasıyla tamamlayabilirsiniz.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
                <button
                  type="button"
                  onClick={() => setIsTranscriptModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4 text-slate-600" />
                  <span>Danışmana Transkript Gönder</span>
                </button>

                {missingCourses.length > 0 && (
                  <button
                    onClick={handleApplyCoaching}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold flex items-center gap-2 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Koçluk ile Eksik Notları Tamamla ({missingCourses.length})</span>
                  </button>
                )}
              </div>
            </div>

            {/* Semester-by-Semester Tables */}
            <div className="space-y-6">
              {Object.keys(coursesByTerm).map((termStr) => {
                const termNum = Number(termStr);
                const courses = coursesByTerm[termNum];
                const termMissing = courses.filter((c) => !c.passed).length;

                return (
                  <div
                    key={termNum}
                    className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden"
                  >
                    <div className="bg-slate-50 px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="w-6 h-6 rounded-lg bg-slate-900 text-white text-xs font-bold flex items-center justify-center font-mono">
                          {termNum}
                        </span>
                        <span className="text-sm font-bold text-slate-900">
                          {termNum}. Yarıyıl Müfredat Dersleri
                        </span>
                      </div>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                          termMissing === 0
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-900'
                        }`}
                      >
                        {termMissing === 0 ? 'Tüm Dersler Başarılı' : `${termMissing} Eksik Ders`}
                      </span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100/75 text-slate-500 font-semibold border-b border-slate-200">
                          <tr>
                            <th className="py-3 px-4">Ders Kodu</th>
                            <th className="py-3 px-4">Ders Adı</th>
                            <th className="py-3 px-3 text-center">Kredi</th>
                            <th className="py-3 px-3 text-center">AKTS</th>
                            <th className="py-3 px-3 text-center">Vize</th>
                            <th className="py-3 px-3 text-center">Final</th>
                            <th className="py-3 px-3 text-center">Harf Notu</th>
                            <th className="py-3 px-4 text-center">Durum</th>
                            <th className="py-3 px-3 text-right">İşlem</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {courses.map((c) => (
                            <tr
                              key={c.code}
                              className={`hover:bg-slate-50 transition-colors ${
                                !c.passed ? 'bg-amber-50/30' : ''
                              }`}
                            >
                              <td className="py-3 px-4 font-mono font-bold text-slate-700">
                                {c.code}
                              </td>
                              <td className="py-3 px-4 font-medium text-slate-900">
                                {c.name}
                              </td>
                              <td className="py-3 px-3 text-center font-mono text-slate-600">
                                {c.credit}
                              </td>
                              <td className="py-3 px-3 text-center font-mono text-slate-600">
                                {c.akts}
                              </td>
                              <td className="py-3 px-3 text-center font-mono">
                                {c.midterm > 0 ? c.midterm : '-'}
                              </td>
                              <td className="py-3 px-3 text-center font-mono">
                                {c.final > 0 ? c.final : '-'}
                              </td>
                              <td className="py-3 px-3 text-center">
                                <span
                                  className={`px-2 py-0.5 rounded font-mono font-bold text-xs ${
                                    c.passed
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-red-100 text-red-700'
                                  }`}
                                >
                                  {c.letterGrade}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-center">
                                <span
                                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                                    c.passed
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : 'bg-amber-50 text-amber-800 border border-amber-200'
                                  }`}
                                >
                                  {c.passed ? 'Geçti' : 'Kaldı / Eksik'}
                                </span>
                              </td>
                              <td className="py-3 px-3 text-right">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setIsEditingCourse(c);
                                    setEditMidterm(c.midterm || 50);
                                    setEditFinal(c.final || 60);
                                  }}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
                                  title="Notu Düzenle"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: Financials & Debt Breakdown */}
        {activeTab === 'financials' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-amber-500" />
                <span>Öğrenim Harcı, Eksik Kredi ve Burs Geri Ödeme Dökümü</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                YÖK mevzuatı gereği kaç yıl geriden gelinmişse ödenmemiş harçların tümü, eksik kredilerin ücreti
                ve tahsis edilen 10.000,00 TL öğrenim bursunun geri ödemesi tahakkuk ettirilir.
              </p>

              {/* Financial Calculation Breakdown Table */}
              <div className="mt-6 border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-3.5">Borç Kalemi</th>
                      <th className="p-3.5 text-center">Birim / Miktar</th>
                      <th className="p-3.5 text-right">Tutar (TL)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">Geçmiş Yıllara Ait Ödenmemiş Öğrenim Harcı</div>
                        <div className="text-[11px] text-slate-500">
                          {profile.delayedYears > 0
                            ? `${profile.delayedYears} Yıl (${profile.financials.unpaidSemestersCount} Yarıyıl) gecikme harcı`
                            : 'Kayıt yenileme ve pasif dönem intibak harcı'}
                        </div>
                      </td>
                      <td className="p-3.5 text-center font-mono">
                        {profile.financials.unpaidSemestersCount} Dönem x {formatTL(department.termFee)}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900">
                        {formatTL(profile.financials.totalTuitionDebt)}
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">Eksik Müfredat ve Kredi Tamamlama Ücreti</div>
                        <div className="text-[11px] text-slate-500">
                          {profile.financials.missingCoursesCount} eksik ders ({profile.financials.missingAktsTotal} AKTS)
                        </div>
                      </td>
                      <td className="p-3.5 text-center font-mono">
                        {profile.financials.missingAktsTotal} AKTS
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900">
                        {formatTL(profile.financials.totalCoursesFee)}
                      </td>
                    </tr>

                    <tr>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">Öğrenim Bursu Geri Ödemesi</div>
                        <div className="text-[11px] text-slate-500">
                          Tüm öğrencilere tahsis edilen 10.000,00 TL öğrenim bursu borç bakiyesi
                        </div>
                      </td>
                      <td className="p-3.5 text-center font-mono">
                        Sabit Burs
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900">
                        {formatTL(profile.financials.scholarshipDebt)}
                      </td>
                    </tr>

                    <tr className="bg-amber-50/60 font-bold text-sm">
                      <td className="p-4 text-amber-950 font-black">
                        GENEL TOPLAM MALİ YÜKÜMLÜLÜK
                      </td>
                      <td className="p-4 text-center font-mono text-amber-900">
                        Nihai Bakiye
                      </td>
                      <td className="p-4 text-right font-mono font-black text-amber-900 text-base">
                        {formatTL(profile.financials.totalPayable)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Commitment Action Box */}
              <div className="mt-6 p-5 rounded-xl bg-slate-900 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-amber-400">
                    {profile.hasCommitted
                      ? 'Mezuniyet Şartları ve Mali Taahhütname Onaylandı'
                      : 'Mezuniyet Taahhütnamesini İnceleyin ve Onaylayın'}
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                    Yukarıdaki borç ve eksik ders yükümlülüklerini taahhüt ederek mezuniyet onayını alabilir,
                    resmi diplomayı ve geçici mezuniyet belgesini tescil ettirebilirsiniz.
                  </p>
                </div>

                {!profile.hasCommitted ? (
                  <button
                    onClick={() => setIsCommitModalOpen(true)}
                    className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-2 shadow-lg shadow-amber-500/20 shrink-0 cursor-pointer"
                  >
                    <FileCheck2 className="w-4 h-4" />
                    <span>Şartları Taahhüt Et & Mezun Ol</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Taahhütname Onaylıdır</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Thesis / Capstone Project */}
        {activeTab === 'thesis' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                    {department.name} Bitirme Çalışması
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                    {profile.thesisTopic}
                  </h3>
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                  Danışman Onaylı
                </span>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-slate-500">Tez / Proje Danışmanı:</span>
                  <div className="font-bold text-slate-900 mt-0.5">{profile.assignedAdvisor}</div>
                </div>
                <div>
                  <span className="text-slate-500">Kabul Tarihi:</span>
                  <div className="font-bold text-slate-900 mt-0.5">{profile.registrationDate}</div>
                </div>
                <div>
                  <span className="text-slate-500">İntihal (Benzerlik) Oranı:</span>
                  <div className="font-bold text-emerald-600 mt-0.5">%8 (Kabul Sınırı Dahilinde)</div>
                </div>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                Bitirme tezi ve uygulamalı proje çalışması, YÖK lisans/ön lisans yeterlilik çerçevesine uygun olarak
                {profile.assignedAdvisor} denetiminde incelenmiş ve tam not ile kabul edilmiştir.
              </p>
            </div>
          </div>
        )}

        {/* Tab 4: Exams & Temporary Certificate */}
        {activeTab === 'exams' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-500" />
                    <span>YÖK Bitirme ve İntibak Yeterlilik Sınavı</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-xl">
                    Geçici mezuniyet belgesi hak edebilmek veya eksik muafiyetleri teyit etmek için online yeterlilik
                    sınavına katılabilirsiniz. Baraj notu 60 puandır.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsExamModalOpen(true)}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-2 shadow-md shrink-0 cursor-pointer"
                >
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Sınava Gir / Yeniden Dene</span>
                </button>
              </div>

              {/* Exam Attempts List */}
              {profile.examAttempts && profile.examAttempts.length > 0 ? (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-3.5">Sınav Adı</th>
                        <th className="p-3.5 text-center">Tarih</th>
                        <th className="p-3.5 text-center">Puan</th>
                        <th className="p-3.5 text-center">Sonuç</th>
                        <th className="p-3.5 text-right">Belge</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {profile.examAttempts.map((attempt) => (
                        <tr key={attempt.id} className="hover:bg-slate-50">
                          <td className="p-3.5 font-semibold text-slate-900">{attempt.examTitle}</td>
                          <td className="p-3.5 text-center font-mono text-slate-600">{attempt.attemptDate}</td>
                          <td className="p-3.5 text-center font-mono font-bold">{attempt.score} / 100</td>
                          <td className="p-3.5 text-center">
                            <span
                              className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                                attempt.passed
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-red-100 text-red-700'
                              }`}
                            >
                              {attempt.passed ? 'BAŞARILI' : 'BAŞARISIZ'}
                            </span>
                          </td>
                          <td className="p-3.5 text-right">
                            {attempt.passed && (
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveExamAttempt(attempt);
                                  setIsCertificateModalOpen(true);
                                }}
                                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 ml-auto cursor-pointer"
                              >
                                <Download className="w-3.5 h-3.5" />
                                <span>Geçici Belgeyi Aç (PDF)</span>
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-2">
                  <div className="text-slate-400 text-xs">Henüz bir sınav girişiminiz bulunmuyor.</div>
                  <p className="text-xs text-slate-600">
                    Sınava girerek 60 ve üzeri puan alabilir ve anında adınıza tanzim edilmiş Geçici Mezuniyet Belgesini indirebilirsiniz.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Manual Grade Edit Modal */}
      {isEditingCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">{isEditingCourse.name}</h3>
                <div className="text-xs text-slate-500 font-mono">{isEditingCourse.code} • {isEditingCourse.akts} AKTS</div>
              </div>
              <button
                onClick={() => setIsEditingCourse(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Vize Notu (1-100)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={editMidterm}
                  onChange={(e) => setEditMidterm(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Final Notu (1-100)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={editFinal}
                  onChange={(e) => setEditFinal(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                />
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 text-xs flex justify-between items-center">
              <span>Hesaplanan Harf Notu:</span>
              <span className="font-bold font-mono text-slate-900">
                {scoreToLetter(editMidterm, editFinal).letterGrade} (Katsayı: {scoreToLetter(editMidterm, editFinal).gradePoint})
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingCourse(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleSaveCourseEdit}
                className="px-5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
              >
                Notu Kaydet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Commitment Signature Modal */}
      {isCommitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-4 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <FileCheck2 className="w-5 h-5 text-amber-500" />
                <h3 className="text-base font-bold text-slate-900">Resmi Mezuniyet Taahhütnamesi</h3>
              </div>
              <button
                onClick={() => setIsCommitModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 text-xs text-amber-950 space-y-2 leading-relaxed">
              <p>
                Ben, <strong>{profile.fullName}</strong> (T.C. Kimlik No: {profile.tcNo}, Öğrenci No: {profile.studentNumber}),
                {university.name} {department.name} programındaki geçmiş {profile.financials.unpaidTuitionYears} yıla ait
                ödenmemiş harçları, eksik kredi bedellerini ve 10.000,00 TL tutarındaki öğrenim bursu borcumu
                (Toplam: {formatTL(profile.financials.totalPayable)}) ödeyeceğimi; intibak ve mezuniyet şartlarını sağladığımı
                beyan ve taahhüt ederim.
              </p>
            </div>

            <label className="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <input
                type="checkbox"
                checked={commitmentAgreed}
                onChange={(e) => setCommitmentAgreed(e.target.checked)}
                className="w-4 h-4 rounded text-amber-600 mt-0.5 focus:ring-amber-500"
              />
              <span className="text-xs text-slate-700 font-medium">
                Yukarıdaki mali yükümlülükleri ve akademik intibak koşullarını okudum, anladım ve taahhüt ediyorum.
              </span>
            </label>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCommitModalOpen(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="button"
                disabled={!commitmentAgreed}
                onClick={handleSignCommitment}
                className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 text-xs font-extrabold flex items-center gap-2 shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Taahhüdü İmzala & Mezuniyeti Onayla</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Transcript Submission Modal */}
      <TranscriptSubmissionModal
        isOpen={isTranscriptModalOpen}
        onClose={() => setIsTranscriptModalOpen(false)}
        profile={profile}
        department={department}
        onSubmit={handleTranscriptSubmit}
      />

      {/* Exam Modal */}
      <ExamModal
        isOpen={isExamModalOpen}
        onClose={() => setIsExamModalOpen(false)}
        profile={profile}
        onExamPassed={handleExamPassed}
      />

      {/* Temporary Certificate Modal */}
      <TemporaryCertificateModal
        isOpen={isCertificateModalOpen}
        onClose={() => setIsCertificateModalOpen(false)}
        profile={profile}
        university={university}
        department={department}
        attempt={activeExamAttempt}
      />
    </div>
  );
};
