export type ProgramType = '2 Yıllık (Ön Lisans)' | '4 Yıllık (Lisans)';

export type StudentStatus = 
  | 'active'              // Aktif Öğrenci
  | 'passive'             // Pasif Kayıt / Kayıt Yenileme Bekleyen
  | 'dismissed_amnesty';  // Kaydı Silinmiş / Öğrenci Affından Yararlanan

export interface UserAccount {
  id: string;
  email: string;
  tcNo: string;
  fullName: string;
  role: 'student' | 'admin' | 'advisor';
  passwordHash: string;
  registerIp: string;
  lastLoginIp: string;
  createdAt: string;
  lastLoginAt: string;
  studentId?: string;
}

export type AuditAction = 
  | 'register' 
  | 'login' 
  | 'logout'
  | 'grade_update' 
  | 'transcript_submit' 
  | 'advisor_review'
  | 'commitment_sign' 
  | 'exam_submit' 
  | 'id_card_download' 
  | 'diploma_download'
  | 'university_add'
  | 'university_delete';

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: 'student' | 'admin' | 'advisor' | 'system';
  action: AuditAction;
  ipAddress: string;
  details: string;
}

export interface University {
  id: string;
  code: string;           // e.g. 'AÜ', 'EAÜ', 'İÜ', 'MEÜ', 'DEÜ'
  name: string;
  city: string;
  rectorName: string;
  deanName: string;
  sealColor: string;
  badgeBg: string;
  establishedYear: number;
}

export interface CourseDefinition {
  code: string;
  name: string;
  term: number;           // 1..8
  akts: number;
  credit: number;
  isMandatory: boolean;
}

export interface Department {
  id: string;
  name: string;
  type: ProgramType;
  faculty: string;
  totalSemesters: number;
  totalAkts: number;
  termFee: number;
  perCreditFee: number;
  courses: CourseDefinition[];
  thesisTopics: string[];
}

export interface CourseGrade {
  code: string;
  name: string;
  term: number;
  akts: number;
  credit: number;
  midterm: number;        // Vize
  final: number;          // Final
  makeup?: number;        // Büt (varsa)
  letterGrade: 'AA' | 'BA' | 'BB' | 'CB' | 'CC' | 'DC' | 'DD' | 'FF';
  gradePoint: number;
  passed: boolean;
  status: 'passed' | 'failed' | 'coached_passed' | 'student_entered';
}

export interface FinancialBreakdown {
  unpaidTuitionYears: number;
  unpaidSemestersCount: number;
  semesterFee: number;
  totalTuitionDebt: number;       // Kaç yıl geriden gelmişse ödenmemiş harçların tümü
  missingCoursesCount: number;
  missingAktsTotal: number;
  totalCoursesFee: number;        // Eksik derslerin toplam ücreti
  scholarshipDebt: number;        // Tüm öğrencilerin 10.000,00 TL burs aldığını varsayıyoruz
  totalPayable: number;           // Genel toplam
}

export interface ExamQuestion {
  id: string;
  text: string;
  options: string[];
  correctIndex: number;
}

export interface Exam {
  id: string;
  title: string;
  departmentId: string;
  courseCode?: string;
  durationMinutes: number;
  totalQuestions: number;
  passScore: number;             // Baraj notu (örn: 60)
  questions: ExamQuestion[];
}

export interface ExamAttempt {
  id: string;
  studentId: string;
  studentName: string;
  examId: string;
  examTitle: string;
  score: number;
  passed: boolean;
  attemptDate: string;
  certificateNumber?: string;
}

export interface TranscriptSubmission {
  id: string;
  studentId: string;
  studentName: string;
  departmentName: string;
  submittedAt: string;
  studentNote: string;
  status: 'pending' | 'reviewed' | 'approved';
  advisorFeedback?: string;
}

export interface StudentProfile {
  id: string;
  userId: string;
  fullName: string;
  age: number;
  tcNo: string;
  email: string;
  phone: string;
  studentNumber: string;
  universityId: string;
  departmentId: string;
  status: StudentStatus;
  currentClass: string;
  delayedYears: number;
  avatarUrl: string;
  bloodType: string;
  registrationDate: string;
  registerIp: string;
  assignedAdvisor: string;
  thesisTopic: string;
  courses: CourseGrade[];
  financials: FinancialBreakdown;
  hasCommitted: boolean;
  isGraduated: boolean;
  graduationDate?: string;
  diplomaNumber?: string;
  gpa: number;
  transcriptSubmissions: TranscriptSubmission[];
  examAttempts: ExamAttempt[];
}
