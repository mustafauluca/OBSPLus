import React from 'react';
import { GraduationCap, Phone, Mail, ShieldCheck, Download, Code, ArrowUpRight } from 'lucide-react';
import { CONTACT_PHONE, CONTACT_EMAIL } from '../data/departmentsAndUniversities';

interface FooterProps {
  onStartSimulation: () => void;
  onOpenAdmin: () => void;
  onOpenObs: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onStartSimulation,
  onOpenAdmin,
  onOpenObs,
}) => {
  return (
    <footer id="iletisim" className="bg-slate-950 text-slate-300 border-t border-slate-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Brand & Purpose */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                diplomatr<span className="text-amber-400">.com</span>
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Eğitim Koçlarımız ve Danışmanlarımız ile erken mezun olup diplomanı gecikmeden sene
              uzatmadan alabilirsin. YÖK mevzuatı, öğrenci affı, pasif kayıt yenileme, eksik ders
              tamamlama ve intibak danışmanlık merkezi.
            </p>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-amber-300 flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Akademik Danışma & Başvuru Hattı</span>
              </div>
              <div className="text-lg font-black font-mono text-white tracking-wide">
                {CONTACT_PHONE}
              </div>
              <div className="text-[11px] text-slate-400">
                Hafta içi & Hafta sonu: 09:00 - 21:00 Danışman Desteği
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">
              Hızlı Erişim & Başvuru
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onStartSimulation}
                  className="text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Mezuniyet & İntibak Planı Başlat</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenObs}
                  className="text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Öğrenci Bilgi Sistemi (diplomatr.com/obs)</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenAdmin}
                  className="text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Akademisyen & Yönetim Girişi</span>
                  <ArrowUpRight className="w-3 h-3" />
                </button>
              </li>
              <li>
                <a
                  href="#koclar"
                  className="text-slate-400 hover:text-amber-400 transition-colors block"
                >
                  Eğitim Psikolojisi & Koçluk Heyeti
                </a>
              </li>
              <li>
                <a
                  href="#bolumler"
                  className="text-slate-400 hover:text-amber-400 transition-colors block"
                >
                  14 Program (Ön Lisans & Lisans)
                </a>
              </li>
            </ul>
          </div>

          {/* Academic Heyet Credits */}
          <div className="lg:col-span-4 space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">
              Akademik Heyet & Yetkililer
            </div>
            <div className="text-xs text-slate-400 space-y-1.5 leading-snug">
              <div>
                <strong className="text-slate-200">Prof. Dr. Murat DOĞAN</strong> — Eğitim Psikolojisi Uzmanı & Başdanışman
              </div>
              <div>
                <strong className="text-slate-200">Ceyda SÖZER</strong> — Akademisyen & Müfredat Uzmanı
              </div>
              <div>
                <strong className="text-slate-200">Serkan DUMAN</strong> — Akademisyen & Sınav Stratejisti
              </div>
              <div>
                <strong className="text-slate-200">Ahmet KOÇYILMAZ</strong> — Akademisyen & Hukuk / Af Danışmanı
              </div>
              <div>
                <strong className="text-slate-200">Numan YILDIRIM</strong> — Genel Sekreter
              </div>
              <div>
                <strong className="text-slate-200">Büşra DEMİR</strong> — Yönetici Asistanı
              </div>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>YÖK Öğrenci Affı & Üniversite Mevzuatı Uyumlu Danışmanlık</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar & FTP Deployment Notice */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © 2026 diplomatr.com — Tüm Hakları Saklıdır. Erken Mezuniyet & OBS Danışmanlığı.
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 text-slate-400">
              <Code className="w-3.5 h-3.5 text-amber-400" />
              <span>PHP/MySQL Standalone Bundle /dist Hazır</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
