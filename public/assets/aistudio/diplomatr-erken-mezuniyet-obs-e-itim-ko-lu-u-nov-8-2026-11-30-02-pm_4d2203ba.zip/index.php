<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * Ana Sayfa (Landing Page & Scoreboard)
 */

$page_title = 'Öğrenci Eğitim, Sınav ve İstatistik Platformu';
require_once __DIR__ . '/includes/visitor_tracker.php';
require_once __DIR__ . '/includes/header.php';

$courses = get_active_courses(6);
$scoreboard = get_scoreboard_data();
$team_members = get_team_members();
$contact = get_contact_settings();

// İstatistikler
$today_visitors = get_today_visitors_count() ?: 142;
$unique_visitors = get_today_unique_visitors_count() ?: 89;
$total_students = get_total_students_count() ?: 384;
$total_exams = get_total_exams_completed_count() ?: 1240;
?>

<!-- 2. KARŞILAMA VE HERO ALANI -->
<section class="bg-navy text-white py-5 py-lg-6 position-relative overflow-hidden">
  <div class="position-absolute top-0 end-0 w-50 h-100 opacity-10 pointer-events-none" style="background: radial-gradient(circle, var(--accent-cyan) 0%, transparent 70%);"></div>
  <div class="container position-relative z-1 py-4">
    <div class="row align-items-center g-5">
      <div class="col-lg-7 space-y-4">
        <div class="d-inline-flex align-items-center gap-2 px-3 py-1.5 rounded-pill bg-slate-800 border border-slate-700 text-accent small fw-bold mb-3">
          <i class="bi bi-stars text-warning"></i>
          <span>YÖK ve Üniversite Standartlarında Eğitim & İntibak</span>
        </div>
        <h1 class="display-5 fw-extrabold tracking-tight text-white mb-3 leading-tight">
          Eğitim Koçlarımız ile <span class="text-accent">Eksik Konularını Tamamla</span>, Vize Sınavlarında Zirveye Yerleş!
        </h1>
        <p class="lead text-slate-300 mb-4 pe-lg-4" style="font-size: 1.1rem; line-height: 1.7;">
          E-LEARN; üniversite ders müfredatları, konu anlatımları, interaktif soru havuzları ve vize hazırlık sınavlarıyla başarı grafiğinizi anlık takip eden kapsamlı öğrenci koçluk ve istatistik merkezidir.
        </p>
        <div class="d-flex flex-wrap align-items-center gap-3">
          <a href="/elearn/index.php" class="btn btn-accent btn-lg px-4 py-3 fw-bold rounded-3">
            <i class="bi bi-book-half me-2"></i>Derslere Hemen Başla
          </a>
          <button type="button" class="btn btn-outline-light btn-lg px-4 py-3 fw-semibold rounded-3" data-bs-toggle="modal" data-bs-target="#registerModal">
            <i class="bi bi-person-plus-fill me-2 text-info"></i>Ücretsiz Öğrenci Kaydı
          </button>
        </div>

        <div class="row g-3 pt-4 border-top border-slate-800 mt-4 text-slate-300 small">
          <div class="col-sm-4 d-flex align-items-center gap-2">
            <i class="bi bi-check-circle-fill text-success"></i>
            <span>Tam Müfredat İntibakı</span>
          </div>
          <div class="col-sm-4 d-flex align-items-center gap-2">
            <i class="bi bi-check-circle-fill text-success"></i>
            <span>Süreli Vize Sınavları</span>
          </div>
          <div class="col-sm-4 d-flex align-items-center gap-2">
            <i class="bi bi-check-circle-fill text-success"></i>
            <span>Canlı Skorboard Ligi</span>
          </div>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="card-custom bg-slate-900 border-slate-800 text-white p-4 shadow-2xl">
          <div class="d-flex align-items-center justify-content-between pb-3 border-bottom border-slate-800 mb-3">
            <div class="d-flex align-items-center gap-2">
              <span class="badge bg-danger rounded-pill p-1 px-2 font-monospace">CANLI</span>
              <h6 class="mb-0 fw-bold">Platform İstatistik Özeti</h6>
            </div>
            <i class="bi bi-bar-chart-fill text-accent"></i>
          </div>

          <div class="row g-3 mb-4">
            <div class="col-6">
              <div class="p-3 rounded-3 bg-slate-800/60 border border-slate-700/60">
                <div class="text-secondary small">Bugünkü Ziyaretçi</div>
                <div class="fs-4 fw-bold font-monospace text-white mt-1"><?php echo number_format($today_visitors); ?></div>
                <div class="small text-success mt-1"><i class="bi bi-arrow-up-right me-1"></i>Tekil: <?php echo number_format($unique_visitors); ?></div>
              </div>
            </div>
            <div class="col-6">
              <div class="p-3 rounded-3 bg-slate-800/60 border border-slate-700/60">
                <div class="text-secondary small">Kayıtlı Öğrenci</div>
                <div class="fs-4 fw-bold font-monospace text-accent mt-1"><?php echo number_format($total_students); ?></div>
                <div class="small text-slate-400 mt-1">Aktif Öğrenme</div>
              </div>
            </div>
          </div>

          <div class="p-3 rounded-3 bg-slate-800/80 border border-slate-700 mb-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <span class="small fw-semibold text-slate-300">Ders Tamamlama Ortalama Başarısı</span>
              <span class="small fw-bold text-accent">%88.4</span>
            </div>
            <div class="progress" style="height: 8px;">
              <div class="progress-bar bg-info progress-bar-striped progress-bar-animated" style="width: 88.4%"></div>
            </div>
          </div>

          <div class="d-grid gap-2">
            <button type="button" class="btn btn-sm btn-outline-info py-2 fw-semibold" data-bs-toggle="modal" data-bs-target="#loginModal">
              <i class="bi bi-key-fill me-1"></i>Öğrenci Girişi Yaparak Sonuçlarını İncele
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 4. AKTİF DERSLER VE MÜFREDATLAR -->
<section id="dersler" class="py-5 bg-white border-bottom">
  <div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3 mb-5">
      <div>
        <span class="badge bg-primary-subtle text-primary fw-bold text-uppercase px-3 py-1.5 rounded-pill mb-2">E-LEARN Kataloğu</span>
        <h2 class="fw-bold mb-1">Aktif Eğitim Dersleri ve Konu Planları</h2>
        <p class="text-muted mb-0">Her ders için zengin içerikli konu anlatımları, interaktif soru havuzları ve vize sınavları.</p>
      </div>
      <a href="/elearn/index.php" class="btn btn-outline-primary fw-semibold px-4 py-2 shrink-0">
        Tüm Dersleri İncele <i class="bi bi-arrow-right ms-1"></i>
      </a>
    </div>

    <div class="row g-4">
      <?php foreach ($courses as $c): ?>
        <div class="col-lg-4 col-md-6">
          <div class="card card-custom h-100 overflow-hidden d-flex flex-column">
            <div class="position-relative" style="height: 180px; overflow: hidden;">
              <img src="<?php echo e($c['image'] ?: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80'); ?>" alt="<?php echo e($c['title']); ?>" class="w-100 h-100 object-fit-cover transition-transform">
              <span class="position-absolute top-0 end-0 m-3 badge bg-navy text-white px-3 py-1.5 rounded-pill shadow-sm">
                <?php echo e($c['category']); ?>
              </span>
            </div>
            <div class="card-body p-4 d-flex flex-column flex-grow-1">
              <h5 class="card-title fw-bold text-navy mb-2"><?php echo e($c['title']); ?></h5>
              <p class="card-text text-muted small flex-grow-1 mb-4 leading-relaxed">
                <?php echo e($c['description']); ?>
              </p>
              <div class="d-flex align-items-center justify-content-between pt-3 border-top small text-secondary">
                <span><i class="bi bi-collection me-1 text-primary"></i><?php echo (int)$c['topic_count']; ?> Konu</span>
                <span><i class="bi bi-file-earmark-check me-1 text-success"></i><?php echo (int)$c['exam_count']; ?> Vize Sınavı</span>
                <a href="/elearn/course.php?slug=<?php echo e($c['slug']); ?>" class="btn btn-sm btn-accent px-3 py-1.5 fw-semibold">
                  Derse Git
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- 6. SKORBOARD (HER DERSİN EN BAŞARILI 1. ÖĞRENCİSİ) -->
<section id="skorboard" class="py-5 bg-slate-100 border-bottom">
  <div class="container py-4">
    <div class="text-center max-w-2xl mx-auto mb-5">
      <div class="d-inline-flex align-items-center gap-1 text-warning fw-bold text-uppercase small mb-2">
        <i class="bi bi-trophy-fill"></i>
        <span>Resmi Skorboard Sıralaması</span>
      </div>
      <h2 class="fw-extrabold text-navy">Her Dersin Zirvedeki Öğrencileri</h2>
      <p class="text-muted small">
        Öğrenci gizliliği ve KVKK ilkeleri gereği soyadları yalnızca ilk harfi ile listelenir. Sıralama toplam sınav puanı ve başarı yüzdesine göredir.
      </p>
    </div>

    <div class="row g-4 justify-content-center">
      <?php if (!empty($scoreboard)): ?>
        <?php foreach ($scoreboard as $idx => $item): ?>
          <div class="col-lg-4 col-md-6">
            <div class="card card-custom p-4 h-100 border-top border-4 border-info">
              <div class="d-flex align-items-center justify-content-between mb-3">
                <span class="badge bg-warning text-dark font-monospace fw-bold px-2.5 py-1">
                  <i class="bi bi-award-fill me-1"></i>1. SIRA
                </span>
                <span class="text-muted small font-monospace"><?php echo (int)$item['exam_count']; ?> Sınav Girişimi</span>
              </div>
              <h5 class="fw-bold text-navy mb-1"><?php echo e($item['course_title']); ?></h5>
              <div class="my-3 p-3 rounded-3 bg-light border d-flex align-items-center justify-content-between">
                <div>
                  <div class="text-muted small">Öğrenci Adı</div>
                  <div class="fw-bold text-dark fs-5">
                    <?php echo e(mask_student_name($item['first_name'], $item['last_name'])); ?>
                  </div>
                </div>
                <div class="text-end">
                  <div class="text-muted small">Toplam Skor</div>
                  <div class="fw-extrabold font-monospace text-primary fs-4">
                    <?php echo number_format($item['total_score']); ?> <span class="fs-6 fw-normal text-muted">Puan</span>
                  </div>
                </div>
              </div>
              <div class="d-flex align-items-center justify-content-between small text-secondary pt-2">
                <span>Başarı Yüzdesi:</span>
                <strong class="text-success font-monospace">%<?php echo number_format((float)$item['success_rate'], 1); ?></strong>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="col-12 text-center py-4 text-muted">
          Henüz tamamlanmış bir sınav veya skorboard verisi bulunmamaktadır.
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- 8. AKADEMİK VE DANIŞMAN EKİBİMİZ -->
<section id="ekip" class="py-5 bg-white border-bottom">
  <div class="container py-4">
    <div class="text-center max-w-2xl mx-auto mb-5">
      <span class="badge bg-secondary-subtle text-secondary fw-bold text-uppercase px-3 py-1 rounded-pill mb-2">Akademik Kadro</span>
      <h2 class="fw-bold text-navy">Eğitim Psikolojisi ve Alan Danışmanlarımız</h2>
      <p class="text-muted small">
        Sınav stratejileri, müfredat intibakı ve ders koçluğu yürüten yetkili kadromuz.
      </p>
    </div>

    <div class="row g-4">
      <?php foreach ($team_members as $member): ?>
        <div class="col-lg-4 col-md-6">
          <div class="card card-custom p-4 h-100 d-flex flex-column">
            <div class="d-flex align-items-center gap-3 mb-3">
              <img src="<?php echo e($member['photo_url'] ?: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'); ?>" alt="<?php echo e($member['full_name']); ?>" class="rounded-circle object-fit-cover border border-2 border-info shadow-xs" style="width: 64px; height: 64px;">
              <div>
                <h6 class="fw-bold mb-0 text-navy"><?php echo e($member['full_name']); ?></h6>
                <div class="text-accent small fw-semibold"><?php echo e($member['role_title']); ?></div>
                <div class="text-muted" style="font-size: 0.75rem;"><?php echo e($member['degree_info']); ?></div>
              </div>
            </div>
            <p class="text-muted small flex-grow-1 leading-relaxed mb-3">
              <?php echo e($member['bio']); ?>
            </p>
            <div class="pt-2 border-top small text-secondary">
              <strong>Uzmanlık:</strong> <?php echo e($member['specialties']); ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- 9. İLETİŞİM VE DANIŞMA -->
<section class="py-5 bg-slate-100">
  <div class="container py-4">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6">
        <span class="badge bg-info-subtle text-info fw-bold text-uppercase px-3 py-1.5 rounded-pill mb-2">Canlı Danışman Hattı</span>
        <h2 class="fw-bold text-navy mb-3">Sorularınız veya Kayıt Desteği İçin İletişime Geçin</h2>
        <p class="text-muted mb-4 leading-relaxed">
          Eğitim koçlarımız öğrenci affı, ders intibakı, vize sınavları ve müfredat planlaması hakkında haftanın her günü danışmanlık sağlamaktadır.
        </p>

        <div class="card card-custom p-4 mb-3">
          <div class="d-flex align-items-center gap-3">
            <div class="w-12 h-12 rounded-3 bg-success-subtle text-success d-flex align-items-center justify-content-center fs-4" style="width: 48px; height: 48px;">
              <i class="bi bi-telephone-outbound-fill"></i>
            </div>
            <div>
              <div class="text-muted small">Doğrudan İletişim Hattı</div>
              <a href="tel:<?php echo preg_replace('/\s+/', '', e($contact['phone'])); ?>" class="fs-4 fw-bold text-dark text-decoration-none">
                <?php echo e($contact['phone']); ?>
              </a>
            </div>
          </div>
        </div>

        <div class="card card-custom p-4">
          <div class="d-flex align-items-center gap-3">
            <div class="w-12 h-12 rounded-3 bg-primary-subtle text-primary d-flex align-items-center justify-content-center fs-4" style="width: 48px; height: 48px;">
              <i class="bi bi-geo-alt-fill"></i>
            </div>
            <div>
              <div class="text-muted small">Akademik Koordinasyon Merkezi</div>
              <div class="fw-semibold text-dark"><?php echo e($contact['address']); ?></div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card card-custom p-4 p-md-5 border-0 shadow-lg">
          <h4 class="fw-bold text-navy mb-2">Hızlı Bilgi Talep Formu</h4>
          <p class="text-muted small mb-4">Formu doldurun, danışmanlarımız 15 dakika içinde geri dönüş yapsın.</p>
          <form onsubmit="alert('Talebiniz başarıyla alınmıştır. Eğitim danışmanımız en kısa sürede sizinle iletişime geçecektir.'); return false;">
            <div class="mb-3">
              <label class="form-label small fw-semibold">Adınız Soyadınız</label>
              <input type="text" class="form-control" placeholder="Adınız Soyadınız" required>
            </div>
            <div class="row g-2 mb-3">
              <div class="col-6">
                <label class="form-label small fw-semibold">Telefon Numaranız</label>
                <input type="tel" class="form-control" placeholder="0 5xx xxx xx xx" required>
              </div>
              <div class="col-6">
                <label class="form-label small fw-semibold">E-Posta</label>
                <input type="email" class="form-control" placeholder="E-Posta Adresi" required>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label small fw-semibold">İlgilendiğiniz Bölüm / Konu</label>
              <select class="form-select">
                <option>Bilgisayar Teknolojileri ve Programlama</option>
                <option>İşletme ve Yönetim Organizasyon</option>
                <option>Grafik Tasarım ve Görsel İletişim</option>
                <option>Web Geliştirme ve Veritabanı Sistemleri</option>
                <option>YÖK Öğrenci Affı İntibak Danışmanlığı</option>
              </select>
            </div>
            <button type="submit" class="btn btn-accent w-100 py-2.5 fw-bold">
              <i class="bi bi-send-fill me-1"></i>Danışmana Gönder
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
