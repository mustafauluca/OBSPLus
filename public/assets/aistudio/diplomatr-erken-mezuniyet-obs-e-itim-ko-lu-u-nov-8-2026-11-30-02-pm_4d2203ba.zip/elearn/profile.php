<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/profile.php - Öğrenci Profili, Sınav Geçmişi, Sertifikalar ve Tercihler
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

// Çıkış İşlemi
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    student_logout();
    header("Location: /index.php?msg=logged_out");
    exit;
}

$current_student = get_current_student();
if (!$current_student) {
    header("Location: /elearn/index.php?msg=login_required");
    exit;
}

$success_msg = '';
$error_msg = '';

// Profil Güncelleme ve Skorboard Tercihi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $first_name = clean_input($_POST['first_name'] ?? '');
        $last_name = clean_input($_POST['last_name'] ?? '');
        $phone = clean_input($_POST['phone'] ?? '');
        $show_sb = !empty($_POST['show_on_scoreboard']) ? 1 : 0;

        if (!empty($first_name) && !empty($last_name)) {
            db_execute(
                "UPDATE students SET first_name = ?, last_name = ?, phone = ?, show_on_scoreboard = ? WHERE id = ?",
                "sssii",
                [$first_name, $last_name, $phone, $show_sb, $current_student['id']]
            );
            $current_student = get_current_student();
            $success_msg = 'Profil bilgileriniz başarıyla güncellendi.';
        } else {
            $error_msg = 'Ad ve soyad alanları boş bırakılamaz.';
        }
    }
}

// Öğrencinin Sınav Geçmişi
$attempts = db_fetch_all(
    "SELECT ea.*, 
            e.title as exam_title, 
            t.title as test_title,
            COALESCE(e.course_id, t.course_id) as course_id
     FROM exam_attempts ea
     LEFT JOIN exams e ON ea.exam_id = e.id
     LEFT JOIN tests t ON ea.test_id = t.id
     WHERE ea.student_id = ? 
     ORDER BY ea.id DESC",
    "i",
    [$current_student['id']]
) ?: [];

// Tamamlanan Konular
$completed_topics_count = db_fetch_one("SELECT COUNT(*) as c FROM student_progress WHERE student_id = ? AND is_completed = 1", "i", [$current_student['id']])['c'] ?? 0;

// Genel Puan ve Ortalama
$score_summary = db_fetch_one(
    "SELECT SUM(total_score) as sum_score, AVG(success_rate) as avg_rate, COUNT(*) as active_courses
     FROM student_scores WHERE student_id = ?",
    "i",
    [$current_student['id']]
);
$total_points = (int)($score_summary['sum_score'] ?? 0);
$avg_success = round((float)($score_summary['avg_rate'] ?? 0), 1);

$page_title = 'Öğrenci Profilim & Başarı Raporum';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-navy text-white py-4 py-md-5 border-bottom border-slate-800">
  <div class="container">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
      <div class="d-flex align-items-center gap-3">
        <div class="w-16 h-16 rounded-circle bg-accent text-white d-flex align-items-center justify-content-center fs-2 fw-bold border border-2 border-info shadow-sm" style="width: 64px; height: 64px;">
          <?php echo mb_substr($current_student['first_name'], 0, 1) . mb_substr($current_student['last_name'], 0, 1); ?>
        </div>
        <div>
          <span class="badge bg-info text-dark font-monospace fw-bold px-2.5 py-0.5 rounded-pill mb-1">
            Öğrenci No: <?php echo e($current_student['student_number']); ?>
          </span>
          <h1 class="h3 fw-bold text-white mb-0"><?php echo e($current_student['first_name'] . ' ' . $current_student['last_name']); ?></h1>
          <div class="text-slate-400 small mt-0.5"><?php echo e($current_student['email']); ?></div>
        </div>
      </div>

      <div class="d-flex gap-2">
        <a href="/elearn/index.php" class="btn btn-sm btn-outline-light">
          <i class="bi bi-book me-1"></i>Derslere Git
        </a>
        <a href="/elearn/profile.php?action=logout" class="btn btn-sm btn-danger px-3">
          <i class="bi bi-box-arrow-right me-1"></i>Oturumu Kapat
        </a>
      </div>
    </div>
  </div>
</div>

<div class="container py-5">
  <?php if ($success_msg): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="bi bi-check-circle-fill me-2"></i><?php echo e($success_msg); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <?php if ($error_msg): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo e($error_msg); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <!-- 4 İstatistik Kartı -->
  <div class="row g-3 mb-5">
    <div class="col-6 col-lg-3">
      <div class="card card-custom p-3 border-start border-4 border-primary">
        <div class="text-muted small">Toplam Skorboard Puanı</div>
        <div class="fs-2 fw-extrabold font-monospace text-primary mt-1"><?php echo number_format($total_points); ?></div>
        <div class="small text-muted">Kazanılan Puan</div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card card-custom p-3 border-start border-4 border-success">
        <div class="text-muted small">Genel Başarı Yüzdesi</div>
        <div class="fs-2 fw-extrabold font-monospace text-success mt-1">%<?php echo $avg_success; ?></div>
        <div class="small text-muted">Tüm Sınavlar Ortalaması</div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card card-custom p-3 border-start border-4 border-info">
        <div class="text-muted small">Tamamlanan Konu</div>
        <div class="fs-2 fw-extrabold font-monospace text-info mt-1"><?php echo $completed_topics_count; ?></div>
        <div class="small text-muted">Okunan Konu Anlatımı</div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card card-custom p-3 border-start border-4 border-warning">
        <div class="text-muted small">Toplam Sınav Girişimi</div>
        <div class="fs-2 fw-extrabold font-monospace text-dark mt-1"><?php echo count($attempts); ?></div>
        <div class="small text-muted">Test & Vize Sınavı</div>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <!-- Sol Kolon: Sınav Geçmişi ve Sonuçlar -->
    <div class="col-lg-8">
      <div class="card card-custom p-4 mb-4">
        <div class="d-flex align-items-center justify-content-between mb-4 pb-2 border-bottom">
          <h5 class="fw-bold text-navy mb-0">
            <i class="bi bi-clock-history me-2 text-primary"></i>Sınav ve Test Geçmişim
          </h5>
          <span class="badge bg-secondary-subtle text-secondary"><?php echo count($attempts); ?> Kayıt</span>
        </div>

        <?php if (!empty($attempts)): ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle small mb-0">
              <thead class="table-light">
                <tr>
                  <th>Sınav / Test Adı</th>
                  <th class="text-center">Tür</th>
                  <th class="text-center">Tarih</th>
                  <th class="text-center">Puan</th>
                  <th class="text-center">Durum</th>
                  <th class="text-end">Rapor</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($attempts as $att): ?>
                  <tr>
                    <td>
                      <div class="fw-bold text-dark">
                        <?php echo e($att['exam_title'] ?: ($att['test_title'] ?: 'Sınav Girişimi')); ?>
                      </div>
                      <div class="text-muted" style="font-size: 0.75rem;">
                        <?php echo (int)$att['correct_count']; ?> Doğru, <?php echo (int)$att['wrong_count']; ?> Yanlış, <?php echo (int)$att['empty_count']; ?> Boş
                      </div>
                    </td>
                    <td class="text-center">
                      <span class="badge <?php echo ($att['type'] === 'exam') ? 'bg-warning text-dark' : 'bg-info text-dark'; ?> font-monospace">
                        <?php echo ($att['type'] === 'exam') ? 'VİZE' : 'TEST'; ?>
                      </span>
                    </td>
                    <td class="text-center font-monospace text-muted">
                      <?php echo date('d.m.Y H:i', strtotime($att['start_time'])); ?>
                    </td>
                    <td class="text-center font-monospace fw-bold">
                      <?php echo ($att['status'] === 'completed') ? '%' . number_format((float)$att['score'], 1) : '-'; ?>
                    </td>
                    <td class="text-center">
                      <?php if ($att['status'] === 'completed'): ?>
                        <span class="badge <?php echo $att['is_passed'] ? 'bg-success' : 'bg-danger'; ?>">
                          <?php echo $att['is_passed'] ? 'GEÇTİ' : 'KALDI'; ?>
                        </span>
                      <?php else: ?>
                        <span class="badge bg-secondary">Devam Ediyor</span>
                      <?php endif; ?>
                    </td>
                    <td class="text-end">
                      <?php if ($att['status'] === 'completed'): ?>
                        <a href="/elearn/result.php?attempt_id=<?php echo $att['id']; ?>" class="btn btn-sm btn-outline-primary py-1 px-2.5">
                          <i class="bi bi-eye me-1"></i>İncele
                        </a>
                      <?php else: ?>
                        <a href="<?php echo ($att['type'] === 'exam') ? '/elearn/exam.php?exam_id=' . $att['exam_id'] : '/elearn/test.php?test_id=' . $att['test_id']; ?>" class="btn btn-sm btn-warning py-1 px-2.5">
                          Devam Et
                        </a>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="text-center py-4 text-muted">
            <i class="bi bi-journal-x fs-1 d-block mb-2 text-secondary"></i>
            Henüz tamamlanmış bir sınav veya testiniz bulunmuyor.
            <div class="mt-3">
              <a href="/elearn/index.php" class="btn btn-sm btn-accent fw-bold px-4">Derslere Git ve Sınava Katıl</a>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Sağ Kolon: Profil Ayarları ve Tercihler -->
    <div class="col-lg-4">
      <div class="card card-custom p-4 mb-4">
        <h5 class="fw-bold text-navy mb-3 pb-2 border-bottom">
          <i class="bi bi-person-gear me-2 text-primary"></i>Kişisel Bilgiler & Ayarlar
        </h5>

        <form method="POST" action="">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="action" value="update_profile">

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">Öğrenci Numarası</label>
            <input type="text" class="form-control bg-light font-monospace" value="<?php echo e($current_student['student_number']); ?>" readonly>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold text-muted">E-Posta Adresi</label>
            <input type="email" class="form-control bg-light" value="<?php echo e($current_student['email']); ?>" readonly>
          </div>

          <div class="row g-2 mb-3">
            <div class="col-6">
              <label class="form-label small fw-semibold">Ad</label>
              <input type="text" name="first_name" class="form-control" value="<?php echo e($current_student['first_name']); ?>" required>
            </div>
            <div class="col-6">
              <label class="form-label small fw-semibold">Soyad</label>
              <input type="text" name="last_name" class="form-control" value="<?php echo e($current_student['last_name']); ?>" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Telefon Numarası</label>
            <input type="tel" name="phone" class="form-control" value="<?php echo e($current_student['phone']); ?>">
          </div>

          <div class="form-check p-3 rounded bg-light border mb-4">
            <input class="form-check-input" type="checkbox" name="show_on_scoreboard" id="showScoreboardCheck" <?php echo !empty($current_student['show_on_scoreboard']) ? 'checked' : ''; ?>>
            <label class="form-check-label small fw-semibold" for="showScoreboardCheck">
              Başarımı Ana Sayfa Skorboard'da Göster
            </label>
            <div class="text-muted" style="font-size: 0.75rem; margin-top: 4px;">
              İşaretlendiğinde adınız ve maskelenmiş soyadınız (Örn: <?php echo mask_student_name($current_student['first_name'], $current_student['last_name']); ?>) skorboard sıralamasında görünür.
            </div>
          </div>

          <button type="submit" class="btn btn-primary w-100 fw-bold">
            <i class="bi bi-save me-1"></i>Bilgileri Güncelle
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
