<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/topic.php - Konu Anlatım İçeriği, Video, Materyaller ve Tamamlama Takibi
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

$slug = clean_input($_GET['slug'] ?? '');
$topic = db_fetch_one("SELECT * FROM course_topics WHERE slug = ? AND is_active = 1", "s", [$slug]);

if (!$topic) {
    header("Location: /elearn/index.php");
    exit;
}

$course = db_fetch_one("SELECT * FROM courses WHERE id = ?", "i", [$topic['course_id']]);
$content = db_fetch_one("SELECT * FROM topic_contents WHERE topic_id = ?", "i", [$topic['id']]);
$materials = db_fetch_all("SELECT * FROM course_materials WHERE topic_id = ?", "i", [$topic['id']]) ?: [];
$test = db_fetch_one("SELECT * FROM tests WHERE topic_id = ? AND is_active = 1 LIMIT 1", "i", [$topic['id']]);

$current_student = get_current_student();
$is_completed = $current_student ? is_topic_completed($current_student['id'], $topic['id']) : false;

// Konuyu Tamamlandı Olarak İşaretleme İsteği (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_complete') {
    if ($current_student && verify_csrf_token($_POST['csrf_token'] ?? '')) {
        mark_topic_completed($current_student['id'], $course['id'], $topic['id']);
        $is_completed = true;
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit;
        }
    }
}

// Önceki ve Sonraki Konu
$prev_topic = db_fetch_one(
    "SELECT * FROM course_topics WHERE course_id = ? AND sort_order < ? AND is_active = 1 ORDER BY sort_order DESC LIMIT 1",
    "ii",
    [$course['id'], $topic['sort_order']]
);
$next_topic = db_fetch_one(
    "SELECT * FROM course_topics WHERE course_id = ? AND sort_order > ? AND is_active = 1 ORDER BY sort_order ASC LIMIT 1",
    "ii",
    [$course['id'], $topic['sort_order']]
);

$page_title = $topic['title'] . ' - ' . ($course['title'] ?? '');
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Topic Top Banner -->
<div class="bg-navy text-white py-4 border-bottom border-slate-800">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb small text-slate-400 mb-2">
        <li class="breadcrumb-item"><a href="/index.php" class="text-accent text-decoration-none">Ana Sayfa</a></li>
        <li class="breadcrumb-item"><a href="/elearn/index.php" class="text-accent text-decoration-none">Dersler</a></li>
        <li class="breadcrumb-item"><a href="/elearn/course.php?slug=<?php echo e($course['slug']); ?>" class="text-accent text-decoration-none"><?php echo e($course['title']); ?></a></li>
        <li class="breadcrumb-item active text-slate-300" aria-current="page"><?php echo e($topic['title']); ?></li>
      </ol>
    </nav>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
      <div>
        <h1 class="h3 fw-bold text-white mb-1"><?php echo e($topic['title']); ?></h1>
        <p class="text-slate-300 small mb-0"><?php echo e($topic['short_description']); ?></p>
      </div>
      
      <div class="d-flex align-items-center gap-2">
        <?php if ($test): ?>
          <a href="/elearn/test.php?topic_id=<?php echo $topic['id']; ?>" class="btn btn-sm btn-outline-info fw-semibold px-3">
            <i class="bi bi-ui-checks me-1"></i>Konu Testini Çöz
          </a>
        <?php endif; ?>

        <?php if ($current_student): ?>
          <?php if ($is_completed): ?>
            <span class="badge bg-success-subtle text-success p-2 px-3 fw-bold border border-success-subtle">
              <i class="bi bi-check2-circle me-1"></i>Tamamlandı
            </span>
          <?php else: ?>
            <form method="POST" action="">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="action" value="mark_complete">
              <button type="submit" class="btn btn-sm btn-success fw-bold px-3">
                <i class="bi bi-check-lg me-1"></i>Tamamlandı Olarak İşaretle
              </button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="container py-5">
  <div class="row g-4">
    <!-- Ana Konu Anlatım Alanı -->
    <div class="col-lg-8">
      <div class="card card-custom p-4 p-md-5 mb-4">
        <!-- Video Anlatım (Varsa) -->
        <?php if (!empty($content['video_url'])): ?>
          <div class="mb-4 rounded-4 overflow-hidden shadow-xs border bg-dark">
            <?php
              $v_url = $content['video_url'];
              $yt_id = '';
              if (preg_match('/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/', $v_url, $matches)) {
                  $yt_id = $matches[1];
              }
            ?>
            <?php if ($yt_id): ?>
              <div class="ratio ratio-16x9">
                <iframe src="https://www.youtube.com/embed/<?php echo $yt_id; ?>?rel=0" title="Ders Video Anlatımı" allowfullscreen></iframe>
              </div>
            <?php else: ?>
              <div class="p-3 text-center">
                <a href="<?php echo e($v_url); ?>" target="_blank" class="btn btn-outline-light btn-sm">
                  <i class="bi bi-play-circle me-1"></i>Ders Videosunu Yeni Sekmede İzle
                </a>
              </div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <!-- Zengin Metin Ders Gövdesi -->
        <article class="topic-content-body leading-relaxed text-secondary mb-4" style="font-size: 1.05rem; line-height: 1.8;">
          <?php if (!empty($content['body_html'])): ?>
            <?php echo $content['body_html']; ?>
          <?php else: ?>
            <p class="text-muted">Bu konu için henüz ayrıntılı metin içeriği girilmemiştir.</p>
          <?php endif; ?>
        </article>

        <!-- Özet / Notlar -->
        <?php if (!empty($content['summary'])): ?>
          <div class="p-3 rounded-3 bg-light border-start border-4 border-info mb-4">
            <h6 class="fw-bold text-navy mb-1"><i class="bi bi-lightbulb me-1 text-warning"></i>Konu Özeti & Önemli Notlar:</h6>
            <p class="small text-muted mb-0 leading-relaxed"><?php echo e($content['summary']); ?></p>
          </div>
        <?php endif; ?>

        <!-- Alt Gezinme Butonları (Önceki / Sonraki) -->
        <div class="d-flex align-items-center justify-content-between pt-4 border-top mt-4">
          <?php if ($prev_topic): ?>
            <a href="/elearn/topic.php?slug=<?php echo e($prev_topic['slug']); ?>" class="btn btn-outline-secondary btn-sm">
              <i class="bi bi-arrow-left me-1"></i>Önceki Konu
            </a>
          <?php else: ?>
            <div></div>
          <?php endif; ?>

          <?php if ($next_topic): ?>
            <a href="/elearn/topic.php?slug=<?php echo e($next_topic['slug']); ?>" class="btn btn-primary btn-sm fw-semibold">
              Sonraki Konu <i class="bi bi-arrow-right ms-1"></i>
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Sağ Kolon: Materyaller ve Ders İntibakı -->
    <div class="col-lg-4">
      <!-- Konu Materyalleri (PDF, vb.) -->
      <div class="card card-custom p-4 mb-4">
        <h6 class="fw-bold text-navy mb-3">
          <i class="bi bi-file-earmark-pdf me-1 text-danger"></i>Ders Materyalleri
        </h6>
        <?php if (!empty($materials)): ?>
          <div class="list-group list-group-flush border rounded-3 overflow-hidden">
            <?php foreach ($materials as $m): ?>
              <a href="<?php echo e($m['file_path']); ?>" target="_blank" class="list-group-item list-group-item-action d-flex align-items-center justify-content-between p-2.5 small">
                <div class="d-flex align-items-center gap-2">
                  <i class="bi bi-file-earmark-text text-primary"></i>
                  <span class="text-truncate" style="max-width: 180px;"><?php echo e($m['title']); ?></span>
                </div>
                <span class="badge bg-secondary-subtle text-secondary font-monospace"><?php echo strtoupper($m['file_type']); ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="text-muted small mb-0">Bu konuya ait indirilebilir ek materyal bulunmuyor.</p>
        <?php endif; ?>
      </div>

      <!-- Test Kartı -->
      <?php if ($test): ?>
        <div class="card card-custom p-4 bg-primary-subtle/30 border-primary-subtle">
          <div class="d-flex align-items-center gap-2 mb-2">
            <i class="bi bi-patch-question-fill text-primary fs-5"></i>
            <h6 class="fw-bold text-navy mb-0">Konu Değerlendirme Testi</h6>
          </div>
          <p class="text-muted small mb-3">
            Öğrendiklerinizi pekiştirmek ve skorboard puanınızı artırmak için konu testini çözün.
          </p>
          <a href="/elearn/test.php?topic_id=<?php echo $topic['id']; ?>" class="btn btn-sm btn-primary fw-bold w-100">
            <i class="bi bi-play-circle me-1"></i>Teste Başla (<?php echo (int)$test['duration_minutes']; ?> Dk)
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
