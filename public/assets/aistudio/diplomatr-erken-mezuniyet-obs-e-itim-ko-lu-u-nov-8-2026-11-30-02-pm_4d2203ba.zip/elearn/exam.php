<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/exam.php - Resmi Dönem Sonu Vize Sınavı
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

$exam_id = (int)($_GET['exam_id'] ?? 0);
$exam = db_fetch_one("SELECT * FROM exams WHERE id = ? AND is_active = 1", "i", [$exam_id]);

if (!$exam) {
    header("Location: /elearn/index.php");
    exit;
}

$current_student = get_current_student();
if (!$current_student) {
    header("Location: /elearn/index.php?msg=login_required");
    exit;
}

$course = db_fetch_one("SELECT * FROM courses WHERE id = ?", "i", [$exam['course_id']]);

// Devam eden veya yeni girişim başlat
$attempt_id = start_exam_attempt($current_student['id'], $exam['id'], 'exam');
$attempt = db_fetch_one("SELECT * FROM exam_attempts WHERE id = ?", "i", [$attempt_id]);

// Eğer bu girişim zaten tamamlanmışsa doğrudan sonuç sayfasına yönlendir (Çift gönderim engeli)
if ($attempt && $attempt['status'] === 'completed') {
    header("Location: /elearn/result.php?attempt_id=" . $attempt_id);
    exit;
}

// Sınav Gönderimi (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_exam') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $answers = $_POST['answers'] ?? [];
        if (is_array($answers)) {
            foreach ($answers as $q_id => $opt_id) {
                save_attempt_answer($attempt_id, (int)$q_id, (int)$opt_id);
            }
        }
        $finished = finish_exam_attempt($attempt_id);
        header("Location: /elearn/result.php?attempt_id=" . $attempt_id);
        exit;
    }
}

// Ara Kayıt AJAX İstekleri (Cevap seçildikçe anlık sunucuda sakla)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_single_answer') {
    header('Content-Type: application/json');
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $q_id = (int)($_POST['question_id'] ?? 0);
        $opt_id = (int)($_POST['option_id'] ?? 0);
        save_attempt_answer($attempt_id, $q_id, $opt_id);
        echo json_encode(['success' => true]);
        exit;
    }
    echo json_encode(['success' => false]);
    exit;
}

// Soruları ve daha önce seçilmiş cevapları getir
$questions = get_exam_questions_with_options($exam['id']);
$total_questions = count($questions);

$saved_answers_raw = db_fetch_all("SELECT question_id, selected_option_id FROM exam_answers WHERE attempt_id = ?", "i", [$attempt_id]) ?: [];
$saved_answers = [];
foreach ($saved_answers_raw as $sa) {
    $saved_answers[$sa['question_id']] = (int)$sa['selected_option_id'];
}

// Kalan süre hesabı
$duration_seconds = ((int)$exam['duration_minutes'] ?: 30) * 60;
$elapsed_seconds = time() - strtotime($attempt['start_time']);
$remaining_seconds = max(0, $duration_seconds - $elapsed_seconds);

$page_title = $exam['title'] . ' - Vize Sınavı';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-navy text-white py-3 border-bottom border-slate-800 sticky-top" style="top: 56px; z-index: 30;">
  <div class="container d-flex flex-wrap align-items-center justify-content-between gap-2">
    <div>
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-warning text-dark fw-bold font-monospace">VİZE SINAVI</span>
        <h6 class="fw-bold mb-0 text-white"><?php echo e($exam['title']); ?></h6>
      </div>
      <span class="text-secondary small font-monospace"><?php echo e($course['title'] ?? ''); ?> • <?php echo $total_questions; ?> Soru • Geçme Notu: %<?php echo (int)$exam['pass_score']; ?></span>
    </div>

    <!-- Canlı Geri Sayım Sayacı -->
    <div class="d-flex align-items-center gap-3">
      <div class="d-flex align-items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-pill border border-slate-700">
        <i class="bi bi-clock-history text-warning"></i>
        <span class="small text-secondary">Kalan Süre:</span>
        <span id="examTimer" class="fw-bold font-monospace text-warning fs-6">--:--</span>
      </div>
    </div>
  </div>
</div>

<div class="container py-4">
  <form id="examForm" method="POST" action="">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" value="submit_exam">

    <div class="row g-4 justify-content-center">
      <div class="col-lg-9 space-y-4">
        <!-- Bilgilendirme Notu -->
        <div class="alert alert-info bg-primary-subtle border-primary-subtle text-navy d-flex align-items-center gap-2 small">
          <i class="bi bi-shield-check fs-5"></i>
          <span>Sayfayı yenileseniz dahi cevaplarınız ve sınav süreniz sunucu tarafında korunmaktadır. Sınav bittiğinde "Sınavı Tamamla" butonuna tıklayınız.</span>
        </div>

        <?php foreach ($questions as $q_idx => $q): ?>
          <?php 
            $chosen_opt = $saved_answers[$q['id']] ?? null;
          ?>
          <div class="card card-custom p-4 p-md-5 mb-4 shadow-sm border-start border-4 border-warning">
            <div class="d-flex align-items-center justify-content-between pb-3 border-bottom mb-3">
              <span class="badge bg-navy px-3 py-1.5 font-monospace fw-bold">Soru <?php echo $q_idx + 1; ?> / <?php echo $total_questions; ?></span>
              <span class="text-muted small font-monospace"><?php echo (int)$q['points']; ?> Puan</span>
            </div>

            <h5 class="fw-semibold text-navy mb-4 leading-snug">
              <?php echo e($q['question_text']); ?>
            </h5>

            <!-- Seçenekler -->
            <div class="space-y-3">
              <?php foreach ($q['options'] as $opt): ?>
                <label class="d-flex align-items-start gap-3 p-3 rounded-3 border bg-light hover-bg-white cursor-pointer transition-all mb-2">
                  <input type="radio" 
                         name="answers[<?php echo $q['id']; ?>]" 
                         value="<?php echo $opt['id']; ?>" 
                         data-qid="<?php echo $q['id']; ?>"
                         class="form-check-input mt-1 opt-selector"
                         <?php echo ($chosen_opt === (int)$opt['id']) ? 'checked' : ''; ?>>
                  <span class="badge bg-secondary-subtle text-secondary font-monospace px-2 py-1"><?php echo $opt['option_letter']; ?></span>
                  <span class="text-dark fw-medium small flex-grow-1 leading-relaxed"><?php echo e($opt['option_text']); ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>

        <div class="card card-custom p-4 bg-light text-center border">
          <h5 class="fw-bold text-navy mb-2">Sınavı Tamamlamak Üzeresiniz</h5>
          <p class="text-muted small mb-3">Sınavı gönderdikten sonra cevaplarınız kilitlenecek ve detaylı karne raporu oluşturulacaktır.</p>
          <button type="submit" class="btn btn-warning btn-lg px-5 py-3 fw-bold text-dark shadow-md" onclick="return confirm('Sınavı bitirip sonuçlarınızı onaylamak istiyor musunuz?');">
            <i class="bi bi-check2-circle me-2"></i>Sınavı Tamamla ve Sonuçları Gönder
          </button>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
  // Sunucu tabanlı kalan süre geri sayımı
  var remainingSeconds = <?php echo (int)$remaining_seconds; ?>;
  var timerEl = document.getElementById('examTimer');

  function updateTimer() {
    if (remainingSeconds <= 0) {
      clearInterval(timerInterval);
      alert('Sınav süreniz doldu! Cevaplarınız otomatik olarak gönderiliyor.');
      document.getElementById('examForm').submit();
      return;
    }

    var mins = Math.floor(remainingSeconds / 60);
    var secs = remainingSeconds % 60;
    timerEl.textContent = (mins < 10 ? '0' : '') + mins + ':' + (secs < 10 ? '0' : '') + secs;
    remainingSeconds--;
  }

  updateTimer();
  var timerInterval = setInterval(updateTimer, 1000);

  // Seçenek değiştikçe anlık AJAX ile sunucuda sakla
  $(document).ready(function() {
    $('.opt-selector').on('change', function() {
      var qId = $(this).data('qid');
      var optId = $(this).val();
      $.ajax({
        url: '/elearn/exam.php?exam_id=<?php echo $exam_id; ?>',
        type: 'POST',
        data: {
          action: 'save_single_answer',
          csrf_token: '<?php echo generate_csrf_token(); ?>',
          question_id: qId,
          option_id: optId
        }
      });
    });
  });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
