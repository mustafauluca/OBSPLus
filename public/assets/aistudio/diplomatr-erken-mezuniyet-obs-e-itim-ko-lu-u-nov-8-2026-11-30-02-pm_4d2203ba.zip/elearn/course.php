<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/course.php - Tekil Ders Detayı, Konu Ağacı, Testler ve Vize Sınavları
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

$slug = clean_input($_GET['slug'] ?? '');
$course = get_course_by_slug($slug);

if (!$course) {
    header("Location: /elearn/index.php");
    exit;
}

$current_student = get_current_student();
$topics = get_course_topics($course['id']);
$exams = db_fetch_all("SELECT * FROM exams WHERE course_id = ? AND is_active = 1 ORDER BY id ASC", "i", [$course['id']]) ?: [];

// Öğrencinin ilerleme durumu
$total_topics = count($topics);
$completed_topics = 0;
if ($current_student) {
    foreach ($topics as $t) {
        if (is_topic_completed($current_student['id'], $t['id'])) {
            $completed_topics++;
        }
    }
}
$progress_pct = ($total_topics > 0) ? round(($completed_topics / $total_topics) * 100) : 0;

$page_title = $course['title'];
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Course Header -->
<div class="bg-navy text-white py-4 py-md-5 border-bottom border-slate-800">
  <div class="container">
    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb small text-slate-400 mb-0">
        <li class="breadcrumb-item"><a href="/index.php" class="text-accent text-decoration-none">Ana Sayfa</a></li>
        <li class="breadcrumb-item"><a href="/elearn/index.php" class="text-accent text-decoration-none">Dersler</a></li>
        <li class="breadcrumb-item active text-slate-300" aria-current="page"><?php echo e($course['title']); ?></li>
      </ol>
    </nav>

    <div class="row align-items-center g-4">
      <div class="col-lg-8">
        <span class="badge bg-info text-dark font-monospace fw-bold px-3 py-1 rounded-pill mb-2"><?php echo e($course['category']); ?></span>
        <h1 class="display-6 fw-bold text-white mb-2"><?php echo e($course['title']); ?></h1>
        <p class="text-slate-300 small leading-relaxed mb-4 pe-lg-4">
          <?php echo e($course['description']); ?>
        </p>

        <?php if ($current_student): ?>
          <div class="p-3 rounded-3 bg-slate-800/80 border border-slate-700 max-w-md">
            <div class="d-flex align-items-center justify-content-between mb-1 small">
              <span class="text-slate-300">Ders Tamamlama İlerlemeniz</span>
              <span class="fw-bold text-accent">%<?php echo $progress_pct; ?> (<?php echo $completed_topics; ?> / <?php echo $total_topics; ?> Konu)</span>
            </div>
            <div class="progress" style="height: 6px;">
              <div class="progress-bar bg-info" style="width: <?php echo $progress_pct; ?>%"></div>
            </div>
          </div>
        <?php else: ?>
          <div class="alert alert-dark bg-slate-800 border-slate-700 text-slate-300 py-2 px-3 small d-inline-flex align-items-center gap-2">
            <i class="bi bi-info-circle text-info"></i>
            <span>Konu tamamlama durumunuzu kaydetmek için <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#loginModal" class="text-info fw-bold">giriş yapınız</a>.</span>
          </div>
        <?php endif; ?>
      </div>

      <div class="col-lg-4">
        <div class="card card-custom overflow-hidden border-0 shadow-lg">
          <img src="<?php echo e($course['image'] ?: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80'); ?>" alt="<?php echo e($course['title']); ?>" class="w-100 object-fit-cover" style="height: 200px;">
          <div class="card-body p-3 bg-light">
            <ul class="list-unstyled small mb-0 space-y-1">
              <li class="d-flex justify-content-between py-1 border-bottom">
                <span class="text-muted"><i class="bi bi-layers me-1"></i>Toplam Konu:</span>
                <strong><?php echo $total_topics; ?> Bölüm</strong>
              </li>
              <li class="d-flex justify-content-between py-1 border-bottom">
                <span class="text-muted"><i class="bi bi-award me-1"></i>Vize Sınavı:</span>
                <strong><?php echo count($exams); ?> Adet</strong>
              </li>
              <li class="d-flex justify-content-between py-1">
                <span class="text-muted"><i class="bi bi-patch-check me-1"></i>Sertifika Durumu:</span>
                <span class="badge bg-success-subtle text-success">Geçerli</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container py-5">
  <div class="row g-4">
    <!-- Sol Kolon: Konular Ağacı (Topics) -->
    <div class="col-lg-8">
      <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom">
        <h4 class="fw-bold text-navy mb-0">
          <i class="bi bi-journal-text me-2 text-primary"></i>Ders Konuları ve Anlatımlar
        </h4>
        <span class="badge bg-secondary-subtle text-secondary"><?php echo $total_topics; ?> Konu</span>
      </div>

      <?php if (!empty($topics)): ?>
        <div class="list-group list-group-flush shadow-sm rounded-4 overflow-hidden border">
          <?php foreach ($topics as $index => $t): ?>
            <?php 
              $is_done = $current_student ? is_topic_completed($current_student['id'], $t['id']) : false;
            ?>
            <div class="list-group-item p-3 p-md-4 d-flex align-items-center justify-content-between gap-3 <?php echo $is_done ? 'bg-success-subtle/20' : ''; ?>">
              <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold <?php echo $is_done ? 'bg-success text-white' : 'bg-light text-navy border'; ?>" style="width: 36px; height: 36px; shrink: 0;">
                  <?php if ($is_done): ?>
                    <i class="bi bi-check-lg"></i>
                  <?php else: ?>
                    <?php echo $index + 1; ?>
                  <?php endif; ?>
                </div>
                <div>
                  <h6 class="fw-bold mb-1 text-navy">
                    <a href="/elearn/topic.php?slug=<?php echo e($t['slug']); ?>" class="text-navy text-decoration-none hover-primary">
                      <?php echo e($t['title']); ?>
                    </a>
                  </h6>
                  <p class="text-muted small mb-0">
                    <?php echo e($t['short_description']); ?>
                  </p>
                </div>
              </div>

              <div class="d-flex align-items-center gap-2 shrink-0">
                <?php if ((int)$t['test_count'] > 0): ?>
                  <a href="/elearn/test.php?topic_id=<?php echo $t['id']; ?>" class="btn btn-sm btn-outline-info" title="Konu Değerlendirme Testi">
                    <i class="bi bi-ui-checks"></i> <span class="d-none d-sm-inline">Test</span>
                  </a>
                <?php endif; ?>
                <a href="/elearn/topic.php?slug=<?php echo e($t['slug']); ?>" class="btn btn-sm btn-primary fw-semibold px-3">
                  Çalış <i class="bi bi-arrow-right ms-1"></i>
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="card card-custom p-4 text-center text-muted">
          Bu ders için henüz aktif konu eklenmemiştir.
        </div>
      <?php endif; ?>
    </div>

    <!-- Sağ Kolon: Vize Sınavları ve Testler -->
    <div class="col-lg-4">
      <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom">
        <h4 class="fw-bold text-navy mb-0">
          <i class="bi bi-award me-2 text-warning"></i>Vize Sınavları
        </h4>
        <span class="badge bg-warning text-dark font-monospace"><?php echo count($exams); ?></span>
      </div>

      <?php if (!empty($exams)): ?>
        <div class="space-y-3">
          <?php foreach ($exams as $exam): ?>
            <?php
              // Öğrencinin geçmiş sınav girişimi
              $attempt = $current_student 
                ? db_fetch_one("SELECT * FROM exam_attempts WHERE student_id = ? AND exam_id = ? ORDER BY id DESC LIMIT 1", "ii", [$current_student['id'], $exam['id']])
                : null;
            ?>
            <div class="card card-custom p-3 border-start border-4 border-warning">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="badge bg-dark font-monospace"><?php echo (int)$exam['duration_minutes']; ?> Dk</span>
                <span class="badge bg-primary-subtle text-primary">Baraj: <?php echo (int)$exam['pass_score']; ?> Puan</span>
              </div>
              <h6 class="fw-bold text-navy mb-1"><?php echo e($exam['title']); ?></h6>
              <p class="text-muted small leading-relaxed mb-3">
                <?php echo e($exam['description'] ?: 'Resmi dönem sonu vize sınavıdır.'); ?>
              </p>

              <?php if ($attempt && $attempt['status'] === 'completed'): ?>
                <div class="p-2 rounded bg-light border mb-2 d-flex justify-content-between align-items-center small">
                  <span>Sonuç: <strong>%<?php echo number_format((float)$attempt['score'], 1); ?></strong></span>
                  <span class="badge <?php echo $attempt['is_passed'] ? 'bg-success' : 'bg-danger'; ?>">
                    <?php echo $attempt['is_passed'] ? 'GEÇTİ' : 'KALDI'; ?>
                  </span>
                </div>
                <a href="/elearn/result.php?attempt_id=<?php echo $attempt['id']; ?>" class="btn btn-sm btn-outline-secondary w-100 mb-2">
                  <i class="bi bi-file-earmark-bar-graph me-1"></i>Sınav Raporunu Gör
                </a>
              <?php endif; ?>

              <?php if ($current_student): ?>
                <a href="/elearn/exam.php?exam_id=<?php echo $exam['id']; ?>" class="btn btn-sm btn-warning w-100 fw-bold text-dark">
                  <i class="bi bi-pencil-square me-1"></i><?php echo $attempt ? 'Sınava Yeniden Gir' : 'Sınavı Başlat'; ?>
                </a>
              <?php else: ?>
                <button type="button" class="btn btn-sm btn-outline-warning text-dark w-100 fw-bold" data-bs-toggle="modal" data-bs-target="#loginModal">
                  Sınav İçin Giriş Yap
                </button>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="card card-custom p-3 text-center text-muted small">
          Bu derse ait aktif vize sınavı bulunmamaktadır.
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
