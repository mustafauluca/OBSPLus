<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/test.php - Konu Bazlı Alıştırma ve Değerlendirme Testi
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

$topic_id = (int)($_GET['topic_id'] ?? 0);
$test_id = (int)($_GET['test_id'] ?? 0);

if ($topic_id > 0) {
    $test = db_fetch_one("SELECT * FROM tests WHERE topic_id = ? AND is_active = 1 LIMIT 1", "i", [$topic_id]);
} elseif ($test_id > 0) {
    $test = db_fetch_one("SELECT * FROM tests WHERE id = ? AND is_active = 1", "i", [$test_id]);
} else {
    $test = null;
}

if (!$test) {
    header("Location: /elearn/index.php");
    exit;
}

$current_student = get_current_student();
if (!$current_student) {
    header("Location: /elearn/index.php?msg=login_required");
    exit;
}

// Devam eden veya yeni girişim başlat
$attempt_id = start_exam_attempt($current_student['id'], $test['id'], 'test');
$attempt = db_fetch_one("SELECT * FROM exam_attempts WHERE id = ?", "i", [$attempt_id]);

// Test gönderimi işleme
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_test') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $answers = $_POST['answers'] ?? [];
        if (is_array($answers)) {
            foreach ($answers as $q_id => $opt_id) {
                save_attempt_answer($attempt_id, (int)$q_id, (int)$opt_id);
            }
        }
        $finished = finish_exam_attempt($attempt_id);
        header("Location: /elearn/result.php?attempt_id=" . $attempt_id);
        exit;
    }
}

// Soruları getir
$questions = get_test_questions_with_options($test['id']);
$total_questions = count($questions);

// Kalan süre hesabı
$duration_seconds = ((int)$test['duration_minutes'] ?: 15) * 60;
$elapsed_seconds = time() - strtotime($attempt['start_time']);
$remaining_seconds = max(0, $duration_seconds - $elapsed_seconds);

$page_title = $test['title'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-navy text-white py-3 border-bottom border-slate-800 sticky-top" style="top: 56px; z-index: 30;">
  <div class="container d-flex align-items-center justify-content-between">
    <div>
      <h6 class="fw-bold mb-0 text-white"><?php echo e($test['title']); ?></h6>
      <span class="text-secondary small font-monospace"><?php echo $total_questions; ?> Soru • Baraj: %<?php echo (int)$test['pass_score']; ?></span>
    </div>

    <!-- Canlı Geri Sayım Sayacı -->
    <div class="d-flex align-items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-pill border border-slate-700">
      <i class="bi bi-clock-history text-warning"></i>
      <span class="small text-secondary">Kalan Süre:</span>
      <span id="testTimer" class="fw-bold font-monospace text-warning fs-6">--:--</span>
    </div>
  </div>
</div>

<div class="container py-4">
  <form id="testForm" method="POST" action="">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" value="submit_test">

    <div class="row g-4 justify-content-center">
      <div class="col-lg-9 space-y-4">
        <?php foreach ($questions as $q_idx => $q): ?>
          <div class="card card-custom p-4 p-md-5 mb-4 shadow-sm border-start border-4 border-info">
            <div class="d-flex align-items-center justify-content-between pb-3 border-bottom mb-3">
              <span class="badge bg-primary px-3 py-1.5 font-monospace fw-bold">Soru <?php echo $q_idx + 1; ?> / <?php echo $total_questions; ?></span>
              <span class="text-muted small font-monospace"><?php echo (int)$q['points']; ?> Puan</span>
            </div>

            <h5 class="fw-semibold text-navy mb-4 leading-snug">
              <?php echo e($q['question_text']); ?>
            </h5>

            <!-- Seçenekler (Radyo Butonları) -->
            <div class="space-y-3">
              <?php foreach ($q['options'] as $opt): ?>
                <label class="d-flex align-items-start gap-3 p-3 rounded-3 border bg-light hover-bg-white cursor-pointer transition-all mb-2">
                  <input type="radio" name="answers[<?php echo $q['id']; ?>]" value="<?php echo $opt['id']; ?>" class="form-check-input mt-1">
                  <span class="badge bg-secondary-subtle text-secondary font-monospace px-2 py-1"><?php echo $opt['option_letter']; ?></span>
                  <span class="text-dark fw-medium small flex-grow-1 leading-relaxed"><?php echo e($opt['option_text']); ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endforeach; ?>

        <div class="card card-custom p-4 bg-light text-center border">
          <p class="text-muted small mb-3">Tüm soruları dikkatlice yanıtladığınızdan emin olduktan sonra testi tamamlayınız.</p>
          <button type="submit" class="btn btn-accent btn-lg px-5 py-2.5 fw-bold shadow-md">
            <i class="bi bi-check-circle-fill me-2"></i>Testi Bitir ve Notlandır
          </button>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
  // Sunucu tabanlı kalan süre geri sayımı
  var remainingSeconds = <?php echo (int)$remaining_seconds; ?>;
  var timerEl = document.getElementById('testTimer');

  function updateTimer() {
    if (remainingSeconds <= 0) {
      clearInterval(timerInterval);
      alert('Süre doldu! Testiniz otomatik olarak teslim ediliyor.');
      document.getElementById('testForm').submit();
      return;
    }

    var mins = Math.floor(remainingSeconds / 60);
    var secs = remainingSeconds % 60;
    timerEl.textContent = (mins < 10 ? '0' : '') + mins + ':' + (secs < 10 ? '0' : '') + secs;
    remainingSeconds--;
  }

  updateTimer();
  var timerInterval = setInterval(updateTimer, 1000);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
