<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn/result.php - Sınav ve Test Sonuç Raporu, Analiz ve İstatistik
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

$attempt_id = (int)($_GET['attempt_id'] ?? 0);
$attempt = db_fetch_one("SELECT * FROM exam_attempts WHERE id = ?", "i", [$attempt_id]);

if (!$attempt) {
    header("Location: /elearn/index.php");
    exit;
}

$current_student = get_current_student();
// Sadece ilgili öğrenci veya admin görebilir
if (!$current_student || ($current_student['id'] != $attempt['student_id'] && !is_admin_logged_in())) {
    header("Location: /elearn/index.php");
    exit;
}

$is_exam = ($attempt['type'] === 'exam');
$title = '';
$course = null;

if ($is_exam) {
    $exam = db_fetch_one("SELECT * FROM exams WHERE id = ?", "i", [$attempt['exam_id']]);
    $title = $exam['title'] ?? 'Vize Sınavı';
    $pass_score = $exam['pass_score'] ?? 50;
    $course = db_fetch_one("SELECT * FROM courses WHERE id = ?", "i", [$exam['course_id']]);
} else {
    $test = db_fetch_one("SELECT * FROM tests WHERE id = ?", "i", [$attempt['test_id']]);
    $title = $test['title'] ?? 'Konu Testi';
    $pass_score = $test['pass_score'] ?? 60;
    $course = db_fetch_one("SELECT * FROM courses WHERE id = ?", "i", [$test['course_id']]);
}

// Detaylı soru ve cevap dökümü
$answers_raw = db_fetch_all(
    "SELECT ea.*, q.question_text, q.explanation, q.points,
            qo_user.option_letter as user_letter, qo_user.option_text as user_text,
            qo_correct.option_letter as correct_letter, qo_correct.option_text as correct_text
     FROM exam_answers ea
     INNER JOIN questions q ON ea.question_id = q.id
     LEFT JOIN question_options qo_user ON ea.selected_option_id = qo_user.id
     LEFT JOIN question_options qo_correct ON q.id = qo_correct.question_id AND qo_correct.is_correct = 1
     WHERE ea.attempt_id = ?
     ORDER BY q.id ASC",
    "i",
    [$attempt_id]
) ?: [];

$mins = floor($attempt['time_spent_seconds'] / 60);
$secs = $attempt['time_spent_seconds'] % 60;
$time_formatted = sprintf('%02d:%02d dk', $mins, $secs);

$page_title = 'Sonuç Raporu - ' . $title;
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-navy text-white py-4 border-bottom border-slate-800">
  <div class="container">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
      <div>
        <span class="badge <?php echo $is_exam ? 'bg-warning text-dark' : 'bg-info text-dark'; ?> font-monospace fw-bold px-3 py-1 rounded-pill mb-1">
          <?php echo $is_exam ? 'VİZE SINAVI RAPORU' : 'KONU TESTİ RAPORU'; ?>
        </span>
        <h1 class="h3 fw-bold text-white mb-0"><?php echo e($title); ?></h1>
        <div class="text-slate-300 small mt-1 font-monospace">
          Tarih: <?php echo date('d.m.Y H:i', strtotime($attempt['start_time'])); ?> • Harcanan Süre: <?php echo $time_formatted; ?>
        </div>
      </div>

      <div>
        <?php if ($attempt['is_passed']): ?>
          <span class="badge bg-success fs-6 py-2 px-3 fw-bold shadow-xs">
            <i class="bi bi-patch-check-fill me-1"></i>BAŞARILI (GEÇTİ)
          </span>
        <?php else: ?>
          <span class="badge bg-danger fs-6 py-2 px-3 fw-bold shadow-xs">
            <i class="bi bi-x-circle-fill me-1"></i>BAŞARISIZ (KALDI)
          </span>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="container py-5">
  <div class="row g-4 justify-content-center">
    <div class="col-lg-10">

      <!-- 4 Temel Metrik Kartı -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
          <div class="card card-custom p-3 text-center border-start border-4 border-primary">
            <div class="text-muted small">Alınan Puan</div>
            <div class="fs-2 fw-extrabold font-monospace text-primary mt-1">
              %<?php echo number_format((float)$attempt['score'], 1); ?>
            </div>
            <div class="small text-muted">Baraj: %<?php echo $pass_score; ?></div>
          </div>
        </div>

        <div class="col-6 col-md-3">
          <div class="card card-custom p-3 text-center border-start border-4 border-success">
            <div class="text-muted small">Doğru Sayısı</div>
            <div class="fs-2 fw-extrabold font-monospace text-success mt-1">
              <?php echo (int)$attempt['correct_count']; ?>
            </div>
            <div class="small text-muted">Toplam: <?php echo (int)$attempt['total_questions']; ?> Soru</div>
          </div>
        </div>

        <div class="col-6 col-md-3">
          <div class="card card-custom p-3 text-center border-start border-4 border-danger">
            <div class="text-muted small">Yanlış Sayısı</div>
            <div class="fs-2 fw-extrabold font-monospace text-danger mt-1">
              <?php echo (int)$attempt['wrong_count']; ?>
            </div>
            <div class="small text-muted">Hatalı Cevap</div>
          </div>
        </div>

        <div class="col-6 col-md-3">
          <div class="card card-custom p-3 text-center border-start border-4 border-secondary">
            <div class="text-muted small">Boş / Yanıtsız</div>
            <div class="fs-2 fw-extrabold font-monospace text-secondary mt-1">
              <?php echo (int)$attempt['empty_count']; ?>
            </div>
            <div class="small text-muted">Boş Bırakılan</div>
          </div>
        </div>
      </div>

      <!-- Detaylı Soru Analizi ve Yanlış Cevap İncelemesi -->
      <div class="card card-custom p-4 p-md-5 mb-4">
        <h4 class="fw-bold text-navy mb-4 pb-2 border-bottom">
          <i class="bi bi-card-checklist me-2 text-primary"></i>Detaylı Soru ve Cevap Analizi
        </h4>

        <?php if (!empty($answers_raw)): ?>
          <div class="space-y-4">
            <?php foreach ($answers_raw as $idx => $ans): ?>
              <?php 
                $is_correct = (int)$ans['is_correct'] === 1;
                $is_empty = empty($ans['selected_option_id']);
              ?>
              <div class="p-3 p-md-4 rounded-3 border mb-3 <?php echo $is_correct ? 'border-success-subtle bg-success-subtle/10' : ($is_empty ? 'border-secondary-subtle bg-secondary-subtle/10' : 'border-danger-subtle bg-danger-subtle/10'); ?>">
                <div class="d-flex align-items-center justify-content-between mb-2">
                  <span class="badge bg-navy font-monospace fw-bold">Soru <?php echo $idx + 1; ?></span>
                  <?php if ($is_correct): ?>
                    <span class="badge bg-success"><i class="bi bi-check-lg me-1"></i>DOĞRU (+<?php echo (int)$ans['points_earned']; ?> Puan)</span>
                  <?php elseif ($is_empty): ?>
                    <span class="badge bg-secondary"><i class="bi bi-dash-circle me-1"></i>BOŞ (0 Puan)</span>
                  <?php else: ?>
                    <span class="badge bg-danger"><i class="bi bi-x-lg me-1"></i>YANLIŞ (0 Puan)</span>
                  <?php endif; ?>
                </div>

                <h6 class="fw-bold text-dark mb-3"><?php echo e($ans['question_text']); ?></h6>

                <div class="row g-2 mb-3 small">
                  <div class="col-md-6">
                    <div class="p-2.5 rounded bg-white border">
                      <span class="text-muted d-block" style="font-size: 0.75rem;">Sizin Cevabınız:</span>
                      <?php if ($is_empty): ?>
                        <em class="text-secondary">Cevap verilmedi</em>
                      <?php else: ?>
                        <span class="<?php echo $is_correct ? 'text-success fw-bold' : 'text-danger fw-bold'; ?>">
                          <?php echo e($ans['user_letter']); ?>) <?php echo e($ans['user_text']); ?>
                        </span>
                      <?php endif; ?>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="p-2.5 rounded bg-white border">
                      <span class="text-muted d-block" style="font-size: 0.75rem;">Doğru Cevap:</span>
                      <span class="text-success fw-bold">
                        <?php echo e($ans['correct_letter']); ?>) <?php echo e($ans['correct_text']); ?>
                      </span>
                    </div>
                  </div>
                </div>

                <?php if (!empty($ans['explanation'])): ?>
                  <div class="p-2.5 rounded bg-light border-start border-3 border-info small text-secondary">
                    <strong><i class="bi bi-info-circle me-1 text-info"></i>Soru Açıklaması & Çözüm:</strong>
                    <div class="mt-1"><?php echo e($ans['explanation']); ?></div>
                  </div>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <p class="text-muted">Bu girişime ait soru dökümü bulunamadı.</p>
        <?php endif; ?>

        <!-- Gezinme Butonları -->
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 pt-4 border-top mt-4">
          <?php if ($course): ?>
            <a href="/elearn/course.php?slug=<?php echo e($course['slug']); ?>" class="btn btn-outline-secondary">
              <i class="bi bi-arrow-left me-1"></i><?php echo e($course['title']); ?> Dersine Dön
            </a>
          <?php endif; ?>
          <a href="/elearn/profile.php" class="btn btn-accent fw-bold px-4">
            <i class="bi bi-person-circle me-1"></i>Profilime ve Karneme Git
          </a>
        </div>
      </div>

    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
