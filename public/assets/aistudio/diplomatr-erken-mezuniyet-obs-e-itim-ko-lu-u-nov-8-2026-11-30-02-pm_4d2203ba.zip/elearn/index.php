<?php
/**
 * E-LEARN - Öğrenci Eğitim, Sınav ve İstatistik Platformu
 * /elearn Ders Kataloğu ve AJAX Auth Handler
 */

require_once __DIR__ . '/../config/settings.php';
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/visitor_tracker.php';

// AJAX Login & Register İsteklerini Yakala
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Geçersiz güvenlik doğrulaması (CSRF). Sayfayı yenileyip tekrar deneyiniz.']);
        exit;
    }

    if ($_POST['action'] === 'student_login') {
        $student_num = $_POST['student_number'] ?? '';
        $pass = $_POST['password'] ?? '';
        $remember = !empty($_POST['remember']);
        $result = student_login($student_num, $pass, $remember);
        if ($result['success']) {
            $result['redirect'] = '/elearn/profile.php';
        }
        echo json_encode($result);
        exit;
    }

    if ($_POST['action'] === 'student_register') {
        $result = student_register($_POST);
        echo json_encode($result);
        exit;
    }
}

$page_title = 'E-Learn Eğitim Modülü ve Ders Kataloğu';
require_once __DIR__ . '/../includes/header.php';

// Filtreleme
$category = clean_input($_GET['category'] ?? '');
$search = clean_input($_GET['q'] ?? '');

$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM course_topics ct WHERE ct.course_id = c.id AND ct.is_active = 1) AS topic_count,
        (SELECT COUNT(*) FROM exams e WHERE e.course_id = c.id AND e.is_active = 1) AS exam_count
        FROM courses c 
        WHERE c.is_active = 1";

$params = [];
$types = "";

if (!empty($category)) {
    $sql .= " AND c.category = ?";
    $params[] = $category;
    $types .= "s";
}

if (!empty($search)) {
    $sql .= " AND (c.title LIKE ? OR c.description LIKE ?)";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $types .= "ss";
}

$sql .= " ORDER BY c.sort_order ASC, c.id ASC";
$courses = db_query_params($sql, $types, $params) ?: [];
$categories = db_fetch_all("SELECT DISTINCT category FROM courses WHERE is_active = 1 ORDER BY category ASC") ?: [];
?>

<div class="bg-navy text-white py-4 py-md-5 border-bottom border-slate-800">
  <div class="container">
    <div class="row align-items-center justify-content-between g-3">
      <div class="col-md-8">
        <span class="badge bg-info text-dark font-monospace fw-bold px-3 py-1 rounded-pill mb-2">E-LEARN MODÜLÜ</span>
        <h1 class="display-6 fw-bold text-white mb-2">Akademik Dersler ve Müfredat Programları</h1>
        <p class="text-slate-300 small mb-0">
          Konu anlatımları, ders materyalleri, interaktif testler ve vize sınavlarıyla eksiksiz öğrenme deneyimi.
        </p>
      </div>
      <div class="col-md-4 text-md-end">
        <?php if ($current_student): ?>
          <a href="/elearn/profile.php" class="btn btn-outline-light btn-sm fw-semibold">
            <i class="bi bi-person-circle me-1"></i>Öğrenci Profilim & Notlarım
          </a>
        <?php else: ?>
          <button type="button" class="btn btn-accent btn-sm fw-bold px-3" data-bs-toggle="modal" data-bs-target="#registerModal">
            <i class="bi bi-person-plus-fill me-1"></i>Hemen Kayıt Ol
          </button>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="container py-5">
  <!-- Arama ve Kategori Filtreleme Çubuğu -->
  <div class="card card-custom p-3 p-md-4 mb-4">
    <form method="GET" action="/elearn/index.php" class="row g-3 align-items-center">
      <div class="col-md-5">
        <div class="input-group">
          <span class="input-group-text bg-light text-secondary border-end-0"><i class="bi bi-search"></i></span>
          <input type="text" name="q" class="form-control border-start-0" placeholder="Ders adı veya açıklama ile ara..." value="<?php echo e($search); ?>">
        </div>
      </div>
      <div class="col-md-4">
        <select name="category" class="form-select">
          <option value="">Tüm Kategoriler</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?php echo e($cat['category']); ?>" <?php echo ($category === $cat['category']) ? 'selected' : ''; ?>>
              <?php echo e($cat['category']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 d-flex gap-2">
        <button type="submit" class="btn btn-primary w-100 fw-semibold">
          <i class="bi bi-funnel me-1"></i>Filtrele
        </button>
        <?php if (!empty($search) || !empty($category)): ?>
          <a href="/elearn/index.php" class="btn btn-outline-secondary" title="Sıfırla">
            <i class="bi bi-x-lg"></i>
          </a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Ders Kartları Grid -->
  <div class="row g-4">
    <?php if (!empty($courses)): ?>
      <?php foreach ($courses as $c): ?>
        <div class="col-lg-4 col-md-6">
          <div class="card card-custom h-100 overflow-hidden d-flex flex-column">
            <div class="position-relative" style="height: 190px;">
              <img src="<?php echo e($c['image'] ?: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80'); ?>" alt="<?php echo e($c['title']); ?>" class="w-100 h-100 object-fit-cover">
              <span class="position-absolute top-0 end-0 m-3 badge bg-navy text-white px-2.5 py-1 rounded-pill shadow-sm small">
                <?php echo e($c['category']); ?>
              </span>
            </div>
            <div class="card-body p-4 d-flex flex-column flex-grow-1">
              <h5 class="fw-bold text-navy mb-2"><?php echo e($c['title']); ?></h5>
              <p class="text-muted small flex-grow-1 leading-relaxed mb-4">
                <?php echo e($c['description']); ?>
              </p>
              
              <div class="d-flex align-items-center justify-content-between pt-3 border-top small text-secondary">
                <span><i class="bi bi-collection text-primary me-1"></i><?php echo (int)$c['topic_count']; ?> Konu Anlatımı</span>
                <span><i class="bi bi-award text-success me-1"></i><?php echo (int)$c['exam_count']; ?> Vize Sınavı</span>
              </div>
            </div>
            <div class="card-footer bg-light border-top p-3 text-center">
              <a href="/elearn/course.php?slug=<?php echo e($c['slug']); ?>" class="btn btn-accent w-100 fw-bold">
                <i class="bi bi-folder2-open me-1"></i>Dersi İncele & Çalış
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="col-12 text-center py-5">
        <i class="bi bi-inbox fs-1 text-muted d-block mb-3"></i>
        <h5 class="fw-bold text-muted">Aramanıza uygun ders bulunamadı.</h5>
        <a href="/elearn/index.php" class="btn btn-sm btn-outline-primary mt-2">Tüm Dersleri Göster</a>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
